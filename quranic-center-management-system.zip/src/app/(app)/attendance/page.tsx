import Link from "next/link";
import { redirect } from "next/navigation";
import { and, asc, eq, inArray } from "drizzle-orm";
import { CalendarCheck, ClipboardList } from "lucide-react";
import { db } from "@/db";
import { attendance, classSessions, classes, enrollments, students, users } from "@/db/schema";
import { Card, EmptyState, PageHeader } from "@/components/ui";
import { AttendanceQuick } from "@/components/teaching-forms";
import { classModeMeta } from "@/lib/labels";
import {
  addDays,
  faDate,
  faDateLong,
  faDays,
  faDigits,
  faTime,
  faWeekday,
  isoDate,
  todayISO,
} from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AttendancePage({
  searchParams,
}: {
  searchParams: Promise<{ date?: string; session?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "parent") redirect("/dashboard");

  const params = await searchParams;
  const classScope =
    user.role === "teacher"
      ? (await db.select({ id: classes.id }).from(classes).where(eq(classes.teacherId, user.id))).map(
          (row) => row.id,
        )
      : null;

  const today = new Date();
  const nearby = Array.from({ length: 15 }, (_, index) => isoDate(addDays(today, index - 3)));

  let date = params.date && /^\d{4}-\d{2}-\d{2}$/.test(params.date) ? params.date : todayISO();
  if (params.session) {
    const found = await db
      .select({ sessionDate: classSessions.sessionDate })
      .from(classSessions)
      .where(eq(classSessions.id, Number(params.session)))
      .limit(1);
    if (found[0]) date = found[0].sessionDate;
  }

  const sessionRows = await db
    .select({
      id: classSessions.id,
      classId: classSessions.classId,
      sessionDate: classSessions.sessionDate,
      startTime: classSessions.startTime,
      topic: classSessions.topic,
      className: classes.name,
      mode: classes.mode,
      location: classes.location,
    })
    .from(classSessions)
    .innerJoin(classes, eq(classes.id, classSessions.classId))
    .where(
      classScope && classScope.length
        ? and(eq(classSessions.sessionDate, date), inArray(classSessions.classId, classScope))
        : eq(classSessions.sessionDate, date),
    )
    .orderBy(asc(classSessions.startTime));

  const scopedSessions =
    user.role === "teacher" && params.session
      ? sessionRows.filter((row) => classScope?.includes(row.classId))
      : sessionRows;

  const teacherMap = new Map<number, string>();
  const teacherRows = await db
    .select({ classId: classes.id, fullName: users.fullName })
    .from(classes)
    .leftJoin(users, eq(users.id, classes.teacherId));
  teacherRows.forEach((row) => {
    if (row.fullName) teacherMap.set(row.classId, row.fullName);
  });

  const attendanceRows = scopedSessions.length
    ? await db
        .select({
          sessionId: attendance.sessionId,
          studentId: attendance.studentId,
          status: attendance.status,
        })
        .from(attendance)
        .where(
          inArray(
            attendance.sessionId,
            scopedSessions.map((session) => session.id),
          ),
        )
    : [];

  const studentsByClass = new Map<number, { studentId: number; fullName: string }[]>();
  const classIds = Array.from(new Set(scopedSessions.map((session) => session.classId)));
  if (classIds.length > 0) {
    const rows = await db
      .select({
        classId: enrollments.classId,
        studentId: students.id,
        fullName: users.fullName,
      })
      .from(enrollments)
      .innerJoin(students, eq(students.id, enrollments.studentId))
      .innerJoin(users, eq(users.id, students.userId))
      .where(and(inArray(enrollments.classId, classIds), eq(enrollments.status, "active")));
    rows.forEach((row) => {
      const list = studentsByClass.get(row.classId) ?? [];
      list.push({ studentId: row.studentId, fullName: row.fullName });
      studentsByClass.set(row.classId, list);
    });
  }

  return (
    <>
      <PageHeader
        title="حضور و غیاب"
        description="ثبت سریع حضور با یک کلیک — اطلاع‌رسانی غیبت به ولی به‌صورت خودکار انجام می‌شود"
      />

      <Card title="انتخاب تاریخ" subtitle="روی تاریخ دلخواه بزنید" className="mb-4">
        <div className="flex flex-wrap gap-2">
          {nearby.map((item) => (
            <Link
              key={item}
              href={`/attendance?date=${item}`}
              className={`rounded-xl border px-3 py-1.5 text-xs font-bold transition ${
                item === date
                  ? "border-emerald-600 bg-emerald-600 text-white"
                  : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300"
              }`}
            >
              {faWeekday(item)} {faDigits(Number(item.slice(8, 10)))}
            </Link>
          ))}
        </div>
        <p className="mt-3 text-sm font-bold text-emerald-800">{faDateLong(date)}</p>
      </Card>

      {scopedSessions.length === 0 ? (
        <EmptyState text="در این تاریخ جلسه‌ای وجود ندارد." icon={<CalendarCheck className="h-6 w-6" />} />
      ) : (
        scopedSessions.map((session) => {
          const initial: Record<string, string> = {};
          attendanceRows
            .filter((row) => row.sessionId === session.id)
            .forEach((row) => {
              initial[String(row.studentId)] = row.status;
            });
          return (
            <div key={session.id}>
              <AttendanceQuick
                sessionId={session.id}
                className={session.className}
                sessionDate={session.sessionDate}
                startTime={session.startTime}
                students={studentsByClass.get(session.classId) ?? []}
                initial={initial as Record<string, never>}
              />
              <p className="mb-4 text-xs text-slate-500">
                استاد: {teacherMap.get(session.classId) ?? "—"} •{" "}
                {classModeMeta[session.mode].label} • {session.location} • موضوع:{" "}
                {session.topic || "—"}
              </p>
            </div>
          );
        })
      )}

      <Card title="راهنما" subtitle="وضعیت‌های رنگی">
        <div className="flex flex-wrap gap-3 text-xs font-bold">
          <span className="rounded-lg bg-emerald-600 px-3 py-1.5 text-white">حاضر</span>
          <span className="rounded-lg bg-rose-600 px-3 py-1.5 text-white">غایب</span>
          <span className="rounded-lg bg-amber-500 px-3 py-1.5 text-white">تأخیر</span>
          <span className="rounded-lg bg-sky-600 px-3 py-1.5 text-white">موجه</span>
        </div>
        <p className="mt-3 flex items-center gap-2 text-xs text-slate-500">
          <ClipboardList className="h-4 w-4" />
          با هر کلیک، وضعیت همان لحظه ذخیره می‌شود؛ نیازی به دکمه «ذخیره» نیست.
        </p>
      </Card>

      <p className="mt-4 text-center text-xs text-slate-400">
        تعداد جلسات این تاریخ: {faDigits(scopedSessions.length)} — {faDate(date)}
      </p>
    </>
  );
}
