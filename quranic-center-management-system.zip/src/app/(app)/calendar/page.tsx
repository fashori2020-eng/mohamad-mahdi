import Link from "next/link";
import { redirect } from "next/navigation";
import { CalendarDays, Trash2 } from "lucide-react";
import { Badge, Card, EmptyState, PageHeader } from "@/components/ui";
import { DeleteEventButton, EventCreator } from "@/components/admin-forms";
import { listEvents, listClasses } from "@/lib/data";
import { classModeMeta, eventTypeMeta } from "@/lib/labels";
import {
  JALALI_MONTHS,
  WEEK_DAYS_SHORT,
  addDays,
  faDate,
  faDateLong,
  faDays,
  faDigits,
  faTime,
  faWeekday,
  faWeekdayIndex,
  isoDate,
  jalaaliMonthLength,
  parseISO,
  toGregorian,
  toJalali,
  todayISO,
} from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function CalendarPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const today = new Date();
  const weekIndex = faWeekdayIndex(today);
  const weekStart = addDays(today, -weekIndex);
  const weekEnd = addDays(weekStart, 6);

  const [weekSessions, events] = await Promise.all([
    import("@/lib/data").then((m) => m.getSessionsInRange(isoDate(weekStart), isoDate(weekEnd))),
    listEvents(isoDate(addDays(today, -30)), isoDate(addDays(today, 90))),
  ]);

  const classIds = Array.from(new Set(weekSessions.map((s) => s.classId)));
  const classRows = classIds.length ? await listClasses() : [];
  void classIds;
  void classRows;

  const { jy, jm } = toJalali(today);
  const monthLength = jalaaliMonthLength(jy, jm);
  const firstDate = toGregorian(jy, jm, 1);
  const leading = faWeekdayIndex(firstDate);

  const sessionDates = new Set(weekSessions.map((s) => s.sessionDate));
  const eventMap = new Map<string, typeof events>();
  events.forEach((event) => {
    const list = eventMap.get(event.eventDate) ?? [];
    list.push(event);
    eventMap.set(event.eventDate, list);
  });

  const times = Array.from(new Set(weekSessions.map((s) => s.startTime))).sort();

  return (
    <>
      <PageHeader
        title="برنامه‌ریزی و تقویم"
        description="جدول هفتگی کلاس‌ها و تقویم ماهانه آزمون‌ها، مناسبت‌ها و اردوها"
      />

      <div className="grid gap-4 xl:grid-cols-5">
        <Card
          title="جدول هفتگی کلاس‌ها"
          subtitle={`${faDate(isoDate(weekStart))} تا ${faDate(isoDate(weekEnd))}`}
          className="xl:col-span-3"
        >
          {times.length === 0 ? (
            <EmptyState text="این هفته جلسه‌ای ثبت نشده است." icon={<CalendarDays className="h-6 w-6" />} />
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>ساعت</th>
                    {WEEK_DAYS_SHORT.map((day) => (
                      <th key={day} className="text-center">
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {times.map((time) => (
                    <tr key={time}>
                      <td className="font-bold text-emerald-900">{faTime(time)}</td>
                      {WEEK_DAYS_SHORT.map((day, index) => {
                        const cellDate = isoDate(addDays(weekStart, index));
                        const items = weekSessions.filter(
                          (session) => session.startTime === time && session.sessionDate === cellDate,
                        );
                        return (
                          <td key={`${time}-${day}`} className="align-top">
                            {items.length === 0 ? (
                              <span className="text-slate-300">—</span>
                            ) : (
                              <div className="space-y-1">
                                {items.map((item) => (
                                  <Link
                                    key={item.id}
                                    href={`/attendance?session=${item.id}`}
                                    className="block rounded-lg bg-emerald-50 px-2 py-1 text-[11px] font-bold text-emerald-800 hover:bg-emerald-100"
                                  >
                                    {item.className}
                                    <span className="block font-normal text-emerald-600">
                                      {item.teacherName ?? "—"}
                                    </span>
                                  </Link>
                                ))}
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card
          title={`تقویم ${JALALI_MONTHS[jm - 1]} ${faDigits(jy)}`}
          subtitle="آزمون‌ها، مناسبت‌ها و اردوها"
          className="xl:col-span-2"
        >
          <div className="grid grid-cols-7 gap-1 text-center">
            {WEEK_DAYS_SHORT.map((day) => (
              <span key={day} className="py-1 text-[11px] font-extrabold text-emerald-700">
                {day}
              </span>
            ))}
            {Array.from({ length: leading }, (_, index) => (
              <span key={`blank-${index}`} />
            ))}
            {Array.from({ length: monthLength }, (_, index) => index + 1).map((day) => {
              const date = toGregorian(jy, jm, day);
              const iso = isoDate(date);
              const isToday = iso === todayISO();
              const hasSession = sessionDates.has(iso);
              const dayEvents = eventMap.get(iso) ?? [];
              return (
                <div
                  key={day}
                  className={`rounded-lg border p-1 text-xs ${
                    isToday
                      ? "border-emerald-600 bg-emerald-600 font-extrabold text-white"
                      : dayEvents.length
                        ? "border-amber-300 bg-amber-50 text-amber-900"
                        : hasSession
                          ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                          : "border-slate-200 text-slate-600"
                  }`}
                  title={dayEvents.map((event) => event.title).join(" • ")}
                >
                  {faDigits(day)}
                  {dayEvents.length > 0 && (
                    <span className="mx-auto mt-0.5 block h-1 w-1 rounded-full bg-amber-500" />
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-3 flex flex-wrap gap-3 text-[11px] font-bold text-slate-500">
            <span className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-emerald-600" /> امروز
            </span>
            <span className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-emerald-100" /> جلسه کلاس
            </span>
            <span className="flex items-center gap-1">
              <span className="h-3 w-3 rounded bg-amber-100" /> رویداد
            </span>
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card title="رویدادهای پیش‌رو" className="lg:col-span-2" padded={false}>
          {events.length === 0 ? (
            <div className="p-5">
              <EmptyState text="رویدادی ثبت نشده است." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>تاریخ</th>
                    <th>روز</th>
                    <th>عنوان</th>
                    <th>نوع</th>
                    <th>توضیحات</th>
                    {user.role === "manager" && <th />}
                  </tr>
                </thead>
                <tbody>
                  {events.map((event) => (
                    <tr key={event.id}>
                      <td className="font-bold text-emerald-900">{faDate(event.eventDate)}</td>
                      <td>{faWeekday(parseISO(event.eventDate))}</td>
                      <td>{event.title}</td>
                      <td>
                        <Badge className={eventTypeMeta[event.eventType].className}>
                          {eventTypeMeta[event.eventType].label}
                        </Badge>
                      </td>
                      <td className="max-w-xs text-xs text-slate-500">{event.description || "—"}</td>
                      {user.role === "manager" && (
                        <td>
                          <DeleteEventButton eventId={event.id} />
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <div className="space-y-4">
          {user.role === "manager" && <EventCreator />}
          <Card title="جلسات هفته آینده">
            <ul className="space-y-2">
              {weekSessions
                .filter((session) => session.sessionDate >= todayISO())
                .slice(0, 8)
                .map((session) => (
                  <li key={session.id} className="rounded-xl bg-slate-50 px-3 py-2">
                    <p className="truncate text-sm font-bold text-emerald-900">{session.className}</p>
                    <p className="text-xs text-slate-500">
                      {faDateLong(session.sessionDate)} — {faTime(session.startTime)} —{" "}
                      {session.location} • {classModeMeta[session.mode].label}
                    </p>
                  </li>
                ))}
              {weekSessions.filter((session) => session.sessionDate >= todayISO()).length === 0 && (
                <EmptyState text="جلسه‌ای باقی نمانده است." />
              )}
            </ul>
          </Card>
          <Card title="برنامه هفتگی کلاس‌ها">
            <ul className="space-y-1.5 text-sm text-slate-600">
              {(await listClasses()).map((cls) => (
                <li key={cls.id} className="flex items-center justify-between gap-2">
                  <Link href={`/classes/${cls.id}`} className="truncate font-bold text-emerald-900">
                    {cls.name}
                  </Link>
                  <span className="shrink-0 text-xs text-slate-500">{faDays(cls.days)}</span>
                </li>
              ))}
            </ul>
          </Card>
          <p className="text-center text-[11px] text-slate-400">
            <Trash2 className="inline h-3 w-3" /> حذف رویداد فقط برای مدیر مجموعه فعال است.
          </p>
        </div>
      </div>
    </>
  );
}
