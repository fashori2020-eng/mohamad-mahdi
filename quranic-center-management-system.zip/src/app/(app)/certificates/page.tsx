import Link from "next/link";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { Award, Printer } from "lucide-react";
import { db } from "@/db";
import { students, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { CertificateIssuer } from "@/components/admin-forms";
import { listCertificates, listClasses } from "@/lib/data";
import { faDate, faDigits } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function CertificatesPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  let rows;
  if (user.role === "student") {
    const studentRows = await db
      .select({ id: students.id })
      .from(students)
      .where(eq(students.userId, user.id));
    rows = await listCertificates({ studentIds: studentRows.map((row) => row.id) });
  } else if (user.role === "parent") {
    const childRows = await db
      .select({ id: students.id })
      .from(students)
      .where(eq(students.parentUserId, user.id));
    rows = await listCertificates({ studentIds: childRows.map((row) => row.id) });
  } else {
    rows = await listCertificates();
  }

  const studentRows = await db
    .select({ id: students.id, fullName: users.fullName })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId));
  const classRows = await listClasses();

  return (
    <>
      <PageHeader
        title="گواهی‌های پایان دوره"
        description="صدور گواهی با طراحی اختصاصی و دریافت خروجی PDF"
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="گواهی‌های صادرشده" value={faDigits(rows.length)} icon={<Award className="h-6 w-6" />} />
        <StatCard label="قرآن‌آموزان" value={faDigits(new Set(rows.map((row) => row.studentId)).size)} tone="sky" icon={<Award className="h-6 w-6" />} />
        <StatCard
          label="ساعت آموزش تأییدشده"
          value={faDigits(rows.reduce((sum, row) => sum + row.hours, 0))}
          tone="gold"
          icon={<Award className="h-6 w-6" />}
        />
      </div>

      {user.role === "manager" && (
        <div className="mt-4">
          <CertificateIssuer
            students={studentRows}
            classes={classRows.map((row) => ({ id: row.id, name: row.name }))}
          />
        </div>
      )}

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        {rows.length === 0 ? (
          <EmptyState text="گواهی‌ای صادر نشده است." icon={<Award className="h-6 w-6" />} />
        ) : (
          rows.map((row) => (
            <Card
              key={row.id}
              title={row.courseName}
              subtitle={`${row.studentName} • ${faDate(row.issuedAt)}`}
              action={
                <Link href={`/print/certificate/${row.id}`} className="btn btn-gold btn-sm">
                  <Printer className="h-4 w-4" />
                  مشاهده / PDF
                </Link>
              }
            >
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-emerald-50 text-emerald-700">{row.level || "دوره قرآنی"}</Badge>
                <Badge className="bg-amber-50 text-amber-800">{row.grade}</Badge>
                <Badge className="bg-slate-100 text-slate-600">{faDigits(row.hours)} ساعت</Badge>
              </div>
              <p className="mt-3 text-xs text-slate-500">
                مدرس: {row.teacherName || "—"} — شماره سری: <span dir="ltr">{row.serial}</span>
              </p>
            </Card>
          ))
        )}
      </div>
    </>
  );
}
