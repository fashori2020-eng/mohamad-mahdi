import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, asc, desc, eq, gte, inArray, lte } from "drizzle-orm";
import { CalendarClock, MapPin, Users } from "lucide-react";
import { db } from "@/db";
import { attendance, classSessions, classes, students as studentsTable, teachers, users } from "@/db/schema";
import { Badge, Card, EmptyState, KeyValue, PageHeader, ProgressBar } from "@/components/ui";
import { ClassEnroller, SessionGenerator, TeacherAssigner } from "@/components/admin-forms";
import { getClassStudents } from "@/lib/data";
import { classModeMeta, levelLabel } from "@/lib/labels";
import {
  addDays,
  faDate,
  faDateLong,
  faDays,
  faDigits,
  faMoney,
  faTime,
  isoDate,
} from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ClassDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const classId = Number(id);
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "parent") redirect("/dashboard");

  const rows = await db
    .select({ cls: classes, teacherName: users.fullName })
    .from(classes)
    .leftJoin(teachers, eq(teachers.id, classes.teacherId))
    .leftJoin(users, eq(users.id, teachers.userId))
    .where(eq(classes.id, classId))
    .limit(1);
  if (!rows[0]) notFound();

  const { cls, teacherName } = rows[0];
  const studentRows = await getClassStudents(classId);

  const sessions = await db
    .select()
    .from(classSessions)
    .where(
      and(
        eq(classSessions.classId, classId),
        gte(classSessions.sessionDate, isoDate(addDays(new Date(), -14))),
        lte(classSessions.sessionDate, isoDate(addDays(new Date(), +30))),
      ),
    )
    .orderBy(asc(classSessions.sessionDate));

  const perStudent = await db
    .select({ studentId: attendance.studentId, status: attendance.status, sessionId: attendance.sessionId })
    .from(attendance)
    .orderBy(desc(attendance.id));

  const sessionIds = new Set(sessions.map((session) => session.id));
  const summary = new Map<number, { present: number; total: number }>();
  studentRows.forEach((student) => summary.set(student.studentId, { present: 0, total: 0 }));
  perStudent.forEach((row) => {
    if (!sessionIds.has(row.sessionId)) return;
    if (!summary.has(row.studentId)) return;
    const item = summary.get(row.studentId)!;
    item.total += 1;
    if (row.status === "present" || row.status === "late") item.present += 1;
  });

  const teacherOptions = await db
    .select({ id: teachers.id, fullName: users.fullName })
    .from(teachers)
    .innerJoin(users, eq(users.id, teachers.userId))
    .orderBy(asc(users.fullName));

  const studentOptions = await db
    .select({ id: studentsTable.id, fullName: users.fullName })
    .from(studentsTable)
    .innerJoin(users, eq(users.id, studentsTable.userId))
    .orderBy(asc(users.fullName));

  return (
    <>
      <PageHeader
        title={cls.name}
        description={`${levelLabel(cls.courseType)} • ${classModeMeta[cls.mode].label} • استاد: ${
          teacherName ?? "تعیین نشده"
        }`}
        action={
          <Link href="/classes" className="btn btn-ghost">
            بازگشت به کلاس‌ها
          </Link>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="مشخصات کلاس" className="lg:col-span-2">
          <div className="grid gap-3 sm:grid-cols-2">
            <KeyValue label="روزهای برگزاری" value={faDays(cls.days)} />
            <KeyValue label="ساعت" value={`${faTime(cls.startTime)} — ${faDigits(cls.durationMinutes)} دقیقه`} />
            <KeyValue label="مکان" value={cls.location || "—"} />
            <KeyValue label="ظرفیت" value={`${faDigits(studentRows.length)} از ${faDigits(cls.capacity)}`} />
            <KeyValue label="شهریه" value={faMoney(cls.tuition)} />
            <KeyValue label="تاریخ شروع" value={faDateLong(cls.startDate)} />
            <KeyValue label="تاریخ پایان" value={faDate(cls.endDate)} />
            <KeyValue label="وضعیت" value={cls.status === "active" ? "فعال" : "غیرفعال"} />
          </div>
          <p className="mt-3 rounded-xl bg-slate-50 p-3 text-sm leading-6 text-slate-700">
            {cls.description || "توضیحی ثبت نشده است."}
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge className={classModeMeta[cls.mode].className}>{classModeMeta[cls.mode].label}</Badge>
            <Badge className="bg-emerald-50 text-emerald-700">{levelLabel(cls.courseType)}</Badge>
          </div>
          {user.role === "manager" && (
            <div className="mt-4 space-y-4 border-t border-slate-100 pt-4">
              <TeacherAssigner classId={cls.id} teachers={teacherOptions} current={cls.teacherId} />
              <SessionGenerator classId={cls.id} />
            </div>
          )}
        </Card>

        <Card title="قرآن‌آموزان کلاس" subtitle={`${faDigits(studentRows.length)} نفر`}>
          {studentRows.length === 0 ? (
            <EmptyState text="قرآن‌آموزی ثبت‌نام نکرده است." icon={<Users className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {studentRows.map((student) => {
                const item = summary.get(student.studentId) ?? { present: 0, total: 0 };
                return (
                  <li key={student.studentId} className="rounded-xl border border-slate-200 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <Link
                        href={`/students/${student.studentId}`}
                        className="truncate font-bold text-emerald-900 hover:underline"
                      >
                        {student.fullName}
                      </Link>
                      <span className="text-xs font-bold text-slate-500" dir="ltr">
                        {faDigits(student.mobile)}
                      </span>
                    </div>
                    <div className="mt-2">
                      <p className="mb-1 text-[11px] font-bold text-slate-500">
                        حضور: {faDigits(item.present)} از {faDigits(item.total)} جلسه
                      </p>
                      <ProgressBar value={item.present} max={Math.max(item.total, 1)} showPercent />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
          {user.role === "manager" && (
            <div className="mt-4 border-t border-slate-100 pt-4">
              <ClassEnroller classId={cls.id} students={studentOptions} />
            </div>
          )}
        </Card>
      </div>

      <div className="mt-4">
        <Card
          title="جلسات کلاس"
          subtitle="۴ هفته گذشته تا یک ماه آینده"
          action={
            <Link href={`/attendance?session=${cls.id}`} className="btn btn-ghost btn-sm">
              ثبت حضور
            </Link>
          }
        >
          {sessions.length === 0 ? (
            <EmptyState text="جلسه‌ای ثبت نشده است." icon={<CalendarClock className="h-6 w-6" />} />
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>تاریخ</th>
                    <th>ساعت</th>
                    <th>موضوع</th>
                    <th>وضعیت</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {sessions.map((session) => (
                    <tr key={session.id}>
                      <td className="font-bold text-emerald-900">{faDate(session.sessionDate)}</td>
                      <td>{faTime(session.startTime)}</td>
                      <td>{session.topic}</td>
                      <td>
                        {session.sessionDate < isoDate(new Date()) ? "برگزار شده" : "در پیش"}
                      </td>
                      <td>
                        <Link href={`/attendance?session=${session.id}`} className="btn btn-ghost btn-sm">
                          <MapPin className="h-3 w-3" />
                          حضور و غیاب
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}
