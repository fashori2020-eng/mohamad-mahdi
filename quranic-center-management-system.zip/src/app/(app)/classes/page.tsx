import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, eq, inArray } from "drizzle-orm";
import { CalendarClock, School, Users } from "lucide-react";
import { db } from "@/db";
import { classes, enrollments, students, teachers, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { DataTable } from "@/components/data-table";
import { ClassCreator } from "@/components/admin-forms";
import { listClasses } from "@/lib/data";
import { classModeMeta, levelLabel } from "@/lib/labels";
import { faDate, faDays, faDigits, faMoney, faTime } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ClassesPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  if (user.role === "student") return <StudentClassesView userId={user.id} />;
  if (user.role === "parent") return <ParentClassesView />;

  const rows = await listClasses();
  const countRows = await db
    .select({ classId: enrollments.classId, value: enrollments.id })
    .from(enrollments);

  const enrolledCount = (classId: number) =>
    countRows.filter((row) => row.classId === classId).length;

  const scoped =
    user.role === "teacher" ? rows.filter((row) => row.teacherId !== null) : rows;

  const teacherOptions = await db
    .select({ id: teachers.id, fullName: users.fullName })
    .from(teachers)
    .innerJoin(users, eq(users.id, teachers.userId))
    .orderBy(asc(users.fullName));

  const tableRows = scoped
    .filter((row) => (user.role === "teacher" ? row.teacherId === user.id : true))
    .map((row) => ({
      id: String(row.id),
      href: `/classes/${row.id}`,
      values: {
        name: row.name,
        courseType: levelLabel(row.courseType),
        teacherName: row.teacherName ?? "—",
        schedule: `${faDays(row.days)} — ${faTime(row.startTime)}`,
        mode: classModeMeta[row.mode].label,
        location: row.location,
        students: faDigits(enrolledCount(row.id)),
        tuition: faMoney(row.tuition),
        status: row.status === "active" ? "فعال" : "غیرفعال",
      },
    }));

  return (
    <>
      <PageHeader
        title="کلاس‌ها و دوره‌ها"
        description="دوره‌های حفظ، روخوانی، تجوید، مفاهیم و قرائت — تعیین استاد، زمان و مکان"
        action={
          user.role === "manager" ? <ClassCreator teachers={teacherOptions} /> : undefined
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="کل کلاس‌ها" value={faDigits(rows.length)} icon={<School className="h-6 w-6" />} />
        <StatCard
          label="کلاس‌های حضوری"
          value={faDigits(rows.filter((row) => row.mode === "inperson").length)}
          tone="emerald"
          icon={<School className="h-6 w-6" />}
        />
        <StatCard
          label="کلاس‌های آنلاین"
          value={faDigits(rows.filter((row) => row.mode === "online").length)}
          tone="sky"
          icon={<School className="h-6 w-6" />}
        />
        <StatCard
          label="ثبت‌نام‌ها"
          value={faDigits(countRows.length)}
          tone="gold"
          icon={<Users className="h-6 w-6" />}
        />
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {scoped.map((row) => (
          <Card
            key={row.id}
            title={
              <Link href={`/classes/${row.id}`} className="hover:text-emerald-700">
                {row.name}
              </Link>
            }
            subtitle={`${levelLabel(row.courseType)} • ${classModeMeta[row.mode].label}`}
          >
            <ul className="space-y-1.5 text-sm text-slate-600">
              <li>استاد: {row.teacherName ?? "—"}</li>
              <li>
                <CalendarClock className="inline h-4 w-4 text-emerald-600" /> {faDays(row.days)} —{" "}
                {faTime(row.startTime)} ({faDigits(row.durationMinutes)} دقیقه)
              </li>
              <li>مکان: {row.location}</li>
              <li>
                ظرفیت: {faDigits(enrolledCount(row.id))} از {faDigits(row.capacity)}
              </li>
              <li>شهریه: {faMoney(row.tuition)}</li>
              <li>شروع: {faDate(row.startDate)}</li>
            </ul>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge className={classModeMeta[row.mode].className}>{classModeMeta[row.mode].label}</Badge>
              <Badge className="bg-slate-100 text-slate-700">{levelLabel(row.courseType)}</Badge>
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-4">
        <Card title="جدول کامل کلاس‌ها" subtitle="جستجو و مرتب‌سازی">
          <DataTable
            columns={[
              { key: "name", header: "کلاس" },
              { key: "courseType", header: "دوره" },
              { key: "teacherName", header: "استاد" },
              { key: "schedule", header: "برنامه" },
              { key: "mode", header: "نوع" },
              { key: "students", header: "قرآن‌آموزان", numeric: true },
              { key: "tuition", header: "شهریه", numeric: true },
            ]}
            rows={tableRows}
            searchPlaceholder="جستجو در کلاس‌ها..."
            linkLabel="جزئیات"
          />
        </Card>
      </div>
    </>
  );
}

async function StudentClassesView({ userId }: { userId: number }) {
  const student = await db
    .select({ id: students.id })
    .from(students)
    .where(eq(students.userId, userId))
    .limit(1);
  if (!student[0]) {
    return <EmptyState text="پرونده قرآن‌آموز یافت نشد." />;
  }

  const rows = await db
    .select({
      id: classes.id,
      name: classes.name,
      courseType: classes.courseType,
      days: classes.days,
      startTime: classes.startTime,
      durationMinutes: classes.durationMinutes,
      location: classes.location,
      mode: classes.mode,
      description: classes.description,
    })
    .from(enrollments)
    .innerJoin(classes, eq(classes.id, enrollments.classId))
    .where(eq(enrollments.studentId, student[0].id));

  const teacherRows = await db
    .select({ classId: classes.id, fullName: users.fullName })
    .from(classes)
    .leftJoin(users, eq(users.id, classes.teacherId));
  const teacherMap = new Map(teacherRows.map((row) => [row.classId, row.fullName]));

  return (
    <>
      <PageHeader title="برنامه کلاس‌های من" description="کلاس‌ها، استاد، زمان و مکان برگزاری" />
      <div className="grid gap-4 sm:grid-cols-2">
        {rows.length === 0 && <EmptyState text="در کلاسی ثبت‌نام نکرده‌اید." />}
        {rows.map((row) => (
          <Card key={row.id} title={row.name} subtitle={levelLabel(row.courseType)}>
            <ul className="space-y-1.5 text-sm text-slate-600">
              <li>استاد: {teacherMap.get(row.id) ?? "—"}</li>
              <li>
                {faDays(row.days)} — {faTime(row.startTime)} ({faDigits(row.durationMinutes)} دقیقه)
              </li>
              <li>مکان: {row.location}</li>
              <li>
                <Badge className={classModeMeta[row.mode].className}>{classModeMeta[row.mode].label}</Badge>
              </li>
            </ul>
            <p className="mt-3 text-xs leading-6 text-slate-500">{row.description}</p>
            <Link href={`/classes/${row.id}`} className="btn btn-ghost btn-sm mt-3">
              جزئیات کلاس
            </Link>
          </Card>
        ))}
      </div>
    </>
  );
}

async function ParentClassesView() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const childRows = await db
    .select({ id: students.id, fullName: users.fullName })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .where(eq(students.parentUserId, user.id));

  if (childRows.length === 0) {
    return (
      <>
        <PageHeader title="کلاس‌های فرزندان" />
        <EmptyState text="پرونده‌ای به حساب شما متصل نیست." />
      </>
    );
  }

  const rows = await db
    .select({
      studentName: users.fullName,
      className: classes.name,
      classId: classes.id,
      days: classes.days,
      startTime: classes.startTime,
      mode: classes.mode,
      teacherId: classes.teacherId,
    })
    .from(enrollments)
    .innerJoin(students, eq(students.id, enrollments.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .innerJoin(classes, eq(classes.id, enrollments.classId))
    .where(
      inArray(
        enrollments.studentId,
        childRows.map((child) => child.id),
      ),
    );

  const teacherRows = await db
    .select({ classId: classes.id, fullName: users.fullName })
    .from(classes)
    .leftJoin(users, eq(users.id, classes.teacherId));
  const teacherMap = new Map(teacherRows.map((row) => [row.classId, row.fullName]));

  return (
    <>
      <PageHeader title="کلاس‌های فرزندان" description="برنامه هفتگی کلاس‌های فرزندان شما" />
      <Card>
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>قرآن‌آموز</th>
                <th>کلاس</th>
                <th>روزها</th>
                <th>ساعت</th>
                <th>نوع</th>
                <th>استاد</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={`${row.classId}-${index}`}>
                  <td className="font-bold text-emerald-900">{row.studentName}</td>
                  <td>
                    <Link href={`/classes/${row.classId}`} className="hover:text-emerald-700">
                      {row.className}
                    </Link>
                  </td>
                  <td>{faDays(row.days)}</td>
                  <td>{faTime(row.startTime)}</td>
                  <td>{classModeMeta[row.mode].label}</td>
                  <td>{teacherMap.get(row.classId) ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
