import Link from "next/link";
import { redirect } from "next/navigation";
import {
  AlarmClock,
  Award,
  BookOpenCheck,
  CalendarDays,
  ClipboardList,
  GraduationCap,
  Mic,
  School,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";
import { Badge, Card, EmptyState, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { BarChart, LineChart, ProgressRing } from "@/components/charts";
import {
  getStudentByUserId,
  getTeacherByUserId,
  listNotifications,
  managerDashboard,
  parentDashboard,
  studentDashboard,
  teacherDashboard,
} from "@/lib/data";
import {
  attendanceMeta,
  classModeMeta,
  examTypeLabel,
  levelLabel,
  paymentStatusMeta,
} from "@/lib/labels";
import { faDate, faDateLong, faDigits, faMoney, faNum, faTime, faWeekday, todayISO } from "@/lib/jalali";
import { getCurrentUser, roleLabel } from "@/lib/session";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  if (user.role === "manager") return <ManagerView name={user.fullName} />;
  if (user.role === "teacher") return <TeacherView name={user.fullName} />;
  if (user.role === "student") return <StudentView name={user.fullName} />;
  return <ParentView name={user.fullName} />;
}

/* ------------------------------- مدیر ---------------------------------- */

async function ManagerView({ name }: { name: string }) {
  const data = await managerDashboard();
  const today = todayISO();

  return (
    <>
      <PageHeader
        title={`سلام ${name} 👋`}
        description={`داشبورد مدیریت مجموعه فرهنگی قرآنی معارج — ${faDateLong(today)}`}
        action={
          <Link href="/reports" className="btn btn-gold">
            گزارش هیئت امنا
          </Link>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="قرآن‌آموزان"
          value={faDigits(data.stats.students)}
          hint="فعال در دوره‌های جاری"
          icon={<Users className="h-6 w-6" />}
          href="/students"
        />
        <StatCard
          label="اساتید"
          value={faDigits(data.stats.teachers)}
          hint="با تخصص‌های متنوع قرآنی"
          icon={<GraduationCap className="h-6 w-6" />}
          tone="gold"
          href="/teachers"
        />
        <StatCard
          label="کلاس‌های فعال"
          value={faDigits(data.stats.activeClasses)}
          hint="حفظ، روخوانی، تجوید، قرائت، مفاهیم"
          icon={<School className="h-6 w-6" />}
          tone="sky"
          href="/classes"
        />
        <StatCard
          label="جلسات امروز"
          value={faDigits(data.stats.todaySessions)}
          hint="بر اساس برنامه هفتگی"
          icon={<AlarmClock className="h-6 w-6" />}
          tone="rose"
          href="/attendance"
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="روند رشد مؤسسه" subtitle="تعداد قرآن‌آموزان ثبت‌شده در ۶ ماه اخیر">
          <BarChart data={data.growth} unit="نفر" />
        </Card>
        <Card title="روند حضور در جلسات" subtitle="درصد حضور قرآن‌آموزان در ۶ جلسه اخیر">
          <LineChart data={data.attendanceTrend} />
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card
          title="یادآوری: جلسات امروز"
          subtitle={`${faDigits(data.todaySessions.length)} جلسه`}
          action={
            <Link href="/attendance" className="btn btn-ghost btn-sm">
              حضور و غیاب
            </Link>
          }
        >
          {data.todaySessions.length === 0 ? (
            <EmptyState text="امروز جلسه‌ای ثبت نشده است." icon={<CalendarDays className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {data.todaySessions.map((session) => (
                <li
                  key={session.id}
                  className="flex items-center justify-between gap-2 rounded-xl bg-slate-50 px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-emerald-900">{session.className}</p>
                    <p className="truncate text-xs text-slate-500">
                      {session.teacherName ?? "بدون استاد"} — {faTime(session.startTime)}
                    </p>
                  </div>
                  <Badge className={classModeMeta[session.mode].className}>
                    {classModeMeta[session.mode].label}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card
          title="شهریه‌های معوق"
          subtitle={`مجموع: ${faMoney(data.finance.overdue + data.finance.unpaid)}`}
          action={
            <Link href="/finance" className="btn btn-ghost btn-sm">
              امور مالی
            </Link>
          }
        >
          {data.overdueList.length === 0 ? (
            <EmptyState text="شهریه معوقی وجود ندارد ✓" icon={<Wallet className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {data.overdueList.slice(0, 5).map((item) => (
                <li key={item.id} className="rounded-xl bg-rose-50 px-3 py-2">
                  <p className="truncate text-sm font-bold text-rose-800">
                    {item.studentName ?? "—"} — {faMoney(item.amount)}
                  </p>
                  <p className="truncate text-xs text-rose-600">
                    {item.title} • سررسید {faDate(item.dueDate)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card
          title="آزمون‌ها و رویدادهای پیش‌رو"
          action={
            <Link href="/calendar" className="btn btn-ghost btn-sm">
              تقویم
            </Link>
          }
        >
          <ul className="space-y-2">
            {data.upcomingExams.map((exam) => (
              <li key={`exam-${exam.id}`} className="rounded-xl bg-amber-50 px-3 py-2">
                <p className="truncate text-sm font-bold text-amber-800">{exam.title}</p>
                <p className="truncate text-xs text-amber-600">
                  {exam.studentName} • {faDate(exam.examDate)}
                </p>
              </li>
            ))}
            {data.events.map((event) => (
              <li key={`event-${event.id}`} className="rounded-xl bg-emerald-50 px-3 py-2">
                <p className="truncate text-sm font-bold text-emerald-800">{event.title}</p>
                <p className="truncate text-xs text-emerald-600">{faDate(event.eventDate)}</p>
              </li>
            ))}
            {data.upcomingExams.length === 0 && data.events.length === 0 && (
              <EmptyState text="رویدادی ثبت نشده است." />
            )}
          </ul>
        </Card>
      </div>

      <div className="mt-4">
        <Card
          title="پیام‌های ثبت‌نام اخیر"
          subtitle="هر ثبت‌نام جدید بلافاصله برای مدیریت ارسال می‌شود"
          action={
            <Link href="/messages" className="btn btn-ghost btn-sm">
              صندوق پیام‌ها
            </Link>
          }
        >
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>نقش</th>
                  <th>موبایل</th>
                  <th>تاریخ عضویت</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {data.recentUsers.map((row) => (
                  <tr key={row.id}>
                    <td className="font-bold text-emerald-900">{row.fullName}</td>
                    <td>{roleLabel(row.role)}</td>
                    <td dir="ltr" className="font-mono text-xs">
                      {faDigits(row.mobile)}
                    </td>
                    <td>{faDate(row.createdAt)}</td>
                    <td>
                      {row.role === "student" ? (
                        <Link href="/students" className="btn btn-ghost btn-sm">
                          پرونده
                        </Link>
                      ) : row.role === "teacher" ? (
                        <Link href="/teachers" className="btn btn-ghost btn-sm">
                          پرونده
                        </Link>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </>
  );
}

/* ------------------------------- استاد --------------------------------- */

async function TeacherView({ name }: { name: string }) {
  const me = await getTeacherByUserId((await getCurrentUser())!.id);
  if (!me) {
    return <EmptyState text="پرونده استاد برای حساب شما یافت نشد. با مدیریت تماس بگیرید." />;
  }
  const data = await teacherDashboard(me.id);
  const today = todayISO();

  return (
    <>
      <PageHeader
        title={`سلام استاد ${name}`}
        description={`${faDateLong(today)} — ${faDigits(data.classes.length)} کلاس فعال`}
        action={
          <Link href="/attendance" className="btn btn-primary">
            ثبت حضور و غیاب
          </Link>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="کلاس‌های من" value={faDigits(data.classes.length)} icon={<School className="h-6 w-6" />} href="/classes" />
        <StatCard
          label="قرآن‌آموزان"
          value={faDigits(new Set(data.students.map((s) => s.studentId)).size)}
          icon={<Users className="h-6 w-6" />}
          tone="sky"
        />
        <StatCard
          label="جلسات امروز"
          value={faDigits(data.todaySessions.length)}
          icon={<AlarmClock className="h-6 w-6" />}
          tone="gold"
          href="/attendance"
        />
        <StatCard
          label="میانگین حضور"
          value={`${faDigits(data.attendanceRate)}٪`}
          icon={<ClipboardList className="h-6 w-6" />}
          tone="emerald"
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card title="کلاس‌های من" className="lg:col-span-2">
          {data.classes.length === 0 ? (
            <EmptyState text="هنوز کلاسی به شما انتصاب نشده است." />
          ) : (
            <ul className="grid gap-3 sm:grid-cols-2">
              {data.classes.map((cls) => (
                <li key={cls.id}>
                  <Link
                    href={`/classes/${cls.id}`}
                    className="card card-hover block p-4 transition"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate font-extrabold text-emerald-900">{cls.name}</p>
                      <Badge className={classModeMeta[cls.mode].className}>
                        {classModeMeta[cls.mode].label}
                      </Badge>
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      {levelLabel(cls.courseType)} • {faTime(cls.startTime)} • {cls.location}
                    </p>
                    <p className="mt-2 text-xs font-bold text-emerald-700">
                      {faDigits(
                        data.students.filter((s) => s.classId === cls.id).length,
                      )}{" "}
                      قرآن‌آموز
                    </p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card
          title="تلاوت‌های در انتظار تصحیح"
          subtitle={`${faDigits(data.pendingRecordings.length)} فایل`}
          action={
            <Link href="/recordings" className="btn btn-ghost btn-sm">
              تصحیح
            </Link>
          }
        >
          {data.pendingRecordings.length === 0 ? (
            <EmptyState text="تلاوتی در انتظار تصحیح نیست ✓" icon={<Mic className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {data.pendingRecordings.map((item) => (
                <li key={item.id} className="rounded-xl bg-amber-50 px-3 py-2">
                  <p className="truncate text-sm font-bold text-amber-800">{item.title}</p>
                  <p className="truncate text-xs text-amber-600">{item.studentName}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="mt-4">
        <Card title="آخرین نمرات ثبت‌شده" action={<Link href="/exams" className="btn btn-ghost btn-sm">ثبت نمره</Link>}>
          {data.examRows.length === 0 ? (
            <EmptyState text="نمره‌ای ثبت نشده است." icon={<BookOpenCheck className="h-6 w-6" />} />
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>قرآن‌آموز</th>
                    <th>آزمون</th>
                    <th>تاریخ</th>
                    <th>نمره</th>
                  </tr>
                </thead>
                <tbody>
                  {data.examRows.map((exam) => (
                    <tr key={exam.id}>
                      <td className="font-bold text-emerald-900">{exam.studentName}</td>
                      <td>{exam.title}</td>
                      <td>{faDate(exam.examDate)}</td>
                      <td className="font-bold">
                        {faDigits(exam.score)} از {faDigits(exam.maxScore)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}

/* ---------------------------- قرآن‌آموز -------------------------------- */

async function StudentView({ name }: { name: string }) {
  const me = await getStudentByUserId((await getCurrentUser())!.id);
  if (!me) {
    return <EmptyState text="پرونده قرآن‌آموز برای حساب شما یافت نشد." />;
  }
  const data = await studentDashboard(me.id);
  if (!data) return <EmptyState text="داده‌ای یافت نشد." />;
  const today = todayISO();

  return (
    <>
      <PageHeader
        title={`سلام ${name}`}
        description={`${faDateLong(today)} — سطح فعلی: ${levelLabel(me.level)}`}
        action={
          <Link href="/recordings" className="btn btn-gold">
            آپلود صوت تلاوت
          </Link>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="نوار پیشرفت حفظ" className="lg:col-span-2">
          <div className="flex flex-col items-center gap-5 sm:flex-row">
            <ProgressRing percent={data.summary.percent} label="پیشرفت کل قرآن کریم" />
            <div className="w-full space-y-3">
              <div>
                <p className="mb-1 text-xs font-bold text-slate-500">
                  صفحات حفظ‌شده: {faDigits(data.summary.memorized)} از {faDigits(604)}
                </p>
                <ProgressBar value={data.summary.memorized} max={604} />
              </div>
              <div>
                <p className="mb-1 text-xs font-bold text-slate-500">
                  در حال حفظ: {faDigits(data.summary.inProgress)} صفحه
                </p>
                <ProgressBar value={data.summary.inProgress} max={20} tone="gold" />
              </div>
              <Link href="/hifz" className="btn btn-ghost btn-sm">
                مشاهده مسیر حفظ صفحه‌به‌صفحه
              </Link>
            </div>
          </div>
        </Card>

        <Card title="جلسات امروز">
          {data.todaySessions.length === 0 ? (
            <EmptyState text="امروز جلسه‌ای ندارید." icon={<CalendarDays className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {data.todaySessions.map((session) => (
                <li key={session.id} className="rounded-xl bg-emerald-50 px-3 py-2">
                  <p className="truncate text-sm font-bold text-emerald-900">{session.className}</p>
                  <p className="text-xs text-emerald-700">
                    {faWeekday(session.sessionDate)} • {faTime(session.startTime)}
                  </p>
                </li>
              ))}
            </ul>
          )}
          {data.debt > 0 && (
            <div className="mt-4 rounded-xl bg-rose-50 px-3 py-2">
              <p className="text-xs font-bold text-rose-700">شهریه پرداخت‌نشده</p>
              <p className="text-sm font-extrabold text-rose-800">{faMoney(data.debt)}</p>
              <Link href="/finance" className="btn btn-danger btn-sm mt-2">
                پرداخت آنلاین
              </Link>
            </div>
          )}
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="آزمون‌های پیش‌رو">
          {data.upcomingExams.length === 0 ? (
            <EmptyState text="آزمونی در پیش نیست." />
          ) : (
            <ul className="space-y-2">
              {data.upcomingExams.map((exam) => (
                <li key={exam.id} className="rounded-xl bg-amber-50 px-3 py-2">
                  <p className="truncate text-sm font-bold text-amber-800">{exam.title}</p>
                  <p className="text-xs text-amber-600">
                    {examTypeLabel(exam.examType)} • {faDate(exam.examDate)}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card
          title="کارنامه آخرین آزمون‌ها"
          action={
            <Link href="/exams" className="btn btn-ghost btn-sm">
              همه آزمون‌ها
            </Link>
          }
        >
          {data.recentExams.length === 0 ? (
            <EmptyState text="نمره‌ای ثبت نشده است." />
          ) : (
            <ul className="space-y-2">
              {data.recentExams.map((exam) => (
                <li key={exam.id} className="rounded-xl border border-slate-200 px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-bold text-emerald-900">{exam.title}</p>
                    <Badge className="bg-emerald-50 text-emerald-700">
                      {faDigits(exam.score)}/{faDigits(exam.maxScore)}
                    </Badge>
                  </div>
                  {exam.feedback && <p className="mt-1 text-xs text-slate-500">{exam.feedback}</p>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}

/* -------------------------------- ولی ---------------------------------- */

async function ParentView({ name }: { name: string }) {
  const user = (await getCurrentUser())!;
  const data = await parentDashboard(user.id);
  const notifications = await listNotifications(user.id);
  const today = todayISO();

  return (
    <>
      <PageHeader
        title={`سلام ${name}`}
        description={`گزارش پیشرفت فرزندان — ${faDateLong(today)}`}
        action={
          <Link href="/finance" className="btn btn-gold">
            پرداخت شهریه
          </Link>
        }
      />

      {data.children.length === 0 ? (
        <Card title="فرزندی به پرونده شما متصل نیست">
          <EmptyState
            text="برای اتصال پرونده فرزند، با مدیریت مجموعه تماس بگیرید یا کد ملی فرزند را در پرونده ثبت کنید."
            icon={<Users className="h-6 w-6" />}
          />
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {data.children.map((child) => {
            const childHifz = data.hifz.filter((row) => row.studentId === child.id);
            const memorized = childHifz.filter(
              (row) => row.status === "memorized" || row.status === "stable",
            ).length;
            const childExams = data.exams.filter((exam) => exam.studentId === child.id).slice(0, 3);
            const childAttendance = data.attendance.filter((row) => row.studentId === child.id);
            const present = childAttendance.filter(
              (row) => row.status === "present" || row.status === "late",
            ).length;
            const rate = childAttendance.length
              ? Math.round((present / childAttendance.length) * 100)
              : 0;
            const average = childExams.length
              ? Math.round(
                  (childExams.reduce(
                    (sum, exam) => sum + exam.score / Math.max(exam.maxScore, 1),
                    0,
                  ) /
                    childExams.length) *
                    100,
                )
              : null;

            return (
              <Card
                key={child.id}
                title={child.fullName}
                subtitle={`سطح ${levelLabel(child.level)} • عضویت از ${faDate(child.joinDate)}`}
                action={
                  <Link href={`/students/${child.id}`} className="btn btn-ghost btn-sm">
                    کارنامه کامل
                  </Link>
                }
              >
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-xl bg-slate-50 p-3 text-center">
                    <ProgressRing percent={Math.round((memorized / 604) * 100)} size={90} />
                    <p className="mt-1 text-[11px] font-bold text-slate-500">پیشرفت حفظ</p>
                  </div>
                  <div className="rounded-xl bg-slate-50 p-3 text-center">
                    <ProgressRing percent={rate} size={90} />
                    <p className="mt-1 text-[11px] font-bold text-slate-500">میانگین حضور</p>
                  </div>
                  <div className="rounded-xl bg-slate-50 p-3 text-center">
                    <ProgressRing percent={average ?? 0} size={90} />
                    <p className="mt-1 text-[11px] font-bold text-slate-500">میانگین نمرات</p>
                  </div>
                </div>
                {childExams.length > 0 && (
                  <ul className="mt-3 space-y-2">
                    {childExams.map((exam) => (
                      <li key={exam.id} className="rounded-xl border border-slate-200 px-3 py-2">
                        <div className="flex items-center justify-between gap-2">
                          <p className="truncate text-sm font-bold text-emerald-900">{exam.title}</p>
                          <Badge className="bg-emerald-50 text-emerald-700">
                            {faDigits(exam.score)}/{faDigits(exam.maxScore)}
                          </Badge>
                        </div>
                        <p className="mt-0.5 text-xs text-slate-500">
                          {examTypeLabel(exam.examType)} • {faDate(exam.examDate)}
                        </p>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card
          title="وضعیت پرداخت‌ها"
          subtitle={`مجموع بدهی: ${faMoney(data.debt)}`}
          action={
            <Link href="/finance" className="btn btn-ghost btn-sm">
              پرداخت
            </Link>
          }
        >
          {data.payments.length === 0 ? (
            <EmptyState text="پرداختی ثبت نشده است." icon={<Wallet className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {data.payments.slice(0, 6).map((payment) => (
                <li
                  key={payment.id}
                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 px-3 py-2"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-emerald-900">{payment.title}</p>
                    <p className="text-xs text-slate-500">
                      {faMoney(payment.amount)} • سررسید {faDate(payment.dueDate)}
                    </p>
                  </div>
                  <Badge className={paymentStatusMeta[payment.status].className}>
                    {paymentStatusMeta[payment.status].label}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card
          title="آخرین اعلان‌ها"
          action={
            <Link href="/messages" className="btn btn-ghost btn-sm">
              همه پیام‌ها
            </Link>
          }
        >
          {notifications.length === 0 ? (
            <EmptyState text="اعلانی ندارید." icon={<Award className="h-6 w-6" />} />
          ) : (
            <ul className="space-y-2">
              {notifications.slice(0, 5).map((item) => (
                <li
                  key={item.id}
                  className={`rounded-xl px-3 py-2 ${
                    item.isRead ? "bg-slate-50" : "bg-emerald-50"
                  }`}
                >
                  <p className="truncate text-sm font-bold text-emerald-900">{item.title}</p>
                  <p className="line-clamp-2 text-xs text-slate-500">{item.body}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {data.classRows.length > 0 && (
        <div className="mt-4">
          <Card title="برنامه کلاس‌های فرزندان">
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>قرآن‌آموز</th>
                    <th>کلاس</th>
                    <th>روزها</th>
                    <th>ساعت</th>
                    <th>نوع</th>
                    <th>استاد</th>
                  </tr>
                </thead>
                <tbody>
                  {data.classRows.map((row, index) => (
                    <tr key={`${row.studentId}-${index}`}>
                      <td className="font-bold text-emerald-900">{row.studentName}</td>
                      <td>{row.className}</td>
                      <td>{row.days}</td>
                      <td>{faTime(row.startTime)}</td>
                      <td>{classModeMeta[row.mode].label}</td>
                      <td>{row.teacherName ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}
