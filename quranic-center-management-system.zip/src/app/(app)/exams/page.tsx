import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, desc, eq, inArray } from "drizzle-orm";
import { Award, BookOpenCheck } from "lucide-react";
import { db } from "@/db";
import { classes, enrollments, exams, students, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { ExamForm } from "@/components/teaching-forms";
import { examTypeLabel } from "@/lib/labels";
import { faDate, faDateLong, faDigits } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ExamsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  if (user.role === "student") return <StudentExamsView userId={user.id} />;
  if (user.role === "parent") return <ParentExamsView />;

  const teacherClassIds =
    user.role === "teacher"
      ? (await db.select({ id: classes.id }).from(classes).where(eq(classes.teacherId, user.id))).map(
          (row) => row.id,
        )
      : null;

  const classRows = await db
    .select({ id: classes.id, name: classes.name, teacherId: classes.teacherId })
    .from(classes)
    .orderBy(asc(classes.name));
  const scopedClasses =
    user.role === "teacher" ? classRows.filter((row) => teacherClassIds?.includes(row.id)) : classRows;

  const examRows = await db
    .select({
      id: exams.id,
      title: exams.title,
      examType: exams.examType,
      examDate: exams.examDate,
      score: exams.score,
      maxScore: exams.maxScore,
      feedback: exams.feedback,
      studentId: exams.studentId,
      studentName: users.fullName,
      className: classes.name,
      classId: exams.classId,
    })
    .from(exams)
    .innerJoin(students, eq(students.id, exams.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .leftJoin(classes, eq(classes.id, exams.classId))
    .orderBy(desc(exams.examDate));

  const scopedExams =
    user.role === "teacher" ? examRows.filter((row) => teacherClassIds?.includes(row.classId ?? -1)) : examRows;

  const studentRows =
    user.role === "teacher" && teacherClassIds?.length
      ? await db
          .select({ id: students.id, fullName: users.fullName })
          .from(enrollments)
          .innerJoin(students, eq(students.id, enrollments.studentId))
          .innerJoin(users, eq(users.id, students.userId))
          .where(inArray(enrollments.classId, teacherClassIds))
          .orderBy(asc(users.fullName))
      : await db
          .select({ id: students.id, fullName: users.fullName })
          .from(students)
          .innerJoin(users, eq(users.id, students.userId))
          .orderBy(asc(users.fullName));

  const average = (() => {
    if (scopedExams.length === 0) return 0;
    return Math.round(
      (scopedExams.reduce((sum, exam) => sum + exam.score / Math.max(exam.maxScore, 1), 0) /
        scopedExams.length) *
        100,
    );
  })();

  return (
    <>
      <PageHeader
        title="ارزشیابی و آزمون‌ها"
        description="ثبت نتایج آزمون حفظ: صفحه جدید، تثبیت، کل جزء و نمره شفاهی با بازخورد استاد"
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="تعداد آزمون‌ها" value={faDigits(scopedExams.length)} icon={<BookOpenCheck className="h-6 w-6" />} />
        <StatCard label="میانگین نمرات" value={`${faDigits(average)}٪`} tone="emerald" icon={<Award className="h-6 w-6" />} />
        <StatCard
          label="آزمون‌های این ماه"
          value={faDigits(scopedExams.filter((e) => e.examDate.slice(0, 7) === new Date().toISOString().slice(0, 7)).length)}
          tone="gold"
          icon={<BookOpenCheck className="h-6 w-6" />}
        />
        <StatCard label="قرآن‌آموزان ارزیابی‌شده" value={faDigits(new Set(scopedExams.map((e) => e.studentId)).size)} tone="sky" icon={<Award className="h-6 w-6" />} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-5">
        <div className="xl:col-span-2">
          <ExamForm
            students={studentRows}
            classes={scopedClasses.map((row) => ({ id: row.id, name: row.name }))}
          />
        </div>
        <Card title="نتایج ثبت‌شده" subtitle="جدول کامل نتایج آزمون‌ها" className="xl:col-span-3" padded={false}>
          {scopedExams.length === 0 ? (
            <div className="p-5">
              <EmptyState text="آزمونی ثبت نشده است." icon={<BookOpenCheck className="h-6 w-6" />} />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>قرآن‌آموز</th>
                    <th>آزمون</th>
                    <th>نوع</th>
                    <th>کلاس</th>
                    <th>تاریخ</th>
                    <th>نمره</th>
                    <th>بازخورد</th>
                  </tr>
                </thead>
                <tbody>
                  {scopedExams.map((exam) => (
                    <tr key={exam.id}>
                      <td>
                        <Link
                          href={`/students/${exam.studentId}`}
                          className="font-bold text-emerald-900 hover:underline"
                        >
                          {exam.studentName}
                        </Link>
                      </td>
                      <td>{exam.title}</td>
                      <td>
                        <Badge className="bg-amber-50 text-amber-800">{examTypeLabel(exam.examType)}</Badge>
                      </td>
                      <td>{exam.className ?? "—"}</td>
                      <td>{faDate(exam.examDate)}</td>
                      <td className="font-bold">
                        {faDigits(exam.score)}/{faDigits(exam.maxScore)}
                      </td>
                      <td className="max-w-xs text-xs text-slate-500">{exam.feedback || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </>
  );
}

async function StudentExamsView({ userId }: { userId: number }) {
  const studentRows = await db
    .select({ id: students.id })
    .from(students)
    .where(eq(students.userId, userId))
    .limit(1);
  if (!studentRows[0]) return <EmptyState text="پرونده یافت نشد." />;

  const rows = await db
    .select({
      id: exams.id,
      title: exams.title,
      examType: exams.examType,
      examDate: exams.examDate,
      score: exams.score,
      maxScore: exams.maxScore,
      feedback: exams.feedback,
      className: classes.name,
    })
    .from(exams)
    .leftJoin(classes, eq(classes.id, exams.classId))
    .where(eq(exams.studentId, studentRows[0].id))
    .orderBy(desc(exams.examDate));

  const average = rows.length
    ? Math.round(
        (rows.reduce((sum, exam) => sum + exam.score / Math.max(exam.maxScore, 1), 0) / rows.length) * 100,
      )
    : 0;

  return (
    <>
      <PageHeader
        title="کارنامه آزمون‌های من"
        description={`آخرین به‌روزرسانی: ${faDateLong(new Date())}`}
      />
      <Card title="میانگین کل" className="mb-4">
        <ProgressBar value={average} />
        <p className="mt-2 text-sm font-bold text-emerald-900">{faDigits(average)}٪ میانگین نمرات</p>
      </Card>
      <Card title="فهرست آزمون‌ها" padded={false}>
        {rows.length === 0 ? (
          <div className="p-5">
            <EmptyState text="آزمونی ثبت نشده است." />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>آزمون</th>
                  <th>نوع</th>
                  <th>کلاس</th>
                  <th>تاریخ</th>
                  <th>نمره</th>
                  <th>بازخورد استاد</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((exam) => (
                  <tr key={exam.id}>
                    <td className="font-bold text-emerald-900">{exam.title}</td>
                    <td>{examTypeLabel(exam.examType)}</td>
                    <td>{exam.className ?? "—"}</td>
                    <td>{faDate(exam.examDate)}</td>
                    <td className="font-bold">
                      {faDigits(exam.score)}/{faDigits(exam.maxScore)}
                    </td>
                    <td className="max-w-sm text-xs text-slate-500">{exam.feedback || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  );
}

async function ParentExamsView() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const children = await db
    .select({ id: students.id, fullName: users.fullName })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .where(eq(students.parentUserId, user.id));

  if (children.length === 0) {
    return (
      <>
        <PageHeader title="کارنامه فرزندان" />
        <EmptyState text="پرونده‌ای به حساب شما متصل نیست." />
      </>
    );
  }

  const rows = await db
    .select({
      id: exams.id,
      title: exams.title,
      examType: exams.examType,
      examDate: exams.examDate,
      score: exams.score,
      maxScore: exams.maxScore,
      feedback: exams.feedback,
      studentName: users.fullName,
      studentId: exams.studentId,
    })
    .from(exams)
    .innerJoin(students, eq(students.id, exams.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .where(
      inArray(
        exams.studentId,
        children.map((child) => child.id),
      ),
    )
    .orderBy(desc(exams.examDate));

  return (
    <>
      <PageHeader title="کارنامه فرزندان" description="نتایج آزمون‌ها و بازخورد اساتید" />
      {children.map((child) => {
        const childExams = rows.filter((row) => row.studentId === child.id);
        const average = childExams.length
          ? Math.round(
              (childExams.reduce((sum, exam) => sum + exam.score / Math.max(exam.maxScore, 1), 0) /
                childExams.length) *
                100,
            )
          : 0;
        return (
          <Card key={child.id} title={child.fullName} subtitle={`میانگین: ${faDigits(average)}٪`} className="mb-4">
            <ProgressBar value={average} />
            {childExams.length === 0 ? (
              <p className="mt-3 text-sm text-slate-500">آزمونی ثبت نشده است.</p>
            ) : (
              <ul className="mt-3 space-y-2">
                {childExams.map((exam) => (
                  <li key={exam.id} className="rounded-xl border border-slate-200 px-3 py-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-bold text-emerald-900">{exam.title}</p>
                      <Badge className="bg-emerald-50 text-emerald-700">
                        {faDigits(exam.score)}/{faDigits(exam.maxScore)}
                      </Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {examTypeLabel(exam.examType)} • {faDate(exam.examDate)}
                    </p>
                    {exam.feedback && <p className="mt-1 text-xs text-slate-600">{exam.feedback}</p>}
                  </li>
                ))}
              </ul>
            )}
            <Link href={`/students/${child.id}`} className="btn btn-ghost btn-sm mt-3">
              کارنامه کامل
            </Link>
          </Card>
        );
      })}
    </>
  );
}
