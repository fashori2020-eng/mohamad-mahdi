import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { Download, Wallet } from "lucide-react";
import { db } from "@/db";
import { students, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { DonationForm, PaymentActions, PaymentCreator } from "@/components/admin-forms";
import { financeTotals, listPayments } from "@/lib/data";
import { paymentKindLabel, paymentStatusMeta } from "@/lib/labels";
import { faDate, faDigits, faMoney } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function FinancePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "teacher") redirect("/dashboard");

  const allRows = await listPayments();
  const studentRows = await db
    .select({ id: students.id, fullName: users.fullName })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .orderBy(asc(users.fullName));

  if (user.role === "parent") {
    const childRows = await db
      .select({ id: students.id, fullName: users.fullName })
      .from(students)
      .where(eq(students.parentUserId, user.id));
    const childIds = new Set(childRows.map((child) => child.id));
    const myRows = allRows.filter(
      (row) =>
        (row.studentId && childIds.has(row.studentId)) || row.parentUserId === user.id,
    );
    const debt = myRows.filter((row) => row.status !== "paid").reduce((sum, row) => sum + row.amount, 0);
    const paid = myRows
      .filter((row) => row.status === "paid")
      .reduce((sum, row) => sum + row.amount, 0);

    return (
      <>
        <PageHeader
          title="پرداخت‌ها و شهریه"
          description="پرداخت آنلاین شهریه، مشاهده وضعیت بدهی و کمک به هیئت امنا"
        />
        <div className="grid gap-3 sm:grid-cols-3">
          <StatCard label="بدهی جاری" value={faMoney(debt)} tone={debt > 0 ? "rose" : "emerald"} icon={<Wallet className="h-6 w-6" />} />
          <StatCard label="پرداخت‌شده" value={faMoney(paid)} tone="emerald" icon={<Wallet className="h-6 w-6" />} />
          <StatCard label="تعداد فقره" value={faDigits(myRows.length)} tone="sky" icon={<Wallet className="h-6 w-6" />} />
        </div>

        <div className="mt-4">
          <Card title="فهرست پرداخت‌ها" padded={false}>
            {myRows.length === 0 ? (
              <div className="p-5">
                <EmptyState text="پرداختی ثبت نشده است." />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th>عنوان</th>
                      <th>مبلغ</th>
                      <th>سررسید</th>
                      <th>وضعیت</th>
                      <th>کد پیگیری</th>
                      <th>عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {myRows.map((row) => (
                      <tr key={row.id}>
                        <td className="font-bold text-emerald-900">{row.title}</td>
                        <td>{faMoney(row.amount)}</td>
                        <td>{faDate(row.dueDate)}</td>
                        <td>
                          <Badge className={paymentStatusMeta[row.status].className}>
                            {paymentStatusMeta[row.status].label}
                          </Badge>
                        </td>
                        <td dir="ltr" className="font-mono text-xs">
                          {row.trackingCode || "—"}
                        </td>
                        <td>
                          <PaymentActions paymentId={row.id} status={row.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        <div className="mt-4">
          <DonationForm />
        </div>
      </>
    );
  }

  const totals = await financeTotals();
  const overdue = allRows.filter((row) => row.status === "overdue");
  const thisMonth = allRows.filter(
    (row) => row.status === "paid" && (row.paidAt ?? new Date(0)).toISOString().slice(0, 7) === new Date().toISOString().slice(0, 7),
  );

  return (
    <>
      <PageHeader
        title="امور مالی"
        description="مدیریت شهریه‌ها، بدهکاری‌ها و کمک‌های هیئت امنا"
        action={
          <a href="/api/export?type=payments" className="btn btn-gold">
            <Download className="h-4 w-4" />
            خروجی اکسل (CSV)
          </a>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="کل دریافت‌شده" value={faMoney(totals.paid)} tone="emerald" icon={<Wallet className="h-6 w-6" />} />
        <StatCard label="در انتظار پرداخت" value={faMoney(totals.unpaid)} tone="gold" icon={<Wallet className="h-6 w-6" />} />
        <StatCard label="معوق" value={faMoney(totals.overdue)} tone="rose" icon={<Wallet className="h-6 w-6" />} />
        <StatCard
          label="دریافت ماه جاری"
          value={faMoney(thisMonth.reduce((sum, row) => sum + row.amount, 0))}
          tone="sky"
          icon={<Wallet className="h-6 w-6" />}
        />
      </div>

      {overdue.length > 0 && (
        <div className="mt-4">
          <Card title="یادآوری شهریه‌های معوق" subtitle="ارسال اعلان به اولیا از بخش پیام‌رسانی">
            <ul className="grid gap-2 sm:grid-cols-2">
              {overdue.map((row) => (
                <li key={row.id} className="rounded-xl bg-rose-50 px-3 py-2">
                  <p className="text-sm font-bold text-rose-800">
                    {row.studentName ?? "کمک مالی"} — {faMoney(row.amount)}
                  </p>
                  <p className="text-xs text-rose-600">
                    {row.title} • سررسید {faDate(row.dueDate)}
                  </p>
                </li>
              ))}
            </ul>
            <Link href="/messages" className="btn btn-ghost btn-sm mt-3">
              ارسال یادآوری
            </Link>
          </Card>
        </div>
      )}

      <div className="mt-4">
        <PaymentCreator students={studentRows} />
      </div>

      <div className="mt-4">
        <Card title="فهرست کامل پرداخت‌ها" padded={false}>
          {allRows.length === 0 ? (
            <div className="p-5">
              <EmptyState text="موردی ثبت نشده است." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>عنوان</th>
                    <th>نوع</th>
                    <th>قرآن‌آموز</th>
                    <th>مبلغ</th>
                    <th>سررسید</th>
                    <th>وضعیت</th>
                    <th>روش پرداخت</th>
                    <th>عملیات</th>
                  </tr>
                </thead>
                <tbody>
                  {allRows.map((row) => (
                    <tr key={row.id}>
                      <td className="font-bold text-emerald-900">{row.title}</td>
                      <td>{paymentKindLabel[row.kind]}</td>
                      <td>{row.studentName ?? "—"}</td>
                      <td className="font-bold">{faMoney(row.amount)}</td>
                      <td>{faDate(row.dueDate)}</td>
                      <td>
                        <Badge className={paymentStatusMeta[row.status].className}>
                          {paymentStatusMeta[row.status].label}
                        </Badge>
                      </td>
                      <td className="text-xs text-slate-500">{row.method || "—"}</td>
                      <td>
                        <PaymentActions paymentId={row.id} status={row.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      <div className="mt-4">
        <DonationForm />
      </div>
    </>
  );
}


