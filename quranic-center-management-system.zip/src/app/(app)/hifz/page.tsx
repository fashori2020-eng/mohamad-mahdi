import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, eq, inArray } from "drizzle-orm";
import { Sparkles } from "lucide-react";
import { db } from "@/db";
import { classes, enrollments, hifzProgress, students, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { HifzGrid } from "@/components/teaching-forms";
import { hifzSummary } from "@/lib/data";
import { levelLabel } from "@/lib/labels";
import { faDigits } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function HifzPage({
  searchParams,
}: {
  searchParams: Promise<{ student?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const params = await searchParams;

  let options: { id: number; fullName: string; level: string }[] = [];
  if (user.role === "manager") {
    options = await db
      .select({ id: students.id, fullName: users.fullName, level: students.level })
      .from(students)
      .innerJoin(users, eq(users.id, students.userId))
      .orderBy(asc(users.fullName));
  } else if (user.role === "teacher") {
    const myClasses = await db
      .select({ id: classes.id })
      .from(classes)
      .where(eq(classes.teacherId, user.id));
    const ids = myClasses.map((row) => row.id);
    options = ids.length
      ? await db
          .select({ id: students.id, fullName: users.fullName, level: students.level })
          .from(enrollments)
          .innerJoin(students, eq(students.id, enrollments.studentId))
          .innerJoin(users, eq(users.id, students.userId))
          .where(inArray(enrollments.classId, ids))
          .orderBy(asc(users.fullName))
      : [];
  } else if (user.role === "student") {
    options = await db
      .select({ id: students.id, fullName: users.fullName, level: students.level })
      .from(students)
      .innerJoin(users, eq(users.id, students.userId))
      .where(eq(students.userId, user.id));
  } else {
    options = await db
      .select({ id: students.id, fullName: users.fullName, level: students.level })
      .from(students)
      .innerJoin(users, eq(users.id, students.userId))
      .where(eq(students.parentUserId, user.id));
  }

  if (options.length === 0) {
    return (
      <>
        <PageHeader title="مسیر حفظ" />
        <EmptyState
          text="قرآن‌آموزی برای نمایش مسیر حفظ یافت نشد."
          icon={<Sparkles className="h-6 w-6" />}
        />
      </>
    );
  }

  const selectedId = params.student ? Number(params.student) : options[0].id;
  const selected = options.find((option) => option.id === selectedId) ?? options[0];

  const rows = await db
    .select({ juz: hifzProgress.juz, page: hifzProgress.page, status: hifzProgress.status })
    .from(hifzProgress)
    .where(eq(hifzProgress.studentId, selected.id))
    .orderBy(asc(hifzProgress.juz), asc(hifzProgress.page));

  const summary = hifzSummary(rows);
  const editable = user.role === "manager" || user.role === "teacher";

  return (
    <>
      <PageHeader
        title="مسیر حفظ قرآن کریم"
        description="نوار پیشرفت صفحه‌به‌صفحه و جزء‌به‌جزء — کل قرآن ۶۰۴ صفحه و ۳۰ جزء"
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="صفحات حفظ‌شده"
          value={`${faDigits(summary.memorized)} / ${faDigits(604)}`}
          icon={<Sparkles className="h-6 w-6" />}
        />
        <StatCard label="در حال حفظ" value={faDigits(summary.inProgress)} tone="gold" icon={<Sparkles className="h-6 w-6" />} />
        <StatCard label="صفحات باقی‌مانده" value={faDigits(summary.remaining)} tone="sky" icon={<Sparkles className="h-6 w-6" />} />
        <StatCard label="درصد پیشرفت" value={`${faDigits(summary.percent)}٪`} tone="emerald" icon={<Sparkles className="h-6 w-6" />} />
      </div>

      {options.length > 1 && (
        <div className="mt-4">
          <Card title="انتخاب قرآن‌آموز">
            <div className="flex flex-wrap gap-2">
              {options.map((option) => (
                <Link
                  key={option.id}
                  href={`/hifz?student=${option.id}`}
                  className={`rounded-xl border px-3 py-1.5 text-xs font-bold transition ${
                    option.id === selected.id
                      ? "border-emerald-600 bg-emerald-600 text-white"
                      : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300"
                  }`}
                >
                  {option.fullName} — {levelLabel(option.level)}
                </Link>
              ))}
            </div>
          </Card>
        </div>
      )}

      <div className="mt-4">
        <Card title="خلاصه پیشرفت" subtitle={`${selected.fullName} — سطح ${levelLabel(selected.level)}`}>
          <ProgressBar value={summary.memorized} max={604} />
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge className="bg-slate-100 text-slate-600">شروع نشده</Badge>
            <Badge className="bg-amber-100 text-amber-800">در حال حفظ</Badge>
            <Badge className="bg-emerald-100 text-emerald-800">حفظ شده</Badge>
            <Badge className="bg-teal-700 text-white">تثبیت‌شده</Badge>
          </div>
        </Card>
      </div>

      <div className="mt-4">
        <HifzGrid
          studentId={selected.id}
          studentName={selected.fullName}
          rows={rows}
          editable={editable}
        />
      </div>
    </>
  );
}
