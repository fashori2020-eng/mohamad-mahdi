import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import { getUnreadCount } from "@/lib/data";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const unread = await getUnreadCount(user.id);

  return (
    <AppShell user={{ id: user.id, fullName: user.fullName, role: user.role }} unread={unread}>
      {children}
    </AppShell>
  );
}
