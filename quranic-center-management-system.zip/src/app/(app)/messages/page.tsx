import { redirect } from "next/navigation";
import { asc } from "drizzle-orm";
import { Bell, BellRing } from "lucide-react";
import { db } from "@/db";
import { users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader } from "@/components/ui";
import { MarkAllReadButton, MessageComposer } from "@/components/admin-forms";
import { listNotifications } from "@/lib/data";
import { notificationKindLabel } from "@/lib/labels";
import { faDate, faDigits } from "@/lib/jalali";
import { getCurrentUser, roleLabel } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function MessagesPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const rows = await listNotifications(user.id);
  const unread = rows.filter((row) => !row.isRead).length;

  const people =
    user.role === "manager"
      ? await db
          .select({ id: users.id, fullName: users.fullName, role: users.role })
          .from(users)
          .orderBy(asc(users.fullName))
      : [];

  return (
    <>
      <PageHeader
        title="پیام‌رسانی"
        description="اعلان‌های غیبت، آزمون‌ها، پرداخت‌ها و پیام‌های مدیریت"
        action={<MarkAllReadButton />}
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-50 text-emerald-700">
              <Bell className="h-5 w-5" />
            </span>
            <div>
              <p className="text-xs font-bold text-slate-500">کل پیام‌ها</p>
              <p className="text-xl font-extrabold text-emerald-900">{faDigits(rows.length)}</p>
            </div>
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-amber-50 text-amber-700">
              <BellRing className="h-5 w-5" />
            </span>
            <div>
              <p className="text-xs font-bold text-slate-500">خوانده‌نشده</p>
              <p className="text-xl font-extrabold text-emerald-900">{faDigits(unread)}</p>
            </div>
          </div>
        </Card>
        <Card>
          <p className="text-xs font-bold text-slate-500">کانال ارسال</p>
          <p className="mt-1 text-sm font-bold text-emerald-900">
            پیام درون‌برنامه‌ای + پوش‌نوتیفیکیشن (آماده اتصال به سرویس پیامک)
          </p>
        </Card>
      </div>

      {user.role === "manager" && (
        <div className="mt-4">
          <MessageComposer
            people={people.map((person) => ({
              id: person.id,
              fullName: person.fullName,
              role: roleLabel(person.role),
            }))}
          />
        </div>
      )}

      <div className="mt-4 space-y-3">
        {rows.length === 0 ? (
          <EmptyState text="پیامی دریافت نکرده‌اید." icon={<Bell className="h-6 w-6" />} />
        ) : (
          rows.map((row) => (
            <article
              key={row.id}
              className={`card p-4 ${row.isRead ? "" : "border-emerald-300 bg-emerald-50/40"}`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-extrabold text-emerald-900">{row.title}</h3>
                <div className="flex items-center gap-2">
                  <Badge className="bg-slate-100 text-slate-600">
                    {notificationKindLabel[row.kind] ?? "عمومی"}
                  </Badge>
                  {!row.isRead && <Badge className="bg-amber-100 text-amber-800">جدید</Badge>}
                </div>
              </div>
              <p className="mt-2 text-sm leading-6 text-slate-600">{row.body}</p>
              <p className="mt-2 text-[11px] text-slate-400">
                {row.senderName ? `فرستنده: ${row.senderName} — ` : ""}
                {faDate(row.createdAt)}
              </p>
            </article>
          ))
        )}
      </div>
    </>
  );
}


