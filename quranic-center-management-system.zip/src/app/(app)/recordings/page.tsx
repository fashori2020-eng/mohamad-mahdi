import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { Mic } from "lucide-react";
import { db } from "@/db";
import { students } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { RecordingReview, RecordingUploader } from "@/components/teaching-forms";
import { getTeacherByUserId, listRecordings } from "@/lib/data";
import { recordingStatusMeta } from "@/lib/labels";
import { faDate, faDigits } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

async function studentIdOfUser(userId: number) {
  const rows = await db.select({ id: students.id }).from(students).where(eq(students.userId, userId));
  return rows[0]?.id ?? -1;
}

export default async function RecordingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "parent") redirect("/dashboard");

  let rows;
  if (user.role === "student") {
    rows = await listRecordings({ studentIds: [await studentIdOfUser(user.id)] });
  } else if (user.role === "teacher") {
    const teacher = await getTeacherByUserId(user.id);
    rows = await listRecordings({ teacherId: teacher?.id ?? -1 });
  } else {
    rows = await listRecordings();
  }

  const pending = rows.filter((row) => row.status === "pending").length;
  const average = (() => {
    const scores = rows.map((row) => row.score).filter((score): score is number => score !== null);
    return scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
  })();

  return (
    <>
      <PageHeader
        title={user.role === "student" ? "صوت تلاوت من" : "تصحیح صوت تلاوت"}
        description={
          user.role === "student"
            ? "صوت تلاوت خود را بارگذاری کنید تا استاد آن را تصحیح و نمره‌دهی کند"
            : "تلاوت‌های ارسالی قرآن‌آموزان را گوش دهید، نمره و بازخورد ثبت کنید"
        }
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="کل تلاوت‌ها" value={faDigits(rows.length)} icon={<Mic className="h-6 w-6" />} />
        <StatCard label="در انتظار تصحیح" value={faDigits(pending)} tone="gold" icon={<Mic className="h-6 w-6" />} />
        <StatCard
          label="میانگین نمره"
          value={average ? `${faDigits(average)}/۲۰` : "—"}
          tone="emerald"
          icon={<Mic className="h-6 w-6" />}
        />
      </div>

      {user.role === "student" && (
        <div className="mt-4">
          <RecordingUploader />
        </div>
      )}

      <div className="mt-4 space-y-3">
        {rows.length === 0 ? (
          <EmptyState text="تلاوتی ثبت نشده است." icon={<Mic className="h-6 w-6" />} />
        ) : (
          rows.map((row) => (
            <Card
              key={row.id}
              title={row.title}
              subtitle={`${row.studentName} • ${row.surahName || "—"} ${row.ayahRange || ""} • ${faDate(
                row.createdAt,
              )} • کلاس: ${row.className ?? "—"}`}
              action={
                <Badge className={recordingStatusMeta[row.status].className}>
                  {recordingStatusMeta[row.status].label}
                  {row.score !== null ? ` — ${faDigits(row.score)}/۲۰` : ""}
                </Badge>
              }
            >
              {row.hasAudio ? (
                <audio controls preload="none" className="w-full" src={`/api/recordings/${row.id}/audio`}>
                  مرورگر شما از پخش صوت پشتیبانی نمی‌کند.
                </audio>
              ) : (
                <p className="rounded-xl bg-slate-50 px-3 py-2 text-xs text-slate-500">
                  فایل صوتی برای این رکورد ذخیره نشده است (رکورد نمایشی).
                </p>
              )}
              {row.feedback && (
                <p className="mt-3 rounded-xl bg-emerald-50 px-3 py-2 text-sm text-emerald-800">
                  بازخورد استاد: {row.feedback}
                </p>
              )}
              {user.role !== "student" && row.status === "pending" && (
                <RecordingReview recordingId={row.id} />
              )}
            </Card>
          ))
        )}
      </div>
    </>
  );
}
