import { redirect } from "next/navigation";
import { Download, Printer } from "lucide-react";
import { Card, EmptyState, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { BarChart } from "@/components/charts";
import { PrintButton } from "@/components/print-button";
import { reportsData } from "@/lib/data";
import { levelLabel, paymentStatusMeta } from "@/lib/labels";
import { faDateLong, faDigits, faMoney } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const exportLinks = [
  { type: "students", label: "قرآن‌آموزان" },
  { type: "teachers", label: "اساتید" },
  { type: "classes", label: "کلاس‌ها" },
  { type: "exams", label: "آزمون‌ها" },
  { type: "payments", label: "امور مالی" },
  { type: "attendance", label: "حضور و غیاب" },
];

export default async function ReportsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "manager") redirect("/dashboard");

  const data = await reportsData();

  return (
    <>
      <PageHeader
        title="گزارش‌ها"
        description={`گزارش عملکرد کلاس‌ها و اساتید — ${faDateLong(data.today)}`}
        action={
          <div className="flex flex-wrap gap-2">
            <PrintButton label="چاپ گزارش / PDF" />
            <a href="/api/export?type=students" className="btn btn-gold">
              <Download className="h-4 w-4" />
              خروجی اکسل
            </a>
          </div>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="قرآن‌آموزان فعال" value={faDigits(data.activeStudents)} />
        <StatCard label="در انتظار تأیید" value={faDigits(data.pendingStudents)} tone="gold" />
        <StatCard label="میانگین حضور" value={`${faDigits(data.attendanceRate)}٪`} tone="sky" />
        <StatCard label="آزمون‌های ثبت‌شده" value={faDigits(data.examCount)} tone="emerald" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card title="خلاصه مالی" className="lg:col-span-2">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl bg-emerald-50 p-3">
              <p className="text-xs font-bold text-emerald-700">دریافت‌شده</p>
              <p className="mt-1 text-lg font-extrabold text-emerald-900">{faMoney(data.finance.paid)}</p>
            </div>
            <div className="rounded-xl bg-amber-50 p-3">
              <p className="text-xs font-bold text-amber-700">در انتظار پرداخت</p>
              <p className="mt-1 text-lg font-extrabold text-amber-900">{faMoney(data.finance.unpaid)}</p>
            </div>
            <div className="rounded-xl bg-rose-50 p-3">
              <p className="text-xs font-bold text-rose-700">معوق</p>
              <p className="mt-1 text-lg font-extrabold text-rose-900">{faMoney(data.finance.overdue)}</p>
            </div>
          </div>
          <div className="mt-3">
            <p className="mb-1 text-xs font-bold text-slate-500">
              نسبت دریافت به کل: {faMoney(data.finance.total)}
            </p>
            <ProgressBar value={data.finance.paid} max={Math.max(data.finance.total, 1)} />
          </div>
        </Card>

        <Card title="خروجی‌های اکسل (CSV)" subtitle="قابل باز شدن در Excel">
          <div className="flex flex-wrap gap-2">
            {exportLinks.map((item) => (
              <a key={item.type} href={`/api/export?type=${item.type}`} className="btn btn-ghost btn-sm">
                <Download className="h-3 w-3" />
                {item.label}
              </a>
            ))}
          </div>
          <p className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <Printer className="h-4 w-4" />
            برای خروجی PDF از دکمه «چاپ گزارش» استفاده کنید و مقصد را «Save as PDF» انتخاب کنید.
          </p>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="عملکرد کلاس‌ها" padded={false}>
          {data.classPerformance.length === 0 ? (
            <div className="p-5">
              <EmptyState text="کلاسی ثبت نشده است." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>کلاس</th>
                    <th>استاد</th>
                    <th>قرآن‌آموزان</th>
                    <th>میانگین نمرات</th>
                  </tr>
                </thead>
                <tbody>
                  {data.classPerformance.map((row) => (
                    <tr key={row.id}>
                      <td className="font-bold text-emerald-900">{row.name}</td>
                      <td>{row.teacherName}</td>
                      <td>{faDigits(row.students)}</td>
                      <td>{row.average === null ? "—" : `${faDigits(row.average)}٪`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card title="عملکرد اساتید" padded={false}>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>استاد</th>
                  <th>تخصص‌ها</th>
                  <th>کلاس‌ها</th>
                  <th>حضور</th>
                </tr>
              </thead>
              <tbody>
                {data.teacherRows.map((row) => (
                  <tr key={row.id}>
                    <td className="font-bold text-emerald-900">{row.fullName}</td>
                    <td className="text-xs">{row.specialties.split(",").filter(Boolean).join("، ") || "—"}</td>
                    <td>{faDigits(row.classNames.length)}</td>
                    <td>{row.attendanceRate === null ? "—" : `${faDigits(row.attendanceRate)}٪`}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <div className="mt-4">
        <Card title="توزیع قرآن‌آموزان بر اساس سطح">
          <BarChart
            data={["rokhani", "tajvid", "hifz", "qeraat", "mafhim"].map((level) => ({
              label: levelLabel(level),
              value: data.studentRows.filter((row) => row.level === level).length,
            }))}
            unit="نفر"
          />
        </Card>
      </div>

      <div className="mt-4">
        <Card title="فهرست قرآن‌آموزان برای ارائه به هیئت امنا" padded={false}>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>نام</th>
                  <th>سطح</th>
                  <th>کلاس‌ها</th>
                  <th>میانگین نمرات</th>
                  <th>بدهی</th>
                  <th>وضعیت</th>
                </tr>
              </thead>
              <tbody>
                {data.studentRows.map((row) => (
                  <tr key={row.id}>
                    <td className="font-bold text-emerald-900">{row.fullName}</td>
                    <td>{levelLabel(row.level)}</td>
                    <td>{row.classNames.join("، ") || "—"}</td>
                    <td>{row.average === null ? "—" : `${faDigits(row.average)}٪`}</td>
                    <td>{row.debt ? faMoney(row.debt) : "—"}</td>
                    <td className={paymentStatusMeta[row.status === "active" ? "paid" : "unpaid"].className}>
                      {row.status === "active" ? "فعال" : row.status === "pending" ? "در انتظار" : "رد شده"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </>
  );
}
