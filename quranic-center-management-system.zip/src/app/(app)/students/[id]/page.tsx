import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { Award, FileText, Printer, Users } from "lucide-react";
import { db } from "@/db";
import { users } from "@/db/schema";
import { Badge, Card, EmptyState, KeyValue, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { StudentEditor, StudentStatusActions } from "@/components/admin-forms";
import { HifzGrid } from "@/components/teaching-forms";
import { getStudentProfile, hifzSummary } from "@/lib/data";
import {
  attendanceMeta,
  classModeMeta,
  examTypeLabel,
  levelLabel,
  paymentStatusMeta,
  recordingStatusMeta,
  registrationStatusMeta,
} from "@/lib/labels";
import { faDate, faDateLong, faDays, faDigits, faMoney, faTime } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function StudentProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const studentId = Number(id);
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const profile = await getStudentProfile(studentId);
  if (!profile) notFound();

  if (user.role === "parent" && profile.student.parentUserId !== user.id) redirect("/dashboard");
  if (user.role === "student" && profile.student.userId !== user.id) redirect("/dashboard");
  if (user.role === "parent") {
    return (
      <>
        <PageHeader title={profile.user.fullName} description="کارنامه و گزارش پیشرفت فرزند شما" />
        <GradeCard profile={profile} />
      </>
    );
  }

  const parents = await db
    .select({ id: users.id, fullName: users.fullName })
    .from(users)
    .where(eq(users.role, "parent"))
    .orderBy(asc(users.fullName));

  const summary = hifzSummary(profile.hifz);
  const attendanceStats = profile.attendance.reduce(
    (acc, row) => {
      acc.total += 1;
      if (row.status === "present" || row.status === "late") acc.present += 1;
      return acc;
    },
    { total: 0, present: 0 },
  );
  const debt = profile.payments.filter((p) => p.status !== "paid").reduce((s, p) => s + p.amount, 0);

  return (
    <>
      <PageHeader
        title={profile.user.fullName}
        description={`${levelLabel(profile.student.level)} • عضویت از ${faDate(profile.student.joinDate)}`}
        action={
          <Link href="/students" className="btn btn-ghost">
            بازگشت به فهرست
          </Link>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="پیشرفت حفظ"
          value={`${faDigits(summary.percent)}٪`}
          hint={`${faDigits(summary.memorized)} صفحه از ${faDigits(604)}`}
          icon={<Users className="h-6 w-6" />}
          href="/hifz"
        />
        <StatCard
          label="میانگین حضور"
          value={
            attendanceStats.total
              ? `${faDigits(Math.round((attendanceStats.present / attendanceStats.total) * 100))}٪`
              : "—"
          }
          hint={`${faDigits(attendanceStats.total)} جلسه ثبت‌شده`}
          tone="sky"
          icon={<Users className="h-6 w-6" />}
        />
        <StatCard
          label="تعداد آزمون‌ها"
          value={faDigits(profile.exams.length)}
          hint="شامل حفظ و شفاهی"
          tone="gold"
          icon={<FileText className="h-6 w-6" />}
          href="/exams"
        />
        <StatCard
          label="بدهی مالی"
          value={faMoney(debt)}
          hint={`${faDigits(profile.payments.length)} فقره`}
          tone={debt > 0 ? "rose" : "emerald"}
          icon={<Users className="h-6 w-6" />}
          href="/finance"
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card title="اطلاعات فردی" className="lg:col-span-2">
          <div className="grid gap-3 sm:grid-cols-2">
            <KeyValue label="شماره موبایل" value={<span dir="ltr">{faDigits(profile.user.mobile)}</span>} />
            <KeyValue label="تاریخ تولد" value={faDate(profile.student.birthDate)} />
            <KeyValue label="کد ملی" value={faDigits(profile.student.nationalCode) || "—"} />
            <KeyValue label="ولی" value={profile.student.guardianName || "—"} />
            <KeyValue label="تاریخ عضویت" value={faDateLong(profile.student.joinDate)} />
            <KeyValue label="نشانی" value={profile.student.address || "—"} />
          </div>
          <div className="mt-3">
            <p className="text-xs font-bold text-slate-500">سوابق و یادداشت‌ها</p>
            <p className="mt-1 rounded-xl bg-slate-50 p-3 text-sm leading-6 text-slate-700">
              {profile.student.history || "موردی ثبت نشده است."}
            </p>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Badge className={registrationStatusMeta[profile.student.status].className}>
              {registrationStatusMeta[profile.student.status].label}
            </Badge>
            {user.role === "manager" && (
              <StudentStatusActions
                studentId={profile.student.id}
                status={profile.student.status}
              />
            )}
          </div>
        </Card>

        <Card title="کلاس‌های فعال">
          {profile.classes.length === 0 ? (
            <EmptyState text="در کلاسی ثبت‌نام نکرده است." />
          ) : (
            <ul className="space-y-2">
              {profile.classes.map((cls) => (
                <li key={cls.id} className="rounded-xl border border-slate-200 px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <Link href={`/classes/${cls.id}`} className="truncate font-bold text-emerald-900">
                      {cls.name}
                    </Link>
                    <Badge className={classModeMeta[cls.mode].className}>
                      {classModeMeta[cls.mode].label}
                    </Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-slate-500">
                    {faDays(cls.days)} • {faTime(cls.startTime)} • {cls.teacherName ?? "—"}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="mt-4">
        <GradeCard profile={profile} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card title="وضعیت مالی">
          {profile.payments.length === 0 ? (
            <EmptyState text="پرداختی ثبت نشده است." />
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>عنوان</th>
                    <th>مبلغ</th>
                    <th>سررسید</th>
                    <th>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {profile.payments.map((payment) => (
                    <tr key={payment.id}>
                      <td>{payment.title}</td>
                      <td className="font-bold">{faMoney(payment.amount)}</td>
                      <td>{faDate(payment.dueDate)}</td>
                      <td>
                        <Badge className={paymentStatusMeta[payment.status].className}>
                          {paymentStatusMeta[payment.status].label}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card title="حضور و غیاب آخرین جلسات">
          {profile.attendance.length === 0 ? (
            <EmptyState text="حضوری ثبت نشده است." />
          ) : (
            <div className="flex flex-wrap gap-2">
              {profile.attendance.slice(-20).map((row, index) => (
                <Badge key={`${row.sessionId}-${index}`} className={attendanceMeta[row.status].className}>
                  {attendanceMeta[row.status].label}
                </Badge>
              ))}
            </div>
          )}
          <p className="mt-3 text-xs text-slate-500">
            {attendanceMeta.present.label}:{" "}
            {faDigits(profile.attendance.filter((r) => r.status === "present").length)} | غیبت:{" "}
            {faDigits(profile.attendance.filter((r) => r.status === "absent").length)} | تأخیر:{" "}
            {faDigits(profile.attendance.filter((r) => r.status === "late").length)}
          </p>
        </Card>
      </div>

      {user.role === "manager" && (
        <div className="mt-4">
          <StudentEditor
            studentId={profile.student.id}
            initial={{
              fullName: profile.user.fullName,
              level: profile.student.level,
              nationalCode: profile.student.nationalCode,
              guardianName: profile.student.guardianName,
              address: profile.student.address,
              history: profile.student.history,
              parentUserId: profile.student.parentUserId,
            }}
            parents={parents}
          />
        </div>
      )}
    </>
  );
}

function GradeCard({
  profile,
}: {
  profile: NonNullable<Awaited<ReturnType<typeof getStudentProfile>>>;
}) {
  const summary = hifzSummary(profile.hifz);
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="کارنامه و نمرات" className="lg:col-span-2" padded={false}>
        {profile.exams.length === 0 ? (
          <div className="p-5">
            <EmptyState text="نمره‌ای ثبت نشده است." icon={<Award className="h-6 w-6" />} />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>آزمون</th>
                  <th>نوع</th>
                  <th>تاریخ</th>
                  <th>نمره</th>
                  <th>بازخورد</th>
                </tr>
              </thead>
              <tbody>
                {profile.exams.map((exam) => (
                  <tr key={exam.id}>
                    <td className="font-bold text-emerald-900">{exam.title}</td>
                    <td>{examTypeLabel(exam.examType)}</td>
                    <td>{faDate(exam.examDate)}</td>
                    <td className="font-bold">
                      {faDigits(exam.score)} از {faDigits(exam.maxScore)}
                    </td>
                    <td className="max-w-xs text-xs text-slate-500">{exam.feedback || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card title="خلاصه پیشرفت">
        <p className="mb-1 text-xs font-bold text-slate-500">
          {faDigits(summary.memorized)} صفحه حفظ‌شده — {faDigits(summary.inProgress)} صفحه در حال حفظ
        </p>
        <ProgressBar value={summary.memorized} max={604} />
        <p className="mt-3 text-xs font-bold text-slate-500">صوت تلاوت‌ها</p>
        <ul className="mt-1 space-y-1">
          {profile.recordings.length === 0 && (
            <li className="text-xs text-slate-400">صوتی بارگذاری نشده است.</li>
          )}
          {profile.recordings.map((recording) => (
            <li
              key={recording.id}
              className="flex items-center justify-between gap-2 rounded-lg bg-slate-50 px-2 py-1.5"
            >
              <span className="truncate text-xs font-bold text-emerald-900">{recording.title}</span>
              <Badge className={recordingStatusMeta[recording.status].className}>
                {recording.score ? `${faDigits(recording.score)}/۲۰` : recordingStatusMeta[recording.status].label}
              </Badge>
            </li>
          ))}
        </ul>
        {profile.certificates.length > 0 && (
          <Link
            href={`/print/certificate/${profile.certificates[0].id}`}
            className="btn btn-gold btn-sm mt-4 w-full"
          >
            <Printer className="h-4 w-4" />
            مشاهده گواهی پایان دوره
          </Link>
        )}
      </Card>
    </div>
  );
}
