import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, eq, inArray } from "drizzle-orm";
import { Users } from "lucide-react";
import { db } from "@/db";
import { classes, enrollments, hifzProgress, students, users } from "@/db/schema";
import { Badge, Card, EmptyState, PageHeader, ProgressBar, StatCard } from "@/components/ui";
import { DataTable } from "@/components/data-table";
import { StudentCreator, StudentStatusActions } from "@/components/admin-forms";
import { listStudentsWithDetails } from "@/lib/data";
import { levelLabel, registrationStatusMeta } from "@/lib/labels";
import { faDate, faDigits, faMoney } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function StudentsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  if (user.role === "parent") return <ParentChildrenView />;
  if (user.role === "student") redirect("/hifz");

  const rows = await listStudentsWithDetails();

  let scoped = rows;
  if (user.role === "teacher") {
    const myClasses = await db
      .select({ name: classes.name })
      .from(classes)
      .where(eq(classes.teacherId, user.id));
    const names = myClasses.map((item) => item.name);
    scoped = rows.filter((row) => row.classNames.some((name) => names.includes(name)));
  }

  const tableRows = scoped.map((row) => ({
    id: String(row.id),
    href: `/students/${row.id}`,
    values: {
      fullName: row.fullName,
      level: levelLabel(row.level),
      classes: row.classNames.length ? row.classNames.join("، ") : "—",
      status: registrationStatusMeta[row.status].label,
      average: row.average === null ? "—" : `${faDigits(row.average)}٪`,
      debt: row.debt ? faMoney(row.debt) : "—",
      mobile: faDigits(row.mobile),
      joinDate: faDate(row.joinDate),
    },
  }));

  const active = rows.filter((row) => row.status === "active").length;
  const pending = rows.filter((row) => row.status === "pending").length;
  const totalDebt = rows.reduce((sum, row) => sum + row.debt, 0);

  return (
    <>
      <PageHeader
        title="مدیریت قرآن‌آموزان"
        description="پرونده کامل، سطح آموزشی، کارنامه و وضعیت مالی"
        action={<StudentCreator />}
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="کل قرآن‌آموزان" value={faDigits(rows.length)} icon={<Users className="h-6 w-6" />} />
        <StatCard label="پرونده فعال" value={faDigits(active)} tone="emerald" icon={<Users className="h-6 w-6" />} />
        <StatCard label="در انتظار تأیید" value={faDigits(pending)} tone="gold" icon={<Users className="h-6 w-6" />} />
        <StatCard label="مجموع بدهی" value={faMoney(totalDebt)} tone="rose" icon={<Users className="h-6 w-6" />} />
      </div>

      {pending > 0 && (
        <div className="mt-4">
          <Card title="ثبت‌نام‌های در انتظار تأیید">
            <ul className="grid gap-3 sm:grid-cols-2">
              {rows
                .filter((row) => row.status === "pending")
                .map((row) => (
                  <li key={row.id} className="rounded-xl border border-amber-200 bg-amber-50 p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-extrabold text-amber-900">{row.fullName}</p>
                      <Badge className={registrationStatusMeta[row.status].className}>
                        {registrationStatusMeta[row.status].label}
                      </Badge>
                    </div>
                    <p className="mt-1 text-xs text-amber-700">
                      {levelLabel(row.level)} • {faDigits(row.mobile)}
                    </p>
                    <div className="mt-2">
                      <StudentStatusActions studentId={row.id} status={row.status} />
                    </div>
                  </li>
                ))}
            </ul>
          </Card>
        </div>
      )}

      <div className="mt-4">
        <Card title="فهرست قرآن‌آموزان" subtitle="جستجو و مرتب‌سازی بر اساس هر ستون">
          <DataTable
            columns={[
              { key: "fullName", header: "نام" },
              { key: "level", header: "سطح" },
              { key: "classes", header: "کلاس‌ها" },
              { key: "status", header: "وضعیت" },
              { key: "average", header: "میانگین نمرات", numeric: true },
              { key: "debt", header: "بدهی", numeric: true },
              { key: "mobile", header: "موبایل" },
              { key: "joinDate", header: "تاریخ عضویت" },
            ]}
            rows={tableRows}
            searchPlaceholder="جستجو در قرآن‌آموزان..."
            linkLabel="پرونده"
          />
        </Card>
      </div>
    </>
  );
}

async function ParentChildrenView() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const children = await db
    .select({
      id: students.id,
      fullName: users.fullName,
      level: students.level,
      status: students.status,
      joinDate: students.joinDate,
      guardianName: students.guardianName,
    })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .where(eq(students.parentUserId, user.id));

  if (children.length === 0) {
    return (
      <>
        <PageHeader title="گزارش پیشرفت فرزند" />
        <EmptyState text="پرونده‌ای به حساب شما متصل نیست. با مدیریت مجموعه تماس بگیرید." />
      </>
    );
  }

  const rows = await db
    .select({
      studentId: hifzProgress.studentId,
      status: hifzProgress.status,
    })
    .from(hifzProgress)
    .where(
      inArray(
        hifzProgress.studentId,
        children.map((child) => child.id),
      ),
    );

  const classRows = await db
    .select({ studentId: enrollments.studentId, className: classes.name })
    .from(enrollments)
    .innerJoin(classes, eq(classes.id, enrollments.classId))
    .where(
      inArray(
        enrollments.studentId,
        children.map((child) => child.id),
      ),
    )
    .orderBy(asc(classes.name));

  return (
    <>
      <PageHeader
        title="گزارش پیشرفت فرزند"
        description="پیشرفت حفظ، کلاس‌ها و کارنامه — گزارش‌های لحظه‌ای فرزندان شما"
      />
      <div className="grid gap-4 lg:grid-cols-2">
        {children.map((child) => {
          const memorized = rows.filter(
            (row) => row.studentId === child.id && (row.status === "memorized" || row.status === "stable"),
          ).length;
          const percent = Math.round((memorized / 604) * 100);
          const childClasses = classRows.filter((row) => row.studentId === child.id);
          return (
            <Card
              key={child.id}
              title={child.fullName}
              subtitle={`سطح ${levelLabel(child.level)} • عضویت از ${faDate(child.joinDate)}`}
              action={
                <Link href={`/students/${child.id}`} className="btn btn-primary btn-sm">
                  کارنامه کامل
                </Link>
              }
            >
              <p className="mb-1 text-xs font-bold text-slate-500">
                پیشرفت حفظ: {faDigits(memorized)} صفحه از {faDigits(604)}
              </p>
              <ProgressBar value={memorized} max={604} />
              <p className="mt-3 text-xs font-bold text-slate-500">کلاس‌ها:</p>
              <div className="mt-1 flex flex-wrap gap-2">
                {childClasses.length === 0 ? (
                  <span className="text-xs text-slate-400">ثبت‌نامی وجود ندارد</span>
                ) : (
                  childClasses.map((row) => (
                    <Badge key={`${row.studentId}-${row.className}`} className="bg-emerald-50 text-emerald-700">
                      {row.className}
                    </Badge>
                  ))
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </>
  );
}
