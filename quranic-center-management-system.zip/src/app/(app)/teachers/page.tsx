import { redirect } from "next/navigation";
import { GraduationCap, Users } from "lucide-react";
import { Badge, Card, PageHeader, StatCard } from "@/components/ui";
import { TeacherCreator, TeacherStatusActions } from "@/components/admin-forms";
import { listTeachersWithDetails } from "@/lib/data";
import { levelLabel, registrationStatusMeta } from "@/lib/labels";
import { faDate, faDigits } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function TeachersPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role === "student" || user.role === "parent") redirect("/dashboard");

  const rows = await listTeachersWithDetails();
  const totalStudents = rows.reduce((sum, row) => sum + row.studentCount, 0);
  const averageRate = (() => {
    const values = rows.map((row) => row.attendanceRate).filter((v): v is number => v !== null);
    return values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : 0;
  })();

  return (
    <>
      <PageHeader
        title="مدیریت اساتید"
        description="پرونده استاد، تخصص‌ها، انتصاب به کلاس‌ها و مشاهده عملکرد"
        action={user.role === "manager" ? <TeacherCreator /> : undefined}
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="تعداد اساتید" value={faDigits(rows.length)} icon={<GraduationCap className="h-6 w-6" />} />
        <StatCard
          label="قرآن‌آموزان تحت آموزش"
          value={faDigits(totalStudents)}
          tone="sky"
          icon={<Users className="h-6 w-6" />}
        />
        <StatCard
          label="میانگین حضور کلاس‌ها"
          value={`${faDigits(averageRate)}٪`}
          tone="emerald"
          icon={<Users className="h-6 w-6" />}
        />
        <StatCard
          label="آزمون‌های ثبت‌شده"
          value={faDigits(rows.reduce((sum, row) => sum + row.examCount, 0))}
          tone="gold"
          icon={<GraduationCap className="h-6 w-6" />}
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {rows.map((teacher) => (
          <Card
            key={teacher.id}
            title={teacher.fullName}
            subtitle={`${teacher.education || "—"} • عضویت از ${faDate(teacher.joinDate)}`}
            action={
              user.role === "manager" ? (
                <TeacherStatusActions teacherId={teacher.id} status={teacher.status} />
              ) : undefined
            }
          >
            <div className="flex flex-wrap gap-2">
              {teacher.specialties.split(",").filter(Boolean).map((item) => (
                <Badge key={item} className="bg-amber-50 text-amber-800">
                  {item}
                </Badge>
              ))}
              <Badge className={registrationStatusMeta[teacher.status].className}>
                {registrationStatusMeta[teacher.status].label}
              </Badge>
            </div>
            <p className="mt-3 text-sm leading-6 text-slate-600">{teacher.bio || "بدون توضیح."}</p>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center">
              <div className="rounded-xl bg-slate-50 p-2">
                <p className="text-lg font-extrabold text-emerald-900">{faDigits(teacher.classNames.length)}</p>
                <p className="text-[11px] font-bold text-slate-500">کلاس</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-2">
                <p className="text-lg font-extrabold text-emerald-900">{faDigits(teacher.studentCount)}</p>
                <p className="text-[11px] font-bold text-slate-500">قرآن‌آموز</p>
              </div>
              <div className="rounded-xl bg-slate-50 p-2">
                <p className="text-lg font-extrabold text-emerald-900">
                  {teacher.attendanceRate === null ? "—" : `${faDigits(teacher.attendanceRate)}٪`}
                </p>
                <p className="text-[11px] font-bold text-slate-500">حضور</p>
              </div>
            </div>
            <div className="mt-3">
              <p className="text-xs font-bold text-slate-500">کلاس‌ها</p>
              <div className="mt-1 flex flex-wrap gap-2">
                {teacher.classNames.length === 0 ? (
                  <span className="text-xs text-slate-400">هنوز کلاسی انتصاب نشده است.</span>
                ) : (
                  teacher.classNames.map((name) => (
                    <Badge key={name} className="bg-emerald-50 text-emerald-700">
                      {name}
                    </Badge>
                  ))
                )}
              </div>
            </div>
            <p className="mt-3 text-xs text-slate-500" dir="ltr">
              {faDigits(teacher.mobile)}
            </p>
          </Card>
        ))}
      </div>

      <div className="mt-4">
        <Card title="سطوح آموزشی مجموعه" subtitle="دوره‌های فعال در مجموعه معارج">
          <div className="flex flex-wrap gap-2">
            {["rokhani", "tajvid", "hifz", "qeraat", "mafhim"].map((level) => (
              <Badge key={level} className="bg-slate-100 text-slate-700">
                {levelLabel(level)}
              </Badge>
            ))}
          </div>
        </Card>
      </div>
    </>
  );
}
