import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attendance, classSessions, classes, exams, payments, students, teachers, users } from "@/db/schema";
import { levelLabel } from "@/lib/labels";
import { faDate } from "@/lib/jalali";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

function toCsv(headers: string[], rows: (string | number)[][]) {
  const escape = (value: string | number) => {
    const text = String(value ?? "");
    return `"${text.replace(/"/g, '""')}"`;
  };
  const lines = [headers.map(escape).join(","), ...rows.map((row) => row.map(escape).join(","))];
  return `\uFEFF${lines.join("\r\n")}`;
}

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user || user.role !== "manager") {
    return new Response("دسترسی مجاز نیست", { status: 403 });
  }

  const type = new URL(request.url).searchParams.get("type") ?? "students";
  let csv = "";
  let filename = "report.csv";

  if (type === "students") {
    const rows = await db
      .select({
        fullName: users.fullName,
        mobile: users.mobile,
        level: students.level,
        status: students.status,
        joinDate: students.joinDate,
        guardianName: students.guardianName,
        nationalCode: students.nationalCode,
      })
      .from(students)
      .innerJoin(users, eq(users.id, students.userId))
      .orderBy(asc(users.fullName));
    csv = toCsv(
      ["نام", "موبایل", "سطح", "وضعیت", "تاریخ عضویت", "نام ولی", "کد ملی"],
      rows.map((row) => [
        row.fullName,
        row.mobile,
        levelLabel(row.level),
        row.status === "active" ? "فعال" : row.status === "pending" ? "در انتظار تأیید" : "رد شده",
        faDate(row.joinDate),
        row.guardianName,
        row.nationalCode,
      ]),
    );
    filename = "students.csv";
  } else if (type === "teachers") {
    const rows = await db
      .select({
        fullName: users.fullName,
        mobile: users.mobile,
        specialties: teachers.specialties,
        education: teachers.education,
        joinDate: teachers.joinDate,
      })
      .from(teachers)
      .innerJoin(users, eq(users.id, teachers.userId))
      .orderBy(asc(users.fullName));
    csv = toCsv(
      ["نام", "موبایل", "تخصص‌ها", "مدرک", "تاریخ عضویت"],
      rows.map((row) => [row.fullName, row.mobile, row.specialties, row.education, faDate(row.joinDate)]),
    );
    filename = "teachers.csv";
  } else if (type === "classes") {
    const rows = await db
      .select({
        name: classes.name,
        courseType: classes.courseType,
        days: classes.days,
        startTime: classes.startTime,
        mode: classes.mode,
        location: classes.location,
        tuition: classes.tuition,
        capacity: classes.capacity,
        teacherName: users.fullName,
      })
      .from(classes)
      .leftJoin(teachers, eq(teachers.id, classes.teacherId))
      .leftJoin(users, eq(users.id, teachers.userId))
      .orderBy(asc(classes.id));
    csv = toCsv(
      ["کلاس", "دوره", "روزها", "ساعت", "نوع", "مکان", "شهریه", "ظرفیت", "استاد"],
      rows.map((row) => [
        row.name,
        levelLabel(row.courseType),
        row.days,
        row.startTime,
        row.mode === "inperson" ? "حضوری" : "آنلاین",
        row.location,
        row.tuition,
        row.capacity,
        row.teacherName ?? "—",
      ]),
    );
    filename = "classes.csv";
  } else if (type === "exams") {
    const rows = await db
      .select({
        studentName: users.fullName,
        title: exams.title,
        examType: exams.examType,
        examDate: exams.examDate,
        score: exams.score,
        maxScore: exams.maxScore,
        feedback: exams.feedback,
      })
      .from(exams)
      .innerJoin(students, eq(students.id, exams.studentId))
      .innerJoin(users, eq(users.id, students.userId))
      .orderBy(asc(exams.examDate));
    csv = toCsv(
      ["قرآن‌آموز", "آزمون", "نوع", "تاریخ", "نمره", "از", "بازخورد"],
      rows.map((row) => [
        row.studentName,
        row.title,
        row.examType,
        faDate(row.examDate),
        row.score,
        row.maxScore,
        row.feedback,
      ]),
    );
    filename = "exams.csv";
  } else if (type === "payments") {
    const rows = await db
      .select({
        title: payments.title,
        amount: payments.amount,
        kind: payments.kind,
        dueDate: payments.dueDate,
        status: payments.status,
        method: payments.method,
        trackingCode: payments.trackingCode,
        studentName: users.fullName,
      })
      .from(payments)
      .leftJoin(students, eq(students.id, payments.studentId))
      .leftJoin(users, eq(users.id, students.userId))
      .orderBy(asc(payments.dueDate));
    csv = toCsv(
      ["عنوان", "نوع", "قرآن‌آموز", "مبلغ", "سررسید", "وضعیت", "روش پرداخت", "کد پیگیری"],
      rows.map((row) => [
        row.title,
        row.kind,
        row.studentName ?? "—",
        row.amount,
        faDate(row.dueDate),
        row.status === "paid" ? "پرداخت شده" : row.status === "overdue" ? "معوق" : "پرداخت نشده",
        row.method,
        row.trackingCode,
      ]),
    );
    filename = "payments.csv";
  } else if (type === "attendance") {
    const rows = await db
      .select({
        studentName: users.fullName,
        sessionDate: classSessions.sessionDate,
        className: classes.name,
        status: attendance.status,
      })
      .from(attendance)
      .innerJoin(students, eq(students.id, attendance.studentId))
      .innerJoin(users, eq(users.id, students.userId))
      .innerJoin(classSessions, eq(classSessions.id, attendance.sessionId))
      .innerJoin(classes, eq(classes.id, classSessions.classId))
      .orderBy(asc(classSessions.sessionDate));
    csv = toCsv(
      ["قرآن‌آموز", "کلاس", "تاریخ جلسه", "وضعیت"],
      rows.map((row) => [
        row.studentName,
        row.className,
        faDate(row.sessionDate),
        row.status === "present"
          ? "حاضر"
          : row.status === "absent"
            ? "غایب"
            : row.status === "late"
              ? "تأخیر"
              : "موجه",
      ]),
    );
    filename = "attendance.csv";
  } else {
    return new Response("نوع خروجی نامعتبر است", { status: 400 });
  }

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
