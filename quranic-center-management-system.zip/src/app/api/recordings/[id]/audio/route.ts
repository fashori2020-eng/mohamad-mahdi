import { eq } from "drizzle-orm";
import { db } from "@/db";
import { recordings, students } from "@/db/schema";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

async function studentIdOf(userId: number) {
  const rows = await db.select({ id: students.id }).from(students).where(eq(students.userId, userId));
  return rows[0]?.id ?? -1;
}

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) {
    return new Response("ابتدا وارد شوید.", { status: 401 });
  }

  const { id } = await params;
  const rows = await db
    .select({
      audioData: recordings.audioData,
      mimeType: recordings.mimeType,
      studentId: recordings.studentId,
    })
    .from(recordings)
    .where(eq(recordings.id, Number(id)))
    .limit(1);

  const row = rows[0];
  if (!row || !row.audioData) {
    return new Response("فایل صوتی یافت نشد.", { status: 404 });
  }

  let allowed = user.role === "manager" || user.role === "teacher";
  if (!allowed && user.role === "student") {
    allowed = (await studentIdOf(user.id)) === row.studentId;
  }
  if (!allowed && user.role === "parent") {
    const childRows = await db
      .select({ id: students.id })
      .from(students)
      .where(eq(students.parentUserId, user.id));
    allowed = childRows.some((child) => child.id === row.studentId);
  }

  if (!allowed) {
    return new Response("دسترسی مجاز نیست.", { status: 403 });
  }

  const bytes = new Uint8Array(Buffer.from(row.audioData, "base64"));
  return new Response(bytes, {
    headers: {
      "Content-Type": row.mimeType || "audio/mpeg",
      "Cache-Control": "private, max-age=300",
    },
  });
}
