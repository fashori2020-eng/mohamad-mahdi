import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مجموعه فرهنگی قرآنی معارج | سامانه مدیریت یکپارچه",
  description:
    "سامانه مدیریت مجموعه فرهنگی قرآنی معارج — مدیریت قرآن‌آموزان، اساتید، کلاس‌ها، حضور و غیاب، آزمون‌های حفظ، امور مالی و ارتباط با اولیا",
};

export const viewport: Viewport = {
  themeColor: "#047857",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css"
        />
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
