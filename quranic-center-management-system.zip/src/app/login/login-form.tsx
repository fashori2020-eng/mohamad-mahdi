"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { KeyRound, Loader2, LogIn, ShieldCheck, Smartphone } from "lucide-react";
import { requestOtp, verifyOtp } from "@/lib/actions";

export function LoginForm({ demoAccounts }: { demoAccounts: { role: string; mobile: string }[] }) {
  const router = useRouter();
  const [step, setStep] = useState<"mobile" | "code">("mobile");
  const [mobile, setMobile] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [pending, startTransition] = useTransition();

  function submitMobile(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setSuccess("");
    startTransition(async () => {
      const result = await requestOtp(mobile);
      if (!result.ok) {
        setError(result.message);
        return;
      }
      setDevCode(result.extra?.code ?? "");
      setStep("code");
      setSuccess("رمز یکبارمصرف ارسال شد ✓");
    });
  }

  function submitCode(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    startTransition(async () => {
      const result = await verifyOtp(mobile, code);
      if (!result.ok) {
        setError(result.message);
        return;
      }
      setSuccess("ورود موفق ✓ در حال انتقال...");
      router.push("/dashboard");
      router.refresh();
    });
  }

  return (
    <div className="space-y-5">
      <form onSubmit={submitMobile} className={step === "mobile" ? "space-y-4" : "hidden"}>
        <div>
          <label className="label" htmlFor="mobile">
            شماره موبایل
          </label>
          <div className="relative">
            <Smartphone className="pointer-events-none absolute end-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            <input
              id="mobile"
              className="input pe-11 text-left font-mono text-lg tracking-widest"
              placeholder="09121110000"
              dir="ltr"
              value={mobile}
              onChange={(event) => setMobile(event.target.value)}
              inputMode="numeric"
              autoComplete="tel"
              required
            />
          </div>
          <p className="mt-1 text-xs text-slate-400">نمونه: ۰۹۱۲۱۱۱۰۰۰۰</p>
        </div>
        <button type="submit" className="btn btn-primary w-full py-3" disabled={pending}>
          {pending ? <Loader2 className="h-5 w-5 animate-spin" /> : <LogIn className="h-5 w-5" />}
          دریافت رمز یکبارمصرف
        </button>
      </form>

      <form onSubmit={submitCode} className={step === "code" ? "space-y-4" : "hidden"}>
        {devCode && (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-center">
            <p className="text-xs font-bold text-amber-700">رمز یکبارمصرف (حالت نمایشی)</p>
            <p className="mt-1 font-mono text-3xl font-black tracking-[0.4em] text-amber-700">
              {devCode}
            </p>
            <p className="mt-1 text-[11px] text-amber-600">اعتبار: ۵ دقیقه</p>
          </div>
        )}
        <div>
          <label className="label" htmlFor="code">
            رمز یکبارمصرف
          </label>
          <div className="relative">
            <KeyRound className="pointer-events-none absolute end-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
            <input
              id="code"
              className="input pe-11 text-center font-mono text-2xl tracking-[0.4em]"
              placeholder="- - - - -"
              dir="ltr"
              value={code}
              onChange={(event) => setCode(event.target.value)}
              inputMode="numeric"
              maxLength={6}
              required
            />
          </div>
        </div>
        <button type="submit" className="btn btn-primary w-full py-3" disabled={pending}>
          {pending ? <Loader2 className="h-5 w-5 animate-spin" /> : <ShieldCheck className="h-5 w-5" />}
          ورود به سامانه
        </button>
        <button
          type="button"
          className="btn btn-ghost w-full"
          onClick={() => {
            setStep("mobile");
            setCode("");
            setDevCode("");
          }}
        >
          تغییر شماره موبایل
        </button>
      </form>

      {error && (
        <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-700 ring-1 ring-rose-200">
          {error}
        </p>
      )}
      {success && !error && (
        <p className="rounded-xl bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700 ring-1 ring-emerald-200">
          {success}
        </p>
      )}

      <div className="border-t border-slate-200 pt-4">
        <p className="mb-2 text-xs font-extrabold text-slate-500">ورود سریع با حساب‌های نمایشی</p>
        <div className="grid gap-2 sm:grid-cols-2">
          {demoAccounts.map((account) => (
            <button
              key={account.mobile}
              type="button"
              className="btn btn-ghost btn-sm justify-between"
              onClick={() => {
                setMobile(account.mobile);
                setStep("mobile");
                setError("");
              }}
            >
              <span>{account.role}</span>
              <span className="font-mono text-xs text-amber-600" dir="ltr">
                {account.mobile}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
