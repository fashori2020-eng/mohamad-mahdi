import Link from "next/link";
import { redirect } from "next/navigation";
import { asc, inArray } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { LoginForm } from "./login-form";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser, roleLabel } from "@/lib/session";

export const dynamic = "force-dynamic";

const roleOrder = ["manager", "teacher", "student", "parent"];

export default async function LoginPage() {
  await ensureSeeded();
  const current = await getCurrentUser();
  if (current) redirect("/dashboard");

  const rows = await db
    .select({ mobile: users.mobile, role: users.role, fullName: users.fullName })
    .from(users)
    .where(inArray(users.role, ["manager", "teacher", "student", "parent"]))
    .orderBy(asc(users.id));

  const demoAccounts = roleOrder
    .map((role) => {
      const found = rows.find((row) => row.role === role);
      return found ? { role: roleLabel(found.role), mobile: found.mobile } : null;
    })
    .filter((item): item is { role: string; mobile: string } => item !== null);

  return (
    <div className="pattern-quran flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-2xl font-black text-amber-300 shadow-lg">
            م
          </span>
          <h1 className="mt-4 text-2xl font-black text-emerald-900">ورود به سامانه معارج</h1>
          <p className="mt-2 text-sm text-slate-500">
            ورود سریع با شماره موبایل و رمز یکبارمصرف — بدون نیاز به رمز پیچیده
          </p>
        </div>

        <div className="card p-5 sm:p-6">
          <LoginForm demoAccounts={demoAccounts} />
        </div>

        <p className="mt-5 text-center text-sm text-slate-500">
          حساب کاربری ندارید؟{" "}
          <Link href="/register" className="font-extrabold text-emerald-700 hover:underline">
            ثبت‌نام آنلاین
          </Link>
          {" | "}
          <Link href="/" className="font-extrabold text-emerald-700 hover:underline">
            صفحه اصلی
          </Link>
        </p>
      </div>
    </div>
  );
}
