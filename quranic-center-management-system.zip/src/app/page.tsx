import Link from "next/link";
import {
  Award,
  BookOpenCheck,
  CalendarDays,
  ClipboardList,
  GraduationCap,
  LayoutDashboard,
  Mic,
  School,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";
import { ensureSeeded } from "@/lib/seed";
import { getCurrentUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const features = [
  {
    icon: <LayoutDashboard className="h-6 w-6" />,
    title: "داشبورد اختصاصی هر نقش",
    text: "مدیر، استاد، قرآن‌آموز و ولی هر کدام تنها اطلاعات مرتبط با خود را می‌بینند.",
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "مدیریت قرآن‌آموزان",
    text: "پرونده کامل، سطح آموزشی، سوابق و کارنامه در یک نگاه.",
  },
  {
    icon: <Sparkles className="h-6 w-6" />,
    title: "نوار پیشرفت حفظ",
    text: "پیگیری صفحه‌به‌صفحه و جزء‌به‌جزء مسیر حفظ قرآن کریم.",
  },
  {
    icon: <ClipboardList className="h-6 w-6" />,
    title: "حضور و غیاب یک‌کلیکی",
    text: "ثبت سریع حضور هر جلسه و اطلاع‌رسانی خودکار غیبت به اولیا.",
  },
  {
    icon: <BookOpenCheck className="h-6 w-6" />,
    title: "آزمون‌های حفظ",
    text: "صفحه جدید، تثبیت و کل جزء با نمره شفاهی و بازخورد استاد.",
  },
  {
    icon: <Wallet className="h-6 w-6" />,
    title: "امور مالی و شهریه",
    text: "شهریه‌ها، بدهی‌ها، کمک به هیئت امنا و درگاه پرداخت آنلاین.",
  },
  {
    icon: <Mic className="h-6 w-6" />,
    title: "آپلود صوت تلاوت",
    text: "قرآن‌آموز صوت می‌فرستد، استاد تصحیح و بازخورد ثبت می‌کند.",
  },
  {
    icon: <Award className="h-6 w-6" />,
    title: "گواهی پایان دوره",
    text: "صدور گواهی با طراحی زیبا و امکان دریافت خروجی PDF.",
  },
  {
    icon: <CalendarDays className="h-6 w-6" />,
    title: "تقویم و برنامه‌ریزی",
    text: "جدول هفتگی کلاس‌ها و تقویم ماهانه آزمون‌ها، مناسبت‌ها و اردوها.",
  },
];

const demo = [
  { role: "مدیر مجموعه", mobile: "09121110000" },
  { role: "استاد", mobile: "09121230001" },
  { role: "قرآن‌آموز", mobile: "09351010001" },
  { role: "ولی قرآن‌آموز", mobile: "09352020001" },
];

export default async function LandingPage() {
  await ensureSeeded();
  const user = await getCurrentUser();

  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-xl font-black text-amber-300 shadow-lg">
            م
          </span>
          <div>
            <p className="font-extrabold text-emerald-900">مجموعه فرهنگی قرآنی معارج</p>
            <p className="text-xs text-slate-500">سامانه مدیریت یکپارچه مؤسسه قرآنی</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {user ? (
            <Link href="/dashboard" className="btn btn-primary">
              ورود به داشبورد
            </Link>
          ) : (
            <>
              <Link href="/login" className="btn btn-ghost">
                ورود
              </Link>
              <Link href="/register" className="btn btn-primary">
                ثبت‌نام آنلاین
              </Link>
            </>
          )}
        </div>
      </header>

      <section className="pattern-quran mx-auto max-w-6xl px-4 pt-6 pb-10 text-center">
        <span className="badge mx-auto bg-amber-100 text-amber-800">
          قرآن کریم • حفظ • روخوانی • تجوید • قرائت • مفاهیم
        </span>
        <h1 className="mt-5 text-3xl leading-tight font-black text-emerald-900 sm:text-5xl">
          مدیریت هوشمند مجموعه قرآنی شما
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 text-slate-600 sm:text-base">
          از ثبت‌نام آنلاین و پرونده قرآن‌آموزان تا حضور و غیاب، آزمون‌های حفظ، امور مالی،
          اطلاع‌رسانی به اولیا و صدور گواهی پایان دوره — همه در یک سامانه راست‌چین، سبز زمردی و
          موبایل‌پسند.
        </p>
        <div className="mt-7 flex flex-wrap justify-center gap-3">
          <Link href="/register" className="btn btn-primary px-6 py-3">
            ثبت‌نام قرآن‌آموز جدید
          </Link>
          <Link href="/login" className="btn btn-gold px-6 py-3">
            ورود سریع با رمز یکبارمصرف
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <article key={feature.title} className="card card-hover p-5 transition">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-50 text-emerald-700">
                {feature.icon}
              </span>
              <h3 className="mt-3 font-extrabold text-emerald-900">{feature.title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{feature.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="card pattern-quran p-6">
          <h2 className="flex items-center gap-2 text-lg font-extrabold text-emerald-900">
            <GraduationCap className="h-5 w-5" />
            حساب‌های نمایشی برای بازدید سریع
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            با یکی از شماره‌های زیر وارد شوید؛ رمز یکبارمصرف روی صفحه نمایش داده می‌شود (حالت
            نمایشی، بدون پیامک واقعی).
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {demo.map((item) => (
              <div key={item.mobile} className="rounded-2xl border border-emerald-100 bg-white p-4">
                <p className="text-sm font-extrabold text-emerald-900">{item.role}</p>
                <p className="mt-1 font-mono text-lg font-bold tracking-widest text-amber-600">
                  {item.mobile}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link href="/login" className="btn btn-primary">
              ورود به سامانه
            </Link>
            <Link href="/register" className="btn btn-ghost">
              ثبت‌نام
            </Link>
          </div>
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white/70 py-6 text-center text-xs text-slate-500">
        <School className="mx-auto mb-2 h-5 w-5 text-emerald-600" />
        مجموعه فرهنگی قرآنی معارج — همه حقوق محفوظ است.
      </footer>
    </div>
  );
}
