import { notFound } from "next/navigation";
import Link from "next/link";
import { getStudentById } from "@/lib/data";
import { faDateLong, faDigits } from "@/lib/jalali";
import { db } from "@/db";
import { certificates } from "@/db/schema";
import { eq } from "drizzle-orm";
import { PrintButton } from "@/components/print-button";

export const dynamic = "force-dynamic";

export default async function CertificatePrintPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const rows = await db
    .select()
    .from(certificates)
    .where(eq(certificates.id, Number(id)))
    .limit(1);
  const certificate = rows[0];
  if (!certificate) notFound();

  const student = await getStudentById(certificate.studentId);
  const fullName = student?.user.fullName ?? "قرآن‌آموز معارج";

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="mx-auto mb-4 flex max-w-3xl items-center justify-between gap-3 no-print">
        <Link href="/certificates" className="btn btn-ghost">
          بازگشت
        </Link>
        <PrintButton />
      </div>

      <div
        className="mx-auto max-w-3xl overflow-hidden rounded-3xl bg-white p-2 shadow-2xl"
        style={{ background: "linear-gradient(135deg, #065f46, #047857 45%, #b8860b 100%)" }}
      >
        <div className="rounded-[22px] bg-[#fffdf5] p-8 text-center sm:p-12">
          <div className="mx-auto mb-6 h-2 w-32 rounded-full bg-gradient-to-l from-amber-300 to-emerald-600" />
          <p className="text-sm font-bold text-emerald-800">بسم الله الرحمن الرحیم</p>
          <h1 className="mt-4 text-2xl font-black text-emerald-900 sm:text-3xl">
            مجموعه فرهنگی قرآنی معارج
          </h1>
          <p className="mt-1 text-xs text-slate-500">گواهی پایان دوره قرآنی</p>

          <div className="my-8 border-y border-dashed border-amber-300 py-8">
            <p className="text-sm text-slate-600">بدین‌وسیله گواهی می‌شود قرآن‌آموز</p>
            <p className="mt-3 text-3xl font-black text-emerald-800 sm:text-4xl">{fullName}</p>
            <p className="mt-5 text-sm leading-7 text-slate-700">
              دوره آموزشی
              <span className="mx-2 font-extrabold text-emerald-900">{certificate.courseName}</span>
              را با موفقیت در سطح
              <span className="mx-2 font-extrabold text-emerald-900">{certificate.level || "قرآنی"}</span>
              به مدت
              <span className="mx-2 font-extrabold text-emerald-900">
                {faDigits(certificate.hours)} ساعت
              </span>
              گذراند و با کسب ارزشیابی
              <span className="mx-2 font-extrabold text-amber-700">{certificate.grade}</span>
              فارغ‌التحصیل شد.
            </p>
          </div>

          <div className="grid gap-6 text-xs text-slate-600 sm:grid-cols-3">
            <div>
              <p className="font-bold text-emerald-800">تاریخ صدور</p>
              <p className="mt-1">{faDateLong(certificate.issuedAt)}</p>
            </div>
            <div>
              <p className="font-bold text-emerald-800">مدرس دوره</p>
              <p className="mt-1">{certificate.teacherName || "—"}</p>
            </div>
            <div>
              <p className="font-bold text-emerald-800">شماره سری گواهی</p>
              <p className="mt-1 font-mono" dir="ltr">
                {certificate.serial}
              </p>
            </div>
          </div>

          <div className="mt-10 flex items-center justify-between text-[11px] text-slate-500">
            <span>مدیر مجموعه: حاج آقا رسول هدایتی</span>
            <span className="font-mono" dir="ltr">
              maarej.quran
            </span>
            <span>مهر و امضای مجموعه</span>
          </div>

          <div className="mx-auto mt-6 h-2 w-32 rounded-full bg-gradient-to-l from-emerald-600 to-amber-300" />
        </div>
      </div>

      <p className="mx-auto mt-4 max-w-3xl text-center text-xs text-slate-500 no-print">
        برای ذخیره به‌صورت PDF، دکمه چاپ را بزنید و مقصد را «Save as PDF» انتخاب کنید.
      </p>
    </div>
  );
}
