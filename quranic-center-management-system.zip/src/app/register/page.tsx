import Link from "next/link";
import { RegisterForm } from "./register-form";

export const dynamic = "force-dynamic";

export default function RegisterPage() {
  return (
    <div className="pattern-quran flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-xl">
        <div className="mb-6 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-3xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-xl font-black text-amber-300 shadow-lg">
            م
          </span>
          <h1 className="mt-4 text-2xl font-black text-emerald-900">
            ثبت‌نام آنلاین — مجموعه قرآنی معارج
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            سه مرحله کوتاه، فقط اطلاعات ضروری. پیام ثبت‌نام شما بلافاصله برای مدیر مجموعه ارسال
            می‌شود.
          </p>
        </div>
        <div className="card p-5 sm:p-6">
          <RegisterForm />
        </div>
        <p className="mt-5 text-center text-sm text-slate-500">
          قبلاً ثبت‌نام کرده‌اید؟{" "}
          <Link href="/login" className="font-extrabold text-emerald-700 hover:underline">
            ورود به سامانه
          </Link>
        </p>
      </div>
    </div>
  );
}
