"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { CheckCircle2, ChevronLeft, ChevronRight, Loader2, UserPlus } from "lucide-react";
import { LEVELS, TEACHER_SPECIALTIES } from "@/lib/labels";
import { registerUser } from "@/lib/actions";

type RoleChoice = "student" | "teacher" | "parent";

const roleOptions: { value: RoleChoice; title: string; text: string }[] = [
  { value: "student", title: "قرآن‌آموز", text: "برنامه کلاس، مسیر حفظ، آزمون‌ها" },
  { value: "teacher", title: "استاد", text: "کلاس‌ها، حضور و غیاب، نمرات" },
  { value: "parent", title: "ولی قرآن‌آموز", text: "گزارش پیشرفت فرزند و پرداخت‌ها" },
];

export function RegisterForm() {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState<RoleChoice>("student");
  const [fullName, setFullName] = useState("");
  const [mobile, setMobile] = useState("");
  const [level, setLevel] = useState("rokhani");
  const [birthDate, setBirthDate] = useState("");
  const [nationalCode, setNationalCode] = useState("");
  const [guardianName, setGuardianName] = useState("");
  const [address, setAddress] = useState("");
  const [education, setEducation] = useState("");
  const [childNationalCode, setChildNationalCode] = useState("");
  const [specialties, setSpecialties] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [pending, startTransition] = useTransition();

  function toggleSpecialty(value: string) {
    setSpecialties((prev) =>
      prev.includes(value) ? prev.filter((item) => item !== value) : [...prev, value],
    );
  }

  function submit() {
    setError("");
    startTransition(async () => {
      const result = await registerUser({
        role,
        fullName,
        mobile,
        level: level as never,
        birthDate: birthDate || undefined,
        nationalCode,
        guardianName,
        address,
        education,
        childNationalCode,
        specialties,
      });
      if (!result.ok) {
        setError(result.message);
        return;
      }
      setDone(true);
    });
  }

  if (done) {
    return (
      <div className="space-y-4 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-600" />
        <h2 className="text-xl font-black text-emerald-900">ثبت‌نام انجام شد ✓</h2>
        <p className="text-sm leading-6 text-slate-600">
          پرونده شما ایجاد شد و پیام ثبت‌نام برای مدیریت مجموعه ارسال گردید. پس از تأیید مدیریت
          می‌توانید با شماره موبایل خود وارد داشبورد اختصاصی شوید.
        </p>
        <Link href="/login" className="btn btn-primary w-full py-3">
          رفتن به صفحه ورود
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <ol className="flex items-center gap-2 text-xs font-bold">
        {["انتخاب نقش", "اطلاعات ضروری", "تأیید"].map((title, index) => {
          const value = index + 1;
          return (
            <li
              key={title}
              className={`flex flex-1 items-center gap-2 rounded-xl px-2 py-2 ${
                step === value
                  ? "bg-emerald-600 text-white"
                  : step > value
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-slate-50 text-slate-400"
              }`}
            >
              <span className="grid h-6 w-6 place-items-center rounded-full bg-white/25">
                {value}
              </span>
              <span className="truncate">{title}</span>
            </li>
          );
        })}
      </ol>

      {step === 1 && (
        <div className="space-y-3">
          {roleOptions.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setRole(option.value)}
              className={`flex w-full items-center justify-between rounded-2xl border p-4 text-right transition ${
                role === option.value
                  ? "border-emerald-500 bg-emerald-50"
                  : "border-slate-200 hover:border-emerald-300"
              }`}
            >
              <span>
                <span className="block font-extrabold text-emerald-900">{option.title}</span>
                <span className="mt-0.5 block text-xs text-slate-500">{option.text}</span>
              </span>
              {role === option.value && <CheckCircle2 className="h-5 w-5 text-emerald-600" />}
            </button>
          ))}
          <button type="button" className="btn btn-primary w-full py-3" onClick={() => setStep(2)}>
            مرحله بعد <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label">نام و نام خانوادگی</label>
              <input
                className="input"
                value={fullName}
                onChange={(event) => setFullName(event.target.value)}
                placeholder="مثال: مهدی محمدی"
              />
            </div>
            <div>
              <label className="label">شماره موبایل</label>
              <input
                className="input text-left font-mono"
                dir="ltr"
                value={mobile}
                onChange={(event) => setMobile(event.target.value)}
                placeholder="0912..."
                inputMode="numeric"
              />
            </div>
          </div>

          {role === "student" && (
            <>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="label">سطح آموزشی</label>
                  <select
                    className="select"
                    value={level}
                    onChange={(event) => setLevel(event.target.value)}
                  >
                    {LEVELS.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">تاریخ تولد (میلادی)</label>
                  <input
                    type="date"
                    className="input"
                    dir="ltr"
                    value={birthDate}
                    onChange={(event) => setBirthDate(event.target.value)}
                  />
                </div>
                <div>
                  <label className="label">کد ملی</label>
                  <input
                    className="input"
                    dir="ltr"
                    value={nationalCode}
                    onChange={(event) => setNationalCode(event.target.value)}
                    inputMode="numeric"
                  />
                </div>
                <div>
                  <label className="label">نام ولی</label>
                  <input
                    className="input"
                    value={guardianName}
                    onChange={(event) => setGuardianName(event.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="label">نشانی (اختیاری)</label>
                <textarea
                  className="textarea"
                  rows={2}
                  value={address}
                  onChange={(event) => setAddress(event.target.value)}
                />
              </div>
            </>
          )}

          {role === "teacher" && (
            <>
              <div>
                <label className="label">تخصص‌ها</label>
                <div className="flex flex-wrap gap-2">
                  {TEACHER_SPECIALTIES.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleSpecialty(item)}
                      className={`rounded-xl border px-3 py-1.5 text-sm font-bold transition ${
                        specialties.includes(item)
                          ? "border-emerald-500 bg-emerald-600 text-white"
                          : "border-slate-200 text-slate-600 hover:border-emerald-300"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="label">مدرک و سوابق (اختیاری)</label>
                <textarea
                  className="textarea"
                  rows={2}
                  value={education}
                  onChange={(event) => setEducation(event.target.value)}
                />
              </div>
            </>
          )}

          {role === "parent" && (
            <div>
              <label className="label">کد ملی فرزند (برای اتصال پرونده)</label>
              <input
                className="input"
                dir="ltr"
                value={childNationalCode}
                onChange={(event) => setChildNationalCode(event.target.value)}
                inputMode="numeric"
              />
              <p className="mt-1 text-xs text-slate-400">
                در صورت خالی بودن، بعداً توسط مدیریت مجموعه به پرونده فرزند متصل می‌شوید.
              </p>
            </div>
          )}

          <div className="flex gap-2">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(1)}>
              <ChevronRight className="h-4 w-4" /> بازگشت
            </button>
            <button type="button" className="btn btn-primary flex-1" onClick={() => setStep(3)}>
              مرحله بعد <ChevronLeft className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-emerald-100 bg-emerald-50/60 p-4 text-sm leading-6 text-emerald-900">
            <p className="font-extrabold">بازبینی اطلاعات</p>
            <p className="mt-2">
              نقش: <b>{roleOptions.find((r) => r.value === role)?.title}</b> — نام: <b>{fullName}</b>{" "}
              — موبایل: <b dir="ltr">{mobile}</b>
            </p>
            {role === "student" && (
              <p className="mt-1">
                سطح: <b>{LEVELS.find((l) => l.value === level)?.label}</b> — کد ملی:{" "}
                <b dir="ltr">{nationalCode || "—"}</b>
              </p>
            )}
            {role === "teacher" && (
              <p className="mt-1">
                تخصص‌ها: <b>{specialties.join("، ") || "—"}</b>
              </p>
            )}
            <p className="mt-2 text-xs text-emerald-700">
              با ثبت نهایی، پیام ثبت‌نام شما برای مدیریت مجموعه ارسال می‌شود.
            </p>
          </div>
          <div className="flex gap-2">
            <button type="button" className="btn btn-ghost" onClick={() => setStep(2)}>
              <ChevronRight className="h-4 w-4" /> بازگشت
            </button>
            <button
              type="button"
              className="btn btn-gold flex-1 py-3"
              onClick={submit}
              disabled={pending}
            >
              {pending ? <Loader2 className="h-5 w-5 animate-spin" /> : <UserPlus className="h-5 w-5" />}
              ثبت نهایی
            </button>
          </div>
        </div>
      )}

      {error && (
        <p className="rounded-xl bg-rose-50 px-4 py-3 text-sm font-bold text-rose-700 ring-1 ring-rose-200">
          {error}
        </p>
      )}
    </div>
  );
}
