"use client";

import { useState } from "react";
import { Bell, CreditCard, Loader2, Plus, Save, Trash2, UserPlus } from "lucide-react";
import {
  createClass,
  createDonation,
  createEvent,
  createPayment,
  createStudent,
  createTeacher,
  enrollStudent,
  generateSessions,
  issueCertificate,
  markAllRead,
  markPaymentPaid,
  payOnline,
  sendNotification,
  setStudentStatus,
  setTeacherStatus,
  updateClassTeacher,
  updateStudent,
} from "@/lib/actions";
import { LEVELS, TEACHER_SPECIALTIES, classModeMeta } from "@/lib/labels";
import { Feedback, useAction } from "@/components/feedback";
import { Card } from "@/components/ui";

function Collapsible({
  title,
  children,
  openLabel,
}: {
  title: string;
  children: React.ReactNode;
  openLabel?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen((prev) => !prev)}>
        {open ? "بستن" : (openLabel ?? title)}
        <Plus className="h-4 w-4" />
      </button>
      {open && <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50/60 p-4">{children}</div>}
    </div>
  );
}

/* --------------------------- قرآن‌آموزان ------------------------------- */

export function StudentCreator() {
  const { pending, msg, run } = useAction();
  const [form, setForm] = useState({
    fullName: "",
    mobile: "",
    level: "rokhani",
    guardianName: "",
    nationalCode: "",
  });
  const set = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm((prev) => ({ ...prev, [key]: event.target.value }));

  return (
    <Collapsible title="قرآن‌آموز جدید">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              createStudent({
                ...form,
                level: form.level as never,
              }),
            true,
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">نام و نام خانوادگی</label>
            <input className="input" value={form.fullName} onChange={set("fullName")} />
          </div>
          <div>
            <label className="label">موبایل</label>
            <input className="input" dir="ltr" value={form.mobile} onChange={set("mobile")} />
          </div>
          <div>
            <label className="label">سطح</label>
            <select className="select" value={form.level} onChange={set("level")}>
              {LEVELS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">نام ولی</label>
            <input className="input" value={form.guardianName} onChange={set("guardianName")} />
          </div>
          <div>
            <label className="label">کد ملی</label>
            <input className="input" dir="ltr" value={form.nationalCode} onChange={set("nationalCode")} />
          </div>
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
          ثبت قرآن‌آموز
        </button>
      </form>
    </Collapsible>
  );
}

export function StudentStatusActions({
  studentId,
  status,
}: {
  studentId: number;
  status: string;
}) {
  const { pending, msg, run } = useAction();
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        {status !== "active" && (
          <button
            type="button"
            className="btn btn-primary btn-sm"
            disabled={pending}
            onClick={() => run(() => setStudentStatus(studentId, "active"))}
          >
            تأیید پرونده
          </button>
        )}
        {status !== "rejected" && (
          <button
            type="button"
            className="btn btn-danger btn-sm"
            disabled={pending}
            onClick={() => run(() => setStudentStatus(studentId, "rejected"))}
          >
            رد
          </button>
        )}
      </div>
      <Feedback msg={msg} />
    </div>
  );
}

export function StudentEditor({
  studentId,
  initial,
  parents,
}: {
  studentId: number;
  initial: {
    fullName: string;
    level: string;
    nationalCode: string;
    guardianName: string;
    address: string;
    history: string;
    parentUserId: number | null;
  };
  parents: { id: number; fullName: string }[];
}) {
  const { pending, msg, run } = useAction();
  const [form, setForm] = useState({ ...initial, parentUserId: initial.parentUserId ?? 0 });

  return (
    <Card title="ویرایش پرونده">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              updateStudent({
                studentId,
                fullName: form.fullName,
                level: form.level as never,
                nationalCode: form.nationalCode,
                guardianName: form.guardianName,
                address: form.address,
                history: form.history,
                parentUserId: form.parentUserId || null,
              }),
            true,
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">نام و نام خانوادگی</label>
            <input
              className="input"
              value={form.fullName}
              onChange={(event) => setForm({ ...form, fullName: event.target.value })}
            />
          </div>
          <div>
            <label className="label">سطح آموزشی</label>
            <select
              className="select"
              value={form.level}
              onChange={(event) => setForm({ ...form, level: event.target.value })}
            >
              {LEVELS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">کد ملی</label>
            <input
              className="input"
              dir="ltr"
              value={form.nationalCode}
              onChange={(event) => setForm({ ...form, nationalCode: event.target.value })}
            />
          </div>
          <div>
            <label className="label">نام ولی</label>
            <input
              className="input"
              value={form.guardianName}
              onChange={(event) => setForm({ ...form, guardianName: event.target.value })}
            />
          </div>
          <div>
            <label className="label">حساب ولی متصل</label>
            <select
              className="select"
              value={form.parentUserId}
              onChange={(event) => setForm({ ...form, parentUserId: Number(event.target.value) })}
            >
              <option value={0}>بدون ولی</option>
              {parents.map((parent) => (
                <option key={parent.id} value={parent.id}>
                  {parent.fullName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">نشانی</label>
            <input
              className="input"
              value={form.address}
              onChange={(event) => setForm({ ...form, address: event.target.value })}
            />
          </div>
        </div>
        <div>
          <label className="label">سوابق و یادداشت‌ها</label>
          <textarea
            className="textarea"
            rows={3}
            value={form.history}
            onChange={(event) => setForm({ ...form, history: event.target.value })}
          />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          ذخیره پرونده
        </button>
      </form>
    </Card>
  );
}

/* ------------------------------ اساتید -------------------------------- */

export function TeacherCreator() {
  const { pending, msg, run } = useAction();
  const [fullName, setFullName] = useState("");
  const [mobile, setMobile] = useState("");
  const [education, setEducation] = useState("");
  const [specialties, setSpecialties] = useState<string[]>([]);

  return (
    <Collapsible title="استاد جدید">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(() => createTeacher({ fullName, mobile, education, specialties }), true);
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">نام و نام خانوادگی</label>
            <input className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div>
            <label className="label">موبایل</label>
            <input className="input" dir="ltr" value={mobile} onChange={(e) => setMobile(e.target.value)} />
          </div>
        </div>
        <div>
          <label className="label">تخصص‌ها</label>
          <div className="flex flex-wrap gap-2">
            {TEACHER_SPECIALTIES.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() =>
                  setSpecialties((prev) =>
                    prev.includes(item) ? prev.filter((s) => s !== item) : [...prev, item],
                  )
                }
                className={`rounded-xl border px-3 py-1.5 text-sm font-bold transition ${
                  specialties.includes(item)
                    ? "border-emerald-500 bg-emerald-600 text-white"
                    : "border-slate-200 text-slate-600"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="label">مدرک</label>
          <input className="input" value={education} onChange={(e) => setEducation(e.target.value)} />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
          ثبت استاد
        </button>
      </form>
    </Collapsible>
  );
}

export function TeacherStatusActions({ teacherId, status }: { teacherId: number; status: string }) {
  const { pending, msg, run } = useAction();
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        {status !== "active" && (
          <button
            type="button"
            className="btn btn-primary btn-sm"
            disabled={pending}
            onClick={() => run(() => setTeacherStatus(teacherId, "active"))}
          >
            تأیید
          </button>
        )}
        {status !== "rejected" && (
          <button
            type="button"
            className="btn btn-danger btn-sm"
            disabled={pending}
            onClick={() => run(() => setTeacherStatus(teacherId, "rejected"))}
          >
            رد
          </button>
        )}
      </div>
      <Feedback msg={msg} />
    </div>
  );
}

/* ------------------------------ کلاس‌ها ------------------------------- */

export function ClassCreator({ teachers }: { teachers: { id: number; fullName: string }[] }) {
  const { pending, msg, run } = useAction();
  const [form, setForm] = useState({
    name: "",
    courseType: "hifz",
    teacherId: String(teachers[0]?.id ?? ""),
    startTime: "17:00",
    durationMinutes: "90",
    location: "",
    mode: "inperson",
    capacity: "15",
    tuition: "500000",
    startDate: new Date().toISOString().slice(0, 10),
    description: "",
  });
  const [days, setDays] = useState<number[]>([0, 2]);

  return (
    <Collapsible title="کلاس / دوره جدید">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              createClass({
                name: form.name,
                courseType: form.courseType as never,
                teacherId: form.teacherId ? Number(form.teacherId) : null,
                days,
                startTime: form.startTime,
                durationMinutes: Number(form.durationMinutes),
                location: form.location,
                mode: form.mode as never,
                capacity: Number(form.capacity),
                tuition: Number(form.tuition),
                startDate: form.startDate,
                description: form.description,
              }),
            true,
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">نام کلاس</label>
            <input
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>
          <div>
            <label className="label">نوع دوره</label>
            <select
              className="select"
              value={form.courseType}
              onChange={(e) => setForm({ ...form, courseType: e.target.value })}
            >
              {LEVELS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">استاد</label>
            <select
              className="select"
              value={form.teacherId}
              onChange={(e) => setForm({ ...form, teacherId: e.target.value })}
            >
              <option value="">بدون استاد</option>
              {teachers.map((teacher) => (
                <option key={teacher.id} value={teacher.id}>
                  {teacher.fullName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">نوع برگزاری</label>
            <select
              className="select"
              value={form.mode}
              onChange={(e) => setForm({ ...form, mode: e.target.value })}
            >
              {Object.entries(classModeMeta).map(([value, meta]) => (
                <option key={value} value={value}>
                  {meta.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">ساعت شروع</label>
            <input
              type="time"
              dir="ltr"
              className="input"
              value={form.startTime}
              onChange={(e) => setForm({ ...form, startTime: e.target.value })}
            />
          </div>
          <div>
            <label className="label">مدت (دقیقه)</label>
            <input
              type="number"
              className="input"
              value={form.durationMinutes}
              onChange={(e) => setForm({ ...form, durationMinutes: e.target.value })}
            />
          </div>
          <div>
            <label className="label">مکان / لینک</label>
            <input
              className="input"
              value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })}
            />
          </div>
          <div>
            <label className="label">ظرفیت</label>
            <input
              type="number"
              className="input"
              value={form.capacity}
              onChange={(e) => setForm({ ...form, capacity: e.target.value })}
            />
          </div>
          <div>
            <label className="label">شهریه (تومان)</label>
            <input
              type="number"
              className="input"
              value={form.tuition}
              onChange={(e) => setForm({ ...form, tuition: e.target.value })}
            />
          </div>
          <div>
            <label className="label">تاریخ شروع</label>
            <input
              type="date"
              dir="ltr"
              className="input"
              value={form.startDate}
              onChange={(e) => setForm({ ...form, startDate: e.target.value })}
            />
          </div>
        </div>
        <div>
          <label className="label">روزهای برگزاری</label>
          <div className="flex flex-wrap gap-2">
            {["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"].map(
              (day, index) => (
                <button
                  key={day}
                  type="button"
                  onClick={() =>
                    setDays((prev) =>
                      prev.includes(index) ? prev.filter((d) => d !== index) : [...prev, index],
                    )
                  }
                  className={`rounded-xl border px-3 py-1.5 text-sm font-bold transition ${
                    days.includes(index)
                      ? "border-emerald-500 bg-emerald-600 text-white"
                      : "border-slate-200 text-slate-600"
                  }`}
                >
                  {day}
                </button>
              ),
            )}
          </div>
        </div>
        <div>
          <label className="label">توضیحات</label>
          <textarea
            className="textarea"
            rows={2}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
          />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          ایجاد کلاس
        </button>
      </form>
    </Collapsible>
  );
}

export function ClassEnroller({
  classId,
  students,
}: {
  classId: number;
  students: { id: number; fullName: string }[];
}) {
  const { pending, msg, run } = useAction();
  const [studentId, setStudentId] = useState(String(students[0]?.id ?? ""));
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-end gap-2">
        <div className="min-w-52 flex-1">
          <label className="label">افزودن قرآن‌آموز به کلاس</label>
          <select className="select" value={studentId} onChange={(e) => setStudentId(e.target.value)}>
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.fullName}
              </option>
            ))}
          </select>
        </div>
        <button
          type="button"
          className="btn btn-primary"
          disabled={pending || students.length === 0}
          onClick={() => run(() => enrollStudent(classId, Number(studentId)))}
        >
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          ثبت‌نام در کلاس
        </button>
      </div>
      <Feedback msg={msg} />
    </div>
  );
}

export function SessionGenerator({ classId }: { classId: number }) {
  const { pending, msg, run } = useAction();
  return (
    <div className="space-y-2">
      <button
        type="button"
        className="btn btn-gold btn-sm"
        disabled={pending}
        onClick={() => run(() => generateSessions(classId))}
      >
        {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
        تولید جلسات ۴ هفته آینده
      </button>
      <Feedback msg={msg} />
    </div>
  );
}

export function TeacherAssigner({
  classId,
  teachers,
  current,
}: {
  classId: number;
  teachers: { id: number; fullName: string }[];
  current: number | null;
}) {
  const { pending, msg, run } = useAction();
  const [teacherId, setTeacherId] = useState(String(current ?? ""));
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-end gap-2">
        <div className="min-w-48">
          <label className="label">انتصاب استاد</label>
          <select className="select" value={teacherId} onChange={(e) => setTeacherId(e.target.value)}>
            <option value="">بدون استاد</option>
            {teachers.map((teacher) => (
              <option key={teacher.id} value={teacher.id}>
                {teacher.fullName}
              </option>
            ))}
          </select>
        </div>
        <button
          type="button"
          className="btn btn-primary"
          disabled={pending}
          onClick={() =>
            run(() => updateClassTeacher(classId, teacherId ? Number(teacherId) : null))
          }
        >
          ثبت انتصاب
        </button>
      </div>
      <Feedback msg={msg} />
    </div>
  );
}

/* ------------------------------ مالی ---------------------------------- */

export function PaymentCreator({ students }: { students: { id: number; fullName: string }[] }) {
  const { pending, msg, run } = useAction();
  const [studentId, setStudentId] = useState(String(students[0]?.id ?? ""));
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState("500000");
  const [kind, setKind] = useState("tuition");
  const [dueDate, setDueDate] = useState(new Date().toISOString().slice(0, 10));

  return (
    <Collapsible title="ثبت شهریه / بدهی جدید">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              createPayment({
                studentId: studentId ? Number(studentId) : null,
                title: title || "شهریه دوره",
                amount: Number(amount),
                kind: kind as never,
                dueDate,
              }),
            true,
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">قرآن‌آموز</label>
            <select className="select" value={studentId} onChange={(e) => setStudentId(e.target.value)}>
              <option value="">بدون قرآن‌آموز (کمک مالی)</option>
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.fullName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">نوع</label>
            <select className="select" value={kind} onChange={(e) => setKind(e.target.value)}>
              <option value="tuition">شهریه</option>
              <option value="donation">کمک به هیئت امنا</option>
              <option value="other">متفرقه</option>
            </select>
          </div>
          <div>
            <label className="label">عنوان</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <label className="label">مبلغ (تومان)</label>
            <input
              type="number"
              className="input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div>
            <label className="label">سررسید</label>
            <input
              type="date"
              dir="ltr"
              className="input"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
          </div>
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          ثبت
        </button>
      </form>
    </Collapsible>
  );
}

export function PaymentActions({ paymentId, status }: { paymentId: number; status: string }) {
  const { pending, msg, run } = useAction();
  if (status === "paid") return <span className="text-xs text-emerald-700">تسویه شده ✓</span>;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          className="btn btn-gold btn-sm"
          disabled={pending}
          onClick={() => run(() => payOnline(paymentId))}
        >
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
          پرداخت آنلاین
        </button>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          disabled={pending}
          onClick={() => run(() => markPaymentPaid(paymentId, "ثبت دستی مدیریت"))}
        >
          ثبت پرداخت دستی
        </button>
      </div>
      <Feedback msg={msg} />
    </div>
  );
}

export function DonationForm() {
  const { pending, msg, run } = useAction();
  const [amount, setAmount] = useState("1000000");
  const [note, setNote] = useState("کمک به هیئت امنا");
  return (
    <Card title="کمک به هیئت امنا" subtitle="حمایت مالی شما صرف تجهیزات و برنامه‌های فرهنگی می‌شود">
      <form
        className="space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          run(() => createDonation({ amount: Number(amount), note }), true);
        }}
      >
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label">مبلغ (تومان)</label>
            <input
              type="number"
              className="input"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div>
            <label className="label">بابت</label>
            <input className="input" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-gold" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
          ثبت کمک مالی
        </button>
      </form>
    </Card>
  );
}

/* --------------------------- پیام‌رسانی -------------------------------- */

export function MessageComposer({
  people,
  defaultTarget = "all",
}: {
  people: { id: number; fullName: string; role: string }[];
  defaultTarget?: string;
}) {
  const { pending, msg, run } = useAction();
  const [target, setTarget] = useState(defaultTarget);
  const [userId, setUserId] = useState(String(people[0]?.id ?? ""));
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [kind, setKind] = useState("general");

  return (
    <Card title="ارسال اعلان" subtitle="اطلاع‌رسانی به اولیا و قرآن‌آموزان (پیام درون‌برنامه‌ای)">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              sendNotification({
                target: target as never,
                userId: target === "user" ? Number(userId) : undefined,
                title,
                body,
                kind,
              }),
            true,
          );
          setTitle("");
          setBody("");
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">گیرنده</label>
            <select className="select" value={target} onChange={(e) => setTarget(e.target.value)}>
              <option value="all">همه کاربران</option>
              <option value="students">همه قرآن‌آموزان</option>
              <option value="parents">همه اولیا</option>
              <option value="teachers">همه اساتید</option>
              <option value="user">یک کاربر مشخص</option>
            </select>
          </div>
          <div>
            <label className="label">موضوع پیام</label>
            <select className="select" value={kind} onChange={(e) => setKind(e.target.value)}>
              <option value="general">عمومی</option>
              <option value="absence">غیبت</option>
              <option value="exam">آزمون</option>
              <option value="payment">مالی</option>
              <option value="registration">ثبت‌نام</option>
            </select>
          </div>
          {target === "user" && (
            <div className="sm:col-span-2">
              <label className="label">کاربر</label>
              <select className="select" value={userId} onChange={(e) => setUserId(e.target.value)}>
                {people.map((person) => (
                  <option key={person.id} value={person.id}>
                    {person.fullName} — {person.role}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
        <div>
          <label className="label">عنوان</label>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div>
          <label className="label">متن پیام</label>
          <textarea
            className="textarea"
            rows={3}
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
          ارسال اعلان
        </button>
      </form>
    </Card>
  );
}

export function MarkAllReadButton() {
  const { pending, msg, run } = useAction();
  return (
    <div className="flex flex-col items-end gap-2">
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        disabled={pending}
        onClick={() => run(() => markAllRead())}
      >
        {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bell className="h-4 w-4" />}
        علامت‌گذاری همه به‌عنوان خوانده‌شده
      </button>
      <Feedback msg={msg} />
    </div>
  );
}

/* ------------------------- گواهی و تقویم ------------------------------- */

export function CertificateIssuer({
  students,
  classes,
}: {
  students: { id: number; fullName: string }[];
  classes: { id: number; name: string }[];
}) {
  const { pending, msg, run } = useAction();
  const [studentId, setStudentId] = useState(String(students[0]?.id ?? ""));
  const [classId, setClassId] = useState(String(classes[0]?.id ?? ""));
  const [courseName, setCourseName] = useState(classes[0]?.name ?? "");
  const [level, setLevel] = useState("حفظ");
  const [grade, setGrade] = useState("خیلی خوب");
  const [hours, setHours] = useState("60");

  return (
    <Card title="صدور گواهی پایان دوره" subtitle="گواهی با طراحی اختصاصی و خروجی PDF">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              issueCertificate({
                studentId: Number(studentId),
                classId: classId ? Number(classId) : null,
                courseName,
                level,
                grade,
                teacherName: "",
                hours: Number(hours),
              }),
            true,
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">قرآن‌آموز</label>
            <select
              className="select"
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
            >
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.fullName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">کلاس</label>
            <select
              className="select"
              value={classId}
              onChange={(e) => {
                setClassId(e.target.value);
                const found = classes.find((cls) => String(cls.id) === e.target.value);
                if (found) setCourseName(found.name);
              }}
            >
              {classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">عنوان دوره</label>
            <input
              className="input"
              value={courseName}
              onChange={(e) => setCourseName(e.target.value)}
            />
          </div>
          <div>
            <label className="label">سطح</label>
            <input className="input" value={level} onChange={(e) => setLevel(e.target.value)} />
          </div>
          <div>
            <label className="label">مقدار تشخیص</label>
            <input className="input" value={grade} onChange={(e) => setGrade(e.target.value)} />
          </div>
          <div>
            <label className="label">ساعت دوره</label>
            <input
              type="number"
              className="input"
              value={hours}
              onChange={(e) => setHours(e.target.value)}
            />
          </div>
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-gold" disabled={pending || students.length === 0}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          صدور گواهی
        </button>
      </form>
    </Card>
  );
}

export function EventCreator() {
  const { pending, msg, run } = useAction();
  const [title, setTitle] = useState("");
  const [eventType, setEventType] = useState("exam");
  const [eventDate, setEventDate] = useState(new Date().toISOString().slice(0, 10));
  const [description, setDescription] = useState("");

  return (
    <Card title="افزودن رویداد به تقویم" subtitle="آزمون، مناسبت، اردو یا جلسه">
      <form
        className="space-y-3"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              createEvent({
                title,
                eventType: eventType as never,
                eventDate,
                description,
              }),
            true,
          );
          setTitle("");
          setDescription("");
        }}
      >
        <div className="grid gap-3 sm:grid-cols-3">
          <div>
            <label className="label">عنوان</label>
            <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <label className="label">نوع</label>
            <select className="select" value={eventType} onChange={(e) => setEventType(e.target.value)}>
              <option value="exam">آزمون</option>
              <option value="occasion">مناسبت</option>
              <option value="trip">اردو</option>
              <option value="meeting">جلسه</option>
            </select>
          </div>
          <div>
            <label className="label">تاریخ</label>
            <input
              type="date"
              dir="ltr"
              className="input"
              value={eventDate}
              onChange={(e) => setEventDate(e.target.value)}
            />
          </div>
        </div>
        <div>
          <label className="label">توضیحات</label>
          <input
            className="input"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          افزودن رویداد
        </button>
      </form>
    </Card>
  );
}

export function DeleteEventButton({ eventId }: { eventId: number }) {
  const { pending, run } = useAction();
  return (
    <button
      type="button"
      className="rounded-lg p-1.5 text-rose-600 hover:bg-rose-50"
      aria-label="حذف رویداد"
      disabled={pending}
      onClick={() => run(() => import("@/lib/actions").then((m) => m.deleteEvent(eventId)))}
    >
      <Trash2 className="h-4 w-4" />
    </button>
  );
}
