"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  Award,
  Bell,
  BookOpenCheck,
  CalendarDays,
  ClipboardList,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  Mic,
  School,
  Sparkles,
  Users,
  Wallet,
  X,
} from "lucide-react";
import type { Role } from "@/db/schema";
import { faDigits } from "@/lib/jalali";
import { logout } from "@/lib/actions";

type NavItem = { href: string; label: string; icon: ReactNode };
type NavGroup = { title: string; items: NavItem[] };

function navFor(role: Role, unread: number): NavGroup[] {
  const dashboard: NavItem = {
    href: "/dashboard",
    label: "داشبورد",
    icon: <LayoutDashboard className="h-5 w-5" />,
  };
  const messages: NavItem = {
    href: "/messages",
    label: "پیام‌ها",
    icon: <Bell className="h-5 w-5" />,
  };
  const calendar: NavItem = {
    href: "/calendar",
    label: "تقویم و برنامه",
    icon: <CalendarDays className="h-5 w-5" />,
  };

  if (role === "manager") {
    return [
      {
        title: "مدیریت مجموعه",
        items: [
          dashboard,
          { href: "/students", label: "قرآن‌آموزان", icon: <Users className="h-5 w-5" /> },
          { href: "/teachers", label: "اساتید", icon: <GraduationCap className="h-5 w-5" /> },
          { href: "/classes", label: "کلاس‌ها و دوره‌ها", icon: <School className="h-5 w-5" /> },
        ],
      },
      {
        title: "برنامه و ارزشیابی",
        items: [
          calendar,
          { href: "/attendance", label: "حضور و غیاب", icon: <ClipboardList className="h-5 w-5" /> },
          { href: "/exams", label: "آزمون‌ها", icon: <BookOpenCheck className="h-5 w-5" /> },
          { href: "/hifz", label: "مسیر حفظ", icon: <Sparkles className="h-5 w-5" /> },
        ],
      },
      {
        title: "مالی و گزارش",
        items: [
          { href: "/finance", label: "امور مالی", icon: <Wallet className="h-5 w-5" /> },
          { href: "/reports", label: "گزارش‌ها", icon: <ClipboardList className="h-5 w-5" /> },
        ],
      },
      {
        title: "ارتباطات",
        items: [
          { ...messages, label: unread > 0 ? `پیام‌ها (${faDigits(unread)})` : "پیام‌ها" },
          { href: "/recordings", label: "صوت تلاوت", icon: <Mic className="h-5 w-5" /> },
          { href: "/certificates", label: "گواهی‌ها", icon: <Award className="h-5 w-5" /> },
        ],
      },
    ];
  }

  if (role === "teacher") {
    return [
      {
        title: "آموزش",
        items: [
          dashboard,
          { href: "/classes", label: "کلاس‌های من", icon: <School className="h-5 w-5" /> },
          { href: "/attendance", label: "حضور و غیاب", icon: <ClipboardList className="h-5 w-5" /> },
          { href: "/exams", label: "آزمون‌ها و نمرات", icon: <BookOpenCheck className="h-5 w-5" /> },
          { href: "/hifz", label: "مسیر حفظ", icon: <Sparkles className="h-5 w-5" /> },
        ],
      },
      {
        title: "سایر",
        items: [
          calendar,
          { href: "/recordings", label: "تصحیح تلاوت", icon: <Mic className="h-5 w-5" /> },
          { ...messages, label: unread > 0 ? `پیام‌ها (${faDigits(unread)})` : "پیام‌ها" },
        ],
      },
    ];
  }

  if (role === "student") {
    return [
      {
        title: "حساب من",
        items: [
          dashboard,
          { href: "/classes", label: "برنامه کلاس‌ها", icon: <School className="h-5 w-5" /> },
          { href: "/hifz", label: "مسیر حفظ من", icon: <Sparkles className="h-5 w-5" /> },
          { href: "/exams", label: "آزمون‌ها و کارنامه", icon: <BookOpenCheck className="h-5 w-5" /> },
        ],
      },
      {
        title: "امکانات",
        items: [
          { href: "/recordings", label: "صوت تلاوت", icon: <Mic className="h-5 w-5" /> },
          { href: "/certificates", label: "گواهی‌های من", icon: <Award className="h-5 w-5" /> },
          calendar,
          { ...messages, label: unread > 0 ? `پیام‌ها (${faDigits(unread)})` : "پیام‌ها" },
        ],
      },
    ];
  }

  return [
    {
      title: "حساب من",
      items: [
        dashboard,
        { href: "/students", label: "گزارش پیشرفت فرزند", icon: <Users className="h-5 w-5" /> },
        { href: "/finance", label: "پرداخت‌ها و شهریه", icon: <Wallet className="h-5 w-5" /> },
      ],
    },
    {
      title: "سایر",
      items: [
        calendar,
        { ...messages, label: unread > 0 ? `پیام‌ها (${faDigits(unread)})` : "پیام‌ها" },
      ],
    },
  ];
}

const roleTitles: Record<Role, string> = {
  manager: "مدیر مجموعه",
  teacher: "استاد",
  student: "قرآن‌آموز",
  parent: "ولی قرآن‌آموز",
};

export function AppShell({
  user,
  unread,
  children,
}: {
  user: { id: number; fullName: string; role: Role };
  unread: number;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const groups = navFor(user.role, unread);

  const nav = (
    <nav className="flex flex-col gap-5">
      {groups.map((group) => (
        <div key={group.title}>
          <p className="mb-2 px-3 text-[11px] font-extrabold tracking-wide text-emerald-700/70">
            {group.title}
          </p>
          <ul className="space-y-1">
            {group.items.map((item) => {
              const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition ${
                      active
                        ? "bg-gradient-to-l from-emerald-600 to-emerald-700 text-white shadow-md"
                        : "text-emerald-900/80 hover:bg-emerald-50"
                    }`}
                  >
                    {item.icon}
                    <span className="truncate">{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );

  const brand = (
    <div className="flex items-center gap-3">
      <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-lg font-black text-amber-300 shadow-md">
        م
      </span>
      <div>
        <p className="text-sm font-extrabold text-emerald-900">مجموعه قرآنی معارج</p>
        <p className="text-[11px] text-slate-500">سامانه مدیریت یکپارچه</p>
      </div>
    </div>
  );

  const userBox = (
    <div className="rounded-2xl border border-emerald-100 bg-emerald-50/70 p-3">
      <p className="truncate text-sm font-extrabold text-emerald-900">{user.fullName}</p>
      <p className="mt-0.5 text-[11px] font-bold text-emerald-700">{roleTitles[user.role]}</p>
      <form action={logout} className="mt-3">
        <button type="submit" className="btn btn-ghost btn-sm w-full">
          <LogOut className="h-4 w-4" />
          خروج از حساب
        </button>
      </form>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* سایدبار دسکتاپ — سمت راست */}
      <aside className="sticky top-0 hidden h-screen w-72 shrink-0 flex-col justify-between border-s-0 border-e border-slate-200 bg-white/80 p-4 backdrop-blur lg:flex">
        <div className="space-y-6">
          {brand}
          {nav}
        </div>
        {userBox}
      </aside>

      {/* drawer موبایل */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="بستن منو"
            className="absolute inset-0 bg-emerald-950/50"
            onClick={() => setOpen(false)}
          />
          <div className="absolute inset-y-0 end-0 w-72 overflow-y-auto bg-white p-4 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              {brand}
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="بستن"
                className="rounded-lg p-2 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            {nav}
            <div className="mt-6">{userBox}</div>
          </div>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        {/* هدر موبایل */}
        <header className="sticky top-0 z-40 flex items-center justify-between gap-3 border-b border-slate-200 bg-white/90 px-4 py-3 backdrop-blur lg:hidden">
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="باز کردن منو"
            className="rounded-xl border border-slate-200 p-2 hover:bg-slate-50"
          >
            <Menu className="h-5 w-5" />
          </button>
          <p className="truncate text-sm font-extrabold text-emerald-900">مجموعه قرآنی معارج</p>
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-emerald-700 text-sm font-black text-amber-300">
            {user.fullName.slice(0, 1)}
          </span>
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-5 sm:px-6 sm:py-7">{children}</main>

        <footer className="border-t border-slate-200 bg-white/70 px-4 py-4 text-center text-xs text-slate-500">
          مجموعه فرهنگی قرآنی معارج — سامانه مدیریت یکپارچه | طراحی‌شده برای مدیریت، اساتید،
          قرآن‌آموزان و اولیا
        </footer>
      </div>
    </div>
  );
}
