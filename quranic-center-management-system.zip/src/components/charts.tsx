import { faDigits, faNum } from "@/lib/jalali";

export type ChartPoint = { label: string; value: number };

/** نمودار ستونی — با چینش راست‌به‌چپ */
export function BarChart({
  data,
  unit = "",
  tone = "emerald",
  height = 190,
}: {
  data: ChartPoint[];
  unit?: string;
  tone?: "emerald" | "gold";
  height?: number;
}) {
  if (data.length === 0) return <p className="text-sm text-slate-400">داده‌ای برای نمایش نیست.</p>;
  const max = Math.max(...data.map((d) => d.value), 1);
  const width = 100;
  const slot = width / data.length;
  const barWidth = Math.min(slot * 0.5, 8);

  return (
    <div>
      <svg
        viewBox={`0 0 100 ${height / 4}`}
        className="w-full"
        style={{ height }}
        role="img"
        aria-label="نمودار ستونی"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id={`bar-${tone}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={tone === "gold" ? "#eccb52" : "#34d399"} />
            <stop offset="100%" stopColor={tone === "gold" ? "#c6951b" : "#047857"} />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75, 1].map((line) => (
          <line
            key={line}
            x1="0"
            x2="100"
            y1={(height / 4) * line}
            y2={(height / 4) * line}
            stroke="#e6edeb"
            strokeWidth="0.3"
          />
        ))}
        {data.map((point, index) => {
          const barHeight = (point.value / max) * (height / 4 - 6);
          const x = width - (index + 1) * slot + (slot - barWidth) / 2;
          return (
            <rect
              key={`${point.label}-${index}`}
              x={x}
              y={height / 4 - barHeight - 2}
              width={barWidth}
              height={Math.max(barHeight, 0.6)}
              rx="0.8"
              fill={`url(#bar-${tone})`}
            />
          );
        })}
      </svg>
      <div className="mt-2 flex flex-row-reverse justify-start gap-1 overflow-hidden">
        {data.map((point, index) => (
          <div key={`${point.label}-lbl-${index}`} className="flex-1 text-center">
            <p className="truncate text-[11px] font-bold text-emerald-800">
              {faNum(point.value)}
              {unit ? ` ${unit}` : ""}
            </p>
            <p className="truncate text-[10px] text-slate-500">{point.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/** نمودار خطی روند */
export function LineChart({
  data,
  unit = "٪",
  height = 190,
}: {
  data: ChartPoint[];
  unit?: string;
  height?: number;
}) {
  if (data.length === 0) return <p className="text-sm text-slate-400">داده‌ای برای نمایش نیست.</p>;
  const max = Math.max(...data.map((d) => d.value), 10);
  const w = 100;
  const h = height / 4;
  const step = data.length > 1 ? w / (data.length - 1) : 0;
  const points = data.map((d, i) => ({
    x: w - i * step,
    y: h - (d.value / max) * (h - 6) - 2,
    ...d,
  }));
  const path = points.map((p) => `${p.x},${p.y}`).join(" ");
  const area = `${path} ${points[points.length - 1].x},${h} ${points[0].x},${h}`;

  return (
    <div>
      <svg
        viewBox={`0 0 100 ${h}`}
        className="w-full"
        style={{ height }}
        role="img"
        aria-label="نمودار روند"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="line-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#10b981" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#10b981" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75].map((line) => (
          <line
            key={line}
            x1="0"
            x2="100"
            y1={h * line}
            y2={h * line}
            stroke="#e6edeb"
            strokeWidth="0.3"
          />
        ))}
        <polygon points={area} fill="url(#line-fill)" />
        <polyline points={path} fill="none" stroke="#047857" strokeWidth="0.7" />
        {points.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r="1" fill="#065f46" />
        ))}
      </svg>
      <div className="mt-2 flex flex-row-reverse justify-start gap-1">
        {data.map((point, index) => (
          <div key={`${point.label}-l-${index}`} className="flex-1 text-center">
            <p className="text-[11px] font-bold text-emerald-800">
              {faNum(point.value)}
              {unit}
            </p>
            <p className="truncate text-[10px] text-slate-500">{point.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

/** حلقه پیشرفت */
export function ProgressRing({
  percent,
  size = 116,
  label,
}: {
  percent: number;
  size?: number;
  label?: string;
}) {
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(100, percent) / 100) * circumference;
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="حلقه پیشرفت">
        <circle cx="50" cy="50" r={radius} fill="none" stroke="#e2e8e6" strokeWidth="9" />
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke="#047857"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform="rotate(-90 50 50)"
        />
        <text
          x="50"
          y="54"
          textAnchor="middle"
          fontSize="18"
          fontWeight="800"
          fill="#065f46"
        >
          {faDigits(percent)}٪
        </text>
      </svg>
      {label && <p className="mt-1 text-xs font-bold text-slate-500">{label}</p>}
    </div>
  );
}
