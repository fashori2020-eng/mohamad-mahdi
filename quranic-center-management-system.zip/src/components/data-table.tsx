"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { ArrowUpDown, Search } from "lucide-react";
import { faDigits } from "@/lib/jalali";

export type TableColumn = { key: string; header: string; numeric?: boolean };
export type TableRow = { id: string; values: Record<string, string>; href?: string };

export function DataTable({
  columns,
  rows,
  searchPlaceholder = "جستجو...",
  linkLabel = "مشاهده",
  emptyText = "موردی یافت نشد.",
  pageSize = 12,
}: {
  columns: TableColumn[];
  rows: TableRow[];
  searchPlaceholder?: string;
  linkLabel?: string;
  emptyText?: string;
  pageSize?: number;
}) {
  const [query, setQuery] = useState("");
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [asc, setAsc] = useState(true);
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let result = q
      ? rows.filter((row) =>
          columns.some((col) => (row.values[col.key] ?? "").toLowerCase().includes(q)),
        )
      : [...rows];
    if (sortKey) {
      const col = columns.find((c) => c.key === sortKey);
      result.sort((a, b) => {
        const av = a.values[sortKey] ?? "";
        const bv = b.values[sortKey] ?? "";
        if (col?.numeric) {
          const an = Number(av.replace(/[^\d.-]/g, "")) || 0;
          const bn = Number(bv.replace(/[^\d.-]/g, "")) || 0;
          return asc ? an - bn : bn - an;
        }
        return asc ? av.localeCompare(bv, "fa") : bv.localeCompare(av, "fa");
      });
    }
    return result;
  }, [query, rows, sortKey, asc, columns]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pageCount - 1);
  const visible = filtered.slice(current * pageSize, current * pageSize + pageSize);

  function toggleSort(key: string) {
    if (sortKey === key) {
      setAsc((prev) => !prev);
    } else {
      setSortKey(key);
      setAsc(true);
    }
  }

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="pointer-events-none absolute end-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          className="input ps-4 pe-10"
          placeholder={searchPlaceholder}
          value={query}
          onChange={(event) => {
            setQuery(event.target.value);
            setPage(0);
          }}
          aria-label={searchPlaceholder}
        />
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="tbl">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.key}>
                  <button
                    type="button"
                    onClick={() => toggleSort(col.key)}
                    className="inline-flex items-center gap-1 hover:text-emerald-700"
                  >
                    {col.header}
                    <ArrowUpDown className="h-3 w-3 opacity-60" />
                  </button>
                </th>
              ))}
              {rows.some((r) => r.href) && <th className="w-24">عملیات</th>}
            </tr>
          </thead>
          <tbody>
            {visible.length === 0 && (
              <tr>
                <td colSpan={columns.length + 1} className="py-8 text-center text-slate-400">
                  {emptyText}
                </td>
              </tr>
            )}
            {visible.map((row) => (
              <tr key={row.id}>
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={col.numeric ? "font-bold text-emerald-900" : "text-slate-700"}
                  >
                    {row.values[col.key] || "—"}
                  </td>
                ))}
                {rows.some((r) => r.href) && (
                  <td>
                    {row.href ? (
                      <Link href={row.href} className="btn btn-ghost btn-sm">
                        {linkLabel}
                      </Link>
                    ) : (
                      <span className="text-slate-300">—</span>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
        <span>
          {faDigits(filtered.length)} ردیف — صفحه {faDigits(current + 1)} از {faDigits(pageCount)}
        </span>
        {pageCount > 1 && (
          <div className="flex gap-2">
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              disabled={current === 0}
              onClick={() => setPage(current - 1)}
            >
              قبلی
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              disabled={current >= pageCount - 1}
              onClick={() => setPage(current + 1)}
            >
              بعدی
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
