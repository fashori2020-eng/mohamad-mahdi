"use client";

import { useTransition, useState } from "react";
import { CheckCircle2, Info, Loader2, XCircle } from "lucide-react";
import type { ActionResult } from "@/lib/actions";

export type Msg = { ok: boolean; text: string } | null;

export function useAction() {
  const [pending, startTransition] = useTransition();
  const [msg, setMsg] = useState<Msg>(null);

  function run(fn: () => Promise<ActionResult>, keep = false) {
    startTransition(async () => {
      const result = await fn();
      setMsg({ ok: result.ok, text: result.message });
      if (!keep) {
        setTimeout(() => setMsg(null), 5000);
      }
    });
  }

  return { pending, msg, run };
}

export function Feedback({ msg }: { msg: Msg }) {
  if (!msg) return null;
  return (
    <p
      className={`flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-bold ring-1 ${
        msg.ok
          ? "bg-emerald-50 text-emerald-800 ring-emerald-200"
          : "bg-rose-50 text-rose-700 ring-rose-200"
      }`}
      role="status"
    >
      {msg.ok ? <CheckCircle2 className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
      {msg.text}
    </p>
  );
}

export function Spinner({ pending }: { pending: boolean }) {
  if (!pending) return null;
  return <Loader2 className="h-4 w-4 animate-spin" />;
}

export function InfoBox({ text }: { text: string }) {
  return (
    <p className="flex items-start gap-2 rounded-xl bg-sky-50 px-4 py-3 text-xs leading-6 text-sky-800 ring-1 ring-sky-200">
      <Info className="mt-0.5 h-4 w-4 shrink-0" />
      {text}
    </p>
  );
}
