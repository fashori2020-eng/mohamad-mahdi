"use client";

import { Printer } from "lucide-react";

export function PrintButton({ label = "چاپ / ذخیره PDF" }: { label?: string }) {
  return (
    <button type="button" className="btn btn-primary no-print" onClick={() => window.print()}>
      <Printer className="h-4 w-4" />
      {label}
    </button>
  );
}
