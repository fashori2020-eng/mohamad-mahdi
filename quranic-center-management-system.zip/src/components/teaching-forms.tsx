"use client";

import { useState } from "react";
import { Check, Loader2, Mic, Save, Upload } from "lucide-react";
import type { AttendanceStatus, HifzStatus } from "@/db/schema";
import { createExam, reviewRecording, saveAttendance, setHifzPage, uploadRecording } from "@/lib/actions";
import { EXAM_TYPES, hifzStatusMeta } from "@/lib/labels";
import { faDateLong, faDigits } from "@/lib/jalali";
import { Feedback, InfoBox, useAction } from "@/components/feedback";
import { Card } from "@/components/ui";

/* ------------------------- حضور و غیاب یک‌کلیکی ------------------------- */

export function AttendanceQuick({
  sessionId,
  className,
  sessionDate,
  startTime,
  students,
  initial,
}: {
  sessionId: number;
  className: string;
  sessionDate: string;
  startTime: string;
  students: { studentId: number; fullName: string }[];
  initial: Record<string, AttendanceStatus>;
}) {
  const [statuses, setStatuses] = useState<Record<string, AttendanceStatus>>(initial);
  const { pending, msg, run } = useAction();

  function mark(studentId: number, status: AttendanceStatus) {
    const key = String(studentId);
    const next = { ...statuses, [key]: status };
    setStatuses(next);
    run(() =>
      saveAttendance(
        sessionId,
        Object.entries(next).map(([id, value]) => ({
          studentId: Number(id),
          status: value,
        })),
      ),
    );
  }

  const options: { value: AttendanceStatus; label: string; className: string }[] = [
    { value: "present", label: "حاضر", className: "bg-emerald-600 text-white" },
    { value: "absent", label: "غایب", className: "bg-rose-600 text-white" },
    { value: "late", label: "تأخیر", className: "bg-amber-500 text-white" },
    { value: "excused", label: "موجه", className: "bg-sky-600 text-white" },
  ];

  return (
    <Card
      title={`${className} — ${faDigits(startTime)}`}
      subtitle={faDateLong(sessionDate)}
      className="mb-4"
    >
      {students.length === 0 ? (
        <p className="text-sm text-slate-500">قرآن‌آموزی در این کلاس ثبت‌نام نکرده است.</p>
      ) : (
        <ul className="space-y-2">
          {students.map((student) => {
            const current = statuses[String(student.studentId)];
            return (
              <li
                key={student.studentId}
                className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 px-3 py-2"
              >
                <span className="text-sm font-bold text-emerald-900">{student.fullName}</span>
                <div className="flex flex-wrap gap-1.5">
                  {options.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      disabled={pending}
                      onClick={() => mark(student.studentId, option.value)}
                      className={`rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${
                        current === option.value
                          ? `${option.className} shadow`
                          : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      }`}
                      aria-pressed={current === option.value}
                    >
                      {current === option.value ? <Check className="inline h-3 w-3" /> : null}{" "}
                      {option.label}
                    </button>
                  ))}
                </div>
              </li>
            );
          })}
        </ul>
      )}
      <div className="mt-3">
        <Feedback msg={msg} />
      </div>
    </Card>
  );
}

/* ------------------------------ آزمون‌ها ------------------------------- */

export function ExamForm({
  students,
  classes,
}: {
  students: { id: number; fullName: string }[];
  classes: { id: number; name: string }[];
}) {
  const { pending, msg, run } = useAction();
  const [studentId, setStudentId] = useState(String(students[0]?.id ?? ""));
  const [classId, setClassId] = useState(String(classes[0]?.id ?? ""));
  const [examType, setExamType] = useState("new_page");
  const [title, setTitle] = useState("");
  const [examDate, setExamDate] = useState(new Date().toISOString().slice(0, 10));
  const [score, setScore] = useState("18");
  const [maxScore, setMaxScore] = useState("20");
  const [feedback, setFeedback] = useState("");

  return (
    <Card title="ثبت نتیجه آزمون" subtitle="صفحه جدید، تثبیت، کل جزء یا آزمون شفاهی">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(() =>
            createExam({
              studentId: Number(studentId),
              classId: classId ? Number(classId) : null,
              examType: examType as never,
              title: title || EXAM_TYPES.find((t) => t.value === examType)?.label || "آزمون",
              examDate,
              score: Number(score),
              maxScore: Number(maxScore),
              feedback,
            }),
          );
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label">قرآن‌آموز</label>
            <select
              className="select"
              value={studentId}
              onChange={(event) => setStudentId(event.target.value)}
            >
              {students.map((student) => (
                <option key={student.id} value={student.id}>
                  {student.fullName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">کلاس</label>
            <select className="select" value={classId} onChange={(event) => setClassId(event.target.value)}>
              {classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">نوع آزمون</label>
            <select className="select" value={examType} onChange={(event) => setExamType(event.target.value)}>
              {EXAM_TYPES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">تاریخ آزمون</label>
            <input
              type="date"
              dir="ltr"
              className="input"
              value={examDate}
              onChange={(event) => setExamDate(event.target.value)}
            />
          </div>
          <div>
            <label className="label">عنوان</label>
            <input
              className="input"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="مثال: صفحه جدید — جزء ۳۰ صفحه ۱۲"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">نمره</label>
              <input
                type="number"
                min={0}
                className="input"
                value={score}
                onChange={(event) => setScore(event.target.value)}
              />
            </div>
            <div>
              <label className="label">از</label>
              <input
                type="number"
                min={1}
                className="input"
                value={maxScore}
                onChange={(event) => setMaxScore(event.target.value)}
              />
            </div>
          </div>
        </div>
        <div>
          <label className="label">بازخورد استاد (شفاهی)</label>
          <textarea
            className="textarea"
            rows={3}
            value={feedback}
            onChange={(event) => setFeedback(event.target.value)}
            placeholder="نکات لحن، تجوید و روانی تلاوت..."
          />
        </div>
        <Feedback msg={msg} />
        <button type="submit" className="btn btn-primary" disabled={pending || students.length === 0}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          ثبت نمره و بازخورد
        </button>
      </form>
    </Card>
  );
}

/* ----------------------------- مسیر حفظ -------------------------------- */

const HIFZ_CYCLE: HifzStatus[] = ["none", "in_progress", "memorized", "stable"];

export function HifzGrid({
  studentId,
  studentName,
  rows,
  editable = true,
}: {
  studentId: number;
  studentName: string;
  rows: { juz: number; page: number; status: HifzStatus }[];
  editable?: boolean;
}) {
  const [local, setLocal] = useState<Record<string, HifzStatus>>(() => {
    const map: Record<string, HifzStatus> = {};
    rows.forEach((row) => {
      map[`${row.juz}-${row.page}`] = row.status;
    });
    return map;
  });
  const { pending, msg, run } = useAction();

  function cycle(juz: number, page: number, current: HifzStatus) {
    if (!editable) return;
    const next = HIFZ_CYCLE[(HIFZ_CYCLE.indexOf(current) + 1) % HIFZ_CYCLE.length];
    setLocal((prev) => ({ ...prev, [`${juz}-${page}`]: next }));
    run(() => setHifzPage({ studentId, juz, page, status: next }));
  }

  const total = Object.values(local).filter(
    (status) => status === "memorized" || status === "stable",
  ).length;

  return (
    <Card
      title={`مسیر حفظ — ${studentName}`}
      subtitle="با هر کلیک وضعیت صفحه تغییر می‌کند: شروع نشده ← در حال حفظ ← حفظ شده ← تثبیت‌شده"
    >
      <p className="mb-4 text-sm font-bold text-emerald-800">
        مجموع صفحات حفظ‌شده: {faDigits(total)} از {faDigits(604)} (
        {faDigits(Math.round((total / 604) * 100))}٪)
      </p>
      <div className="space-y-3">
        {Array.from({ length: 30 }, (_, index) => 30 - index).map((juz) => (
          <div key={juz} className="rounded-xl border border-slate-200 p-3">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-sm font-extrabold text-emerald-900">جزء {faDigits(juz)}</p>
              <p className="text-xs text-slate-500">
                {faDigits(
                  Array.from({ length: 20 }, (_, p) => local[`${juz}-${p + 1}`]).filter(
                    (status) => status === "memorized" || status === "stable",
                  ).length,
                )}
                /۲۰
              </p>
            </div>
            <div className="grid grid-cols-10 gap-1 sm:grid-cols-20">
              {Array.from({ length: 20 }, (_, pageIndex) => pageIndex + 1).map((page) => {
                const status = local[`${juz}-${page}`] ?? "none";
                const meta = hifzStatusMeta[status];
                return (
                  <button
                    key={page}
                    type="button"
                    disabled={!editable || pending}
                    onClick={() => cycle(juz, page, status)}
                    title={`صفحه ${page} — ${meta.label}`}
                    className={`h-7 rounded-md text-[10px] font-bold ring-1 ring-inset transition ${meta.className} ${
                      editable ? "cursor-pointer hover:scale-105" : "cursor-default"
                    }`}
                  >
                    {faDigits(page)}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 space-y-2">
        <Feedback msg={msg} />
        {editable && (
          <InfoBox text="راهنما: هر خانه نمایانگر یک صفحه از جزء است. رنگ سبز تیره یعنی تثبیت‌شده، سبز روشن حفظ‌شده، کهربایی در حال حفظ و خاکستری شروع نشده." />
        )}
      </div>
    </Card>
  );
}

/* --------------------------- صوت تلاوت --------------------------------- */

export function RecordingUploader() {
  const { pending, msg, run } = useAction();
  const [title, setTitle] = useState("");
  const [surahName, setSurahName] = useState("");
  const [ayahRange, setAyahRange] = useState("");
  const [fileName, setFileName] = useState("");
  const [audioBase64, setAudioBase64] = useState("");

  function handleFile(file: File | null) {
    if (!file) return;
    if (file.size > 4 * 1024 * 1024) {
      setFileName("حجم فایل بیش از ۴ مگابایت است");
      setAudioBase64("");
      return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      setAudioBase64(result.split(",")[1] ?? "");
    };
    reader.readAsDataURL(file);
  }

  return (
    <Card title="آپلود صوت تلاوت" subtitle="صوت خود را برای تصحیح استاد ارسال کنید (حداکثر ۴ مگابایت)">
      <form
        className="space-y-4"
        onSubmit={(event) => {
          event.preventDefault();
          run(
            () =>
              uploadRecording({
                title: title || `تلاوت ${surahName}`,
                surahName,
                ayahRange,
                mimeType: "audio/mpeg",
                audioBase64,
              }),
            true,
          );
          setTitle("");
          setSurahName("");
          setAyahRange("");
          setFileName("");
          setAudioBase64("");
        }}
      >
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label">عنوان</label>
            <input
              className="input"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="تلاوت سوره فجر"
            />
          </div>
          <div>
            <label className="label">نام سوره</label>
            <input
              className="input"
              value={surahName}
              onChange={(event) => setSurahName(event.target.value)}
              placeholder="فجر"
            />
          </div>
          <div>
            <label className="label">بازه آیات</label>
            <input
              className="input"
              value={ayahRange}
              onChange={(event) => setAyahRange(event.target.value)}
              placeholder="۱ تا ۲۰"
            />
          </div>
        </div>
        <div>
          <label className="label">فایل صوتی</label>
          <input
            type="file"
            accept="audio/*"
            className="input"
            onChange={(event) => handleFile(event.target.files?.[0] ?? null)}
          />
          {fileName && <p className="mt-1 text-xs font-bold text-emerald-700">{fileName}</p>}
        </div>
        <Feedback msg={msg} />
        <button
          type="submit"
          className="btn btn-gold"
          disabled={pending || audioBase64.length === 0}
        >
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          ارسال برای تصحیح
        </button>
      </form>
    </Card>
  );
}

export function RecordingReview({
  recordingId,
  initialScore = 18,
  initialFeedback = "",
}: {
  recordingId: number;
  initialScore?: number;
  initialFeedback?: string;
}) {
  const { pending, msg, run } = useAction();
  const [score, setScore] = useState(String(initialScore));
  const [feedback, setFeedback] = useState(initialFeedback);

  return (
    <form
      className="mt-3 space-y-3 rounded-xl bg-slate-50 p-3"
      onSubmit={(event) => {
        event.preventDefault();
        run(() => reviewRecording({ recordingId, score: Number(score), feedback }));
      }}
    >
      <div className="flex items-end gap-3">
        <div className="w-28">
          <label className="label">نمره</label>
          <input
            type="number"
            min={0}
            max={20}
            className="input"
            value={score}
            onChange={(event) => setScore(event.target.value)}
          />
        </div>
        <div className="flex-1">
          <label className="label">بازخورد استاد</label>
          <input
            className="input"
            value={feedback}
            onChange={(event) => setFeedback(event.target.value)}
            placeholder="نکات تجویدی و لحن..."
          />
        </div>
        <button type="submit" className="btn btn-primary btn-sm" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Mic className="h-4 w-4" />}
          ثبت تصحیح
        </button>
      </div>
      <Feedback msg={msg} />
    </form>
  );
}
