import type { ReactNode } from "react";
import Link from "next/link";

export function Card({
  title,
  subtitle,
  action,
  children,
  className = "",
  padded = true,
}: {
  title?: ReactNode;
  subtitle?: ReactNode;
  action?: ReactNode;
  children?: ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return (
    <section className={`card ${className}`}>
      {(title || action) && (
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 px-4 py-3 sm:px-5">
          <div>
            {title && <h2 className="text-base font-extrabold text-emerald-900 sm:text-lg">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-xs text-slate-500 sm:text-sm">{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      <div className={padded ? "p-4 sm:p-5" : ""}>{children}</div>
    </section>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "emerald",
  href,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: ReactNode;
  tone?: "emerald" | "gold" | "rose" | "sky" | "slate";
  href?: string;
}) {
  const tones: Record<string, string> = {
    emerald: "from-emerald-500 to-emerald-700",
    gold: "from-amber-300 to-amber-500",
    rose: "from-rose-400 to-rose-600",
    sky: "from-sky-400 to-sky-600",
    slate: "from-slate-400 to-slate-600",
  };
  const body = (
    <div className="card card-hover flex items-center gap-3 p-4 transition sm:gap-4 sm:p-5">
      {icon && (
        <span
          className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gradient-to-br ${tones[tone]} text-white shadow-inner`}
        >
          {icon}
        </span>
      )}
      <div className="min-w-0">
        <p className="truncate text-xs font-bold text-slate-500 sm:text-sm">{label}</p>
        <p className="mt-1 text-xl font-extrabold text-emerald-900 sm:text-2xl">{value}</p>
        {hint && <p className="mt-0.5 truncate text-xs text-slate-500">{hint}</p>}
      </div>
    </div>
  );
  return href ? (
    <Link href={href} className="block">
      {body}
    </Link>
  ) : (
    body
  );
}

export function Badge({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <span className={`badge ${className}`}>{children}</span>;
}

export function ProgressBar({
  value,
  max = 100,
  tone = "emerald",
  showPercent = true,
}: {
  value: number;
  max?: number;
  tone?: "emerald" | "gold";
  showPercent?: boolean;
}) {
  const percent = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
  return (
    <div className="flex items-center gap-2">
      <div
        className="h-3 w-full overflow-hidden rounded-full bg-slate-200"
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className={`h-full rounded-full ${
            tone === "gold"
              ? "bg-gradient-to-l from-amber-300 to-amber-500"
              : "bg-gradient-to-l from-emerald-400 to-emerald-700"
          }`}
          style={{ width: `${percent}%` }}
        />
      </div>
      {showPercent && <span className="shrink-0 text-xs font-bold text-slate-600">{percent}٪</span>}
    </div>
  );
}

export function EmptyState({ text, icon }: { text: string; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-slate-300 bg-slate-50/60 p-8 text-center">
      {icon && <span className="text-emerald-600">{icon}</span>}
      <p className="text-sm font-bold text-slate-500">{text}</p>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-extrabold text-emerald-900 sm:text-2xl">{title}</h1>
        {description && <p className="mt-1 text-sm text-slate-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

export function KeyValue({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-xl bg-slate-50 px-3 py-2">
      <p className="text-xs font-bold text-slate-500">{label}</p>
      <p className="mt-0.5 text-sm font-bold text-emerald-900">{value}</p>
    </div>
  );
}
