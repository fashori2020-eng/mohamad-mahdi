import {
  boolean,
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* انواع مشترک                                                        */
/* ------------------------------------------------------------------ */

export type Role = "manager" | "teacher" | "student" | "parent";
export type StudentLevel = "rokhani" | "tajvid" | "hifz" | "qeraat" | "mafhim";
export type RegistrationStatus = "pending" | "active" | "rejected";
export type ClassMode = "inperson" | "online";
export type AttendanceStatus = "present" | "absent" | "late" | "excused";
export type HifzStatus = "none" | "in_progress" | "memorized" | "stable";
export type ExamType = "new_page" | "tashbit" | "full_juz" | "oral";
export type PaymentKind = "tuition" | "donation" | "other";
export type PaymentStatus = "unpaid" | "paid" | "overdue";
export type RecordingStatus = "pending" | "reviewed";
export type EventType = "exam" | "occasion" | "trip" | "meeting";

/* ------------------------------------------------------------------ */
/* کاربران و احراز هویت                                               */
/* ------------------------------------------------------------------ */

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  mobile: text("mobile").notNull().unique(),
  role: text("role").$type<Role>().notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const otpCodes = pgTable("otp_codes", {
  id: serial("id").primaryKey(),
  mobile: text("mobile").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  consumed: boolean("consumed").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* اساتید و قرآن‌آموزان                                                */
/* ------------------------------------------------------------------ */

export const teachers = pgTable("teachers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  specialties: text("specialties").notNull().default(""),
  bio: text("bio").notNull().default(""),
  education: text("education").notNull().default(""),
  joinDate: date("join_date").notNull(),
  status: text("status").$type<RegistrationStatus>().notNull().default("active"),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  parentUserId: integer("parent_user_id"),
  level: text("level").$type<StudentLevel>().notNull().default("rokhani"),
  birthDate: date("birth_date"),
  nationalCode: text("national_code").notNull().default(""),
  address: text("address").notNull().default(""),
  guardianName: text("guardian_name").notNull().default(""),
  joinDate: date("join_date").notNull(),
  history: text("history").notNull().default(""),
  status: text("status").$type<RegistrationStatus>().notNull().default("pending"),
});

/* ------------------------------------------------------------------ */
/* کلاس‌ها، ثبت‌نام، جلسات                                            */
/* ------------------------------------------------------------------ */

export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  courseType: text("course_type").$type<StudentLevel>().notNull(),
  teacherId: integer("teacher_id"),
  days: text("days").notNull().default(""),
  startTime: text("start_time").notNull().default("16:00"),
  durationMinutes: integer("duration_minutes").notNull().default(90),
  location: text("location").notNull().default(""),
  mode: text("mode").$type<ClassMode>().notNull().default("inperson"),
  capacity: integer("capacity").notNull().default(15),
  tuition: integer("tuition").notNull().default(0),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  description: text("description").notNull().default(""),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull(),
  studentId: integer("student_id").notNull(),
  enrolledAt: date("enrolled_at").notNull(),
  status: text("status").notNull().default("active"),
});

export const classSessions = pgTable("class_sessions", {
  id: serial("id").primaryKey(),
  classId: integer("class_id").notNull(),
  sessionDate: date("session_date").notNull(),
  startTime: text("start_time").notNull(),
  topic: text("topic").notNull().default(""),
  status: text("status").notNull().default("scheduled"),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  sessionId: integer("session_id").notNull(),
  studentId: integer("student_id").notNull(),
  status: text("status").$type<AttendanceStatus>().notNull().default("present"),
  note: text("note").notNull().default(""),
  recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* مسیر حفظ، آزمون‌ها                                                 */
/* ------------------------------------------------------------------ */

export const hifzProgress = pgTable("hifz_progress", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  juz: integer("juz").notNull(),
  page: integer("page").notNull(),
  status: text("status").$type<HifzStatus>().notNull().default("none"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  classId: integer("class_id"),
  teacherId: integer("teacher_id"),
  examType: text("exam_type").$type<ExamType>().notNull(),
  title: text("title").notNull(),
  examDate: date("exam_date").notNull(),
  score: integer("score").notNull().default(0),
  maxScore: integer("max_score").notNull().default(20),
  feedback: text("feedback").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* امور مالی، اعلان‌ها، صوت، گواهی، تقویم                            */
/* ------------------------------------------------------------------ */

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id"),
  parentUserId: integer("parent_user_id"),
  title: text("title").notNull(),
  amount: integer("amount").notNull(),
  kind: text("kind").$type<PaymentKind>().notNull().default("tuition"),
  dueDate: date("due_date").notNull(),
  status: text("status").$type<PaymentStatus>().notNull().default("unpaid"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  method: text("method").notNull().default(""),
  trackingCode: text("tracking_code").notNull().default(""),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  senderId: integer("sender_id"),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  kind: text("kind").notNull().default("general"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const recordings = pgTable("recordings", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  classId: integer("class_id"),
  teacherId: integer("teacher_id"),
  title: text("title").notNull(),
  surahName: text("surah_name").notNull().default(""),
  ayahRange: text("ayah_range").notNull().default(""),
  mimeType: text("mime_type").notNull().default("audio/webm"),
  audioData: text("audio_data"),
  status: text("status").$type<RecordingStatus>().notNull().default("pending"),
  score: integer("score"),
  feedback: text("feedback").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
});

export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  classId: integer("class_id"),
  courseName: text("course_name").notNull(),
  level: text("level").notNull().default(""),
  grade: text("grade").notNull().default(""),
  teacherName: text("teacher_name").notNull().default(""),
  serial: text("serial").notNull(),
  hours: integer("hours").notNull().default(40),
  issuedAt: date("issued_at").notNull(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  eventType: text("event_type").$type<EventType>().notNull().default("occasion"),
  eventDate: date("event_date").notNull(),
  description: text("description").notNull().default(""),
  classId: integer("class_id"),
});

export type User = typeof users.$inferSelect;
export type Student = typeof students.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type ClassRow = typeof classes.$inferSelect;
export type ClassSession = typeof classSessions.$inferSelect;
export type AttendanceRow = typeof attendance.$inferSelect;
export type ExamRow = typeof exams.$inferSelect;
export type PaymentRow = typeof payments.$inferSelect;
export type NotificationRow = typeof notifications.$inferSelect;
export type RecordingRow = typeof recordings.$inferSelect;
export type CertificateRow = typeof certificates.$inferSelect;
export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type Enrollment = typeof enrollments.$inferSelect;
export type HifzRow = typeof hifzProgress.$inferSelect;
