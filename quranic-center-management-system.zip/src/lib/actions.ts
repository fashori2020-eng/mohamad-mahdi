"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  attendance,
  calendarEvents,
  certificates,
  classSessions,
  classes,
  enrollments,
  exams,
  hifzProgress,
  notifications,
  otpCodes,
  payments,
  recordings,
  students,
  teachers,
  users,
  type AttendanceStatus,
  type ClassMode,
  type EventType,
  type ExamType,
  type HifzStatus,
  type PaymentKind,
  type Role,
  type StudentLevel,
} from "@/db/schema";
import { addDays, faWeekdayIndex, isoDate, todayISO } from "@/lib/jalali";
import { createSession, destroySession, getCurrentUser, requireUser } from "@/lib/session";

export type ActionResult = { ok: boolean; message: string; extra?: Record<string, string> };

const OK = (message: string): ActionResult => ({ ok: true, message });
const FAIL = (message: string): ActionResult => ({ ok: false, message });

function refresh() {
  revalidatePath("/", "layout");
}

function normalizeMobile(input: string): string {
  const digits = input
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[^\d]/g, "");
  if (digits.length === 10 && digits.startsWith("9")) return `0${digits}`;
  return digits;
}

async function notifyManagers(title: string, body: string, senderId: number | null, kind: string) {
  const managers = await db.select({ id: users.id }).from(users).where(eq(users.role, "manager"));
  if (managers.length === 0) return;
  await db
    .insert(notifications)
    .values(managers.map((m) => ({ userId: m.id, senderId, title, body, kind })));
}

/* ------------------------------------------------------------------ */
/* احراز هویت                                                         */
/* ------------------------------------------------------------------ */

export async function requestOtp(rawMobile: string): Promise<ActionResult> {
  const mobile = normalizeMobile(rawMobile);
  if (!/^09\d{9}$/.test(mobile)) {
    return FAIL("شماره موبایل معتبر نیست. نمونه: ۰۹۱۲۱۱۱۰۰۰۰");
  }
  const found = await db.select().from(users).where(eq(users.mobile, mobile)).limit(1);
  if (found.length === 0) {
    return FAIL("این شماره در سامانه ثبت نشده است. ابتدا ثبت‌نام کنید.");
  }
  if (!found[0].isActive) {
    return FAIL("حساب کاربری شما غیرفعال است. با مدیریت مجموعه تماس بگیرید.");
  }

  const code = String(Math.floor(10000 + Math.random() * 89999));
  await db.delete(otpCodes).where(and(eq(otpCodes.mobile, mobile), eq(otpCodes.consumed, false)));
  await db.insert(otpCodes).values({
    mobile,
    code,
    expiresAt: new Date(Date.now() + 5 * 60 * 1000),
  });

  return { ...OK(`رمز یکبارمصرف برای ${mobile} ارسال شد.`), extra: { code } };
}

export async function verifyOtp(rawMobile: string, rawCode: string): Promise<ActionResult> {
  const mobile = normalizeMobile(rawMobile);
  const code = rawCode.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).trim();
  const rows = await db
    .select()
    .from(otpCodes)
    .where(and(eq(otpCodes.mobile, mobile), eq(otpCodes.code, code), eq(otpCodes.consumed, false)))
    .limit(1);

  if (rows.length === 0) return FAIL("کد وارد شده صحیح نیست.");
  if (rows[0].expiresAt.getTime() < Date.now()) return FAIL("کد منقضی شده است. دوباره درخواست کنید.");

  await db.update(otpCodes).set({ consumed: true }).where(eq(otpCodes.id, rows[0].id));
  const found = await db.select().from(users).where(eq(users.mobile, mobile)).limit(1);
  if (found.length === 0) return FAIL("کاربر یافت نشد.");
  await createSession(found[0].id);
  refresh();
  return { ...OK("خوش آمدید ✓"), extra: { role: found[0].role } };
}

export async function logout() {
  await destroySession();
  refresh();
  redirect("/login");
}

/* ------------------------------------------------------------------ */
/* ثبت‌نام آنلاین                                                     */
/* ------------------------------------------------------------------ */

export type RegisterPayload = {
  role: "student" | "teacher" | "parent";
  fullName: string;
  mobile: string;
  nationalCode?: string;
  birthDate?: string;
  level?: StudentLevel;
  guardianName?: string;
  address?: string;
  specialties?: string[];
  education?: string;
  childNationalCode?: string;
};

export async function registerUser(payload: RegisterPayload): Promise<ActionResult> {
  const fullName = payload.fullName.trim();
  const mobile = normalizeMobile(payload.mobile);
  if (fullName.length < 3) return FAIL("نام و نام خانوادگی را کامل وارد کنید.");
  if (!/^09\d{9}$/.test(mobile)) return FAIL("شماره موبایل معتبر نیست.");
  if (payload.role === "teacher" && (payload.specialties ?? []).length === 0) {
    return FAIL("حداقل یک تخصص را انتخاب کنید.");
  }

  const existing = await db.select().from(users).where(eq(users.mobile, mobile)).limit(1);
  if (existing.length > 0) return FAIL("این شماره قبلاً ثبت شده است. وارد شوید.");

  const [user] = await db
    .insert(users)
    .values({ fullName, mobile, role: payload.role as Role })
    .returning({ id: users.id });

  if (payload.role === "student") {
    await db.insert(students).values({
      userId: user.id,
      level: payload.level ?? "rokhani",
      birthDate: payload.birthDate || null,
      nationalCode: payload.nationalCode ?? "",
      address: payload.address ?? "",
      guardianName: payload.guardianName ?? "",
      joinDate: todayISO(),
      status: "pending",
    });
    await notifyManagers(
      `ثبت‌نام جدید قرآن‌آموز: ${fullName}`,
      `قرآن‌آموز جدید در سطح ${payload.level ?? "روخوانی"} ثبت‌نام کرد و در انتظار تأیید است.`,
      user.id,
      "registration",
    );
  } else if (payload.role === "teacher") {
    await db.insert(teachers).values({
      userId: user.id,
      specialties: (payload.specialties ?? []).join(","),
      education: payload.education ?? "",
      joinDate: todayISO(),
      status: "pending",
    });
    await notifyManagers(
      `ثبت‌نام جدید استاد: ${fullName}`,
      `استاد جدید با تخصص‌های ${(payload.specialties ?? []).join("، ")} ثبت‌نام کرد.`,
      user.id,
      "registration",
    );
  } else {
    let linked = "";
    if (payload.childNationalCode) {
      const child = await db
        .select({ id: students.id })
        .from(students)
        .where(eq(students.nationalCode, payload.childNationalCode))
        .limit(1);
      if (child.length > 0) {
        await db
          .update(students)
          .set({ parentUserId: user.id })
          .where(eq(students.id, child[0].id));
        linked = " و به پرونده فرزند شما متصل شد";
      }
    }
    await notifyManagers(
      `ثبت‌نام جدید ولی: ${fullName}`,
      `ولی جدید در سامانه ثبت‌نام کرد${linked}.`,
      user.id,
      "registration",
    );
  }

  await db.insert(notifications).values({
    userId: user.id,
    title: "ثبت‌نام شما در معارج ثبت شد ✓",
    body: "پرونده شما برای بررسی و تأیید نهایی به مدیریت مجموعه ارسال شد. نتیجه از طریق همین سامانه اطلاع‌رسانی می‌شود.",
    kind: "registration",
  });

  refresh();
  return OK("ثبت‌نام انجام شد ✓ منتظر تأیید مدیریت باشید.");
}

/* ------------------------------------------------------------------ */
/* مدیریت قرآن‌آموزان و اساتید                                        */
/* ------------------------------------------------------------------ */

export async function setStudentStatus(studentId: number, status: "active" | "rejected" | "pending") {
  await requireUser().then(() => {});
  await db.update(students).set({ status }).where(eq(students.id, studentId));
  refresh();
  return OK("وضعیت پرونده به‌روزرسانی شد ✓");
}

export async function updateStudent(payload: {
  studentId: number;
  fullName: string;
  level: StudentLevel;
  nationalCode: string;
  guardianName: string;
  address: string;
  history: string;
  parentUserId?: number | null;
}) {
  await db
    .update(students)
    .set({
      level: payload.level,
      nationalCode: payload.nationalCode,
      guardianName: payload.guardianName,
      address: payload.address,
      history: payload.history,
      parentUserId: payload.parentUserId ?? null,
    })
    .where(eq(students.id, payload.studentId));
  if (payload.fullName.trim()) {
    const row = await db
      .select({ userId: students.userId })
      .from(students)
      .where(eq(students.id, payload.studentId))
      .limit(1);
    if (row[0]) {
      await db.update(users).set({ fullName: payload.fullName }).where(eq(users.id, row[0].userId));
    }
  }
  refresh();
  return OK("پرونده قرآن‌آموز ذخیره شد ✓");
}

export async function createStudent(payload: {
  fullName: string;
  mobile: string;
  level: StudentLevel;
  guardianName: string;
  nationalCode: string;
  parentUserId?: number | null;
}) {
  const me = await getCurrentUser();
  const mobile = normalizeMobile(payload.mobile);
  const exists = await db.select().from(users).where(eq(users.mobile, mobile)).limit(1);
  if (exists.length > 0) return FAIL("این شماره موبایل قبلاً ثبت شده است.");

  const [user] = await db
    .insert(users)
    .values({ fullName: payload.fullName, mobile, role: "student" })
    .returning({ id: users.id });
  await db.insert(students).values({
    userId: user.id,
    level: payload.level,
    nationalCode: payload.nationalCode,
    guardianName: payload.guardianName,
    parentUserId: payload.parentUserId ?? null,
    joinDate: todayISO(),
    status: "active",
  });
  await db.insert(notifications).values({
    userId: user.id,
    senderId: me?.id ?? null,
    title: "به مجموعه معارج خوش آمدید",
    body: "پرونده شما توسط مدیریت مجموعه ایجاد شد.",
    kind: "registration",
  });
  refresh();
  return OK("قرآن‌آموز جدید ثبت شد ✓");
}

export async function createTeacher(payload: {
  fullName: string;
  mobile: string;
  specialties: string[];
  education: string;
}) {
  const mobile = normalizeMobile(payload.mobile);
  const exists = await db.select().from(users).where(eq(users.mobile, mobile)).limit(1);
  if (exists.length > 0) return FAIL("این شماره موبایل قبلاً ثبت شده است.");
  if (payload.specialties.length === 0) return FAIL("حداقل یک تخصص انتخاب کنید.");

  const [user] = await db
    .insert(users)
    .values({ fullName: payload.fullName, mobile, role: "teacher" })
    .returning({ id: users.id });
  await db.insert(teachers).values({
    userId: user.id,
    specialties: payload.specialties.join(","),
    education: payload.education,
    joinDate: todayISO(),
    status: "active",
  });
  refresh();
  return OK("استاد جدید ثبت شد ✓");
}

export async function setTeacherStatus(teacherId: number, status: "active" | "rejected" | "pending") {
  await db.update(teachers).set({ status }).where(eq(teachers.id, teacherId));
  refresh();
  return OK("وضعیت استاد به‌روزرسانی شد ✓");
}

/* ------------------------------------------------------------------ */
/* کلاس‌ها و جلسات                                                    */
/* ------------------------------------------------------------------ */

export async function createClass(payload: {
  name: string;
  courseType: StudentLevel;
  teacherId: number | null;
  days: number[];
  startTime: string;
  durationMinutes: number;
  location: string;
  mode: ClassMode;
  capacity: number;
  tuition: number;
  startDate: string;
  description: string;
}) {
  if (!payload.name.trim()) return FAIL("نام کلاس را وارد کنید.");
  if (payload.days.length === 0) return FAIL("روزهای برگزاری را انتخاب کنید.");
  await db.insert(classes).values({
    name: payload.name,
    courseType: payload.courseType,
    teacherId: payload.teacherId,
    days: payload.days.join(","),
    startTime: payload.startTime,
    durationMinutes: payload.durationMinutes,
    location: payload.location,
    mode: payload.mode,
    capacity: payload.capacity,
    tuition: payload.tuition,
    startDate: payload.startDate || todayISO(),
    description: payload.description,
    status: "active",
  });
  refresh();
  return OK("کلاس جدید ایجاد شد ✓");
}

export async function updateClassTeacher(classId: number, teacherId: number | null) {
  await db.update(classes).set({ teacherId }).where(eq(classes.id, classId));
  refresh();
  return OK("استاد کلاس تعیین شد ✓");
}

export async function enrollStudent(classId: number, studentId: number) {
  const exists = await db
    .select()
    .from(enrollments)
    .where(and(eq(enrollments.classId, classId), eq(enrollments.studentId, studentId)))
    .limit(1);
  if (exists.length > 0) return FAIL("این قرآن‌آموز قبلاً در کلاس ثبت‌نام شده است.");
  await db.insert(enrollments).values({ classId, studentId, enrolledAt: todayISO() });
  refresh();
  return OK("قرآن‌آموز به کلاس اضافه شد ✓");
}

export async function removeEnrollment(enrollmentId: number) {
  await db.delete(enrollments).where(eq(enrollments.id, enrollmentId));
  refresh();
  return OK("ثبت‌نام حذف شد ✓");
}

export async function generateSessions(classId: number, weeks = 4) {
  const rows = await db.select().from(classes).where(eq(classes.id, classId)).limit(1);
  if (rows.length === 0) return FAIL("کلاس یافت نشد.");
  const cls = rows[0];
  const dayList = cls.days.split(",").map(Number);
  let created = 0;
  for (let i = 0; i < weeks * 7; i += 1) {
    const date = addDays(new Date(), i);
    if (!dayList.includes(faWeekdayIndex(date))) continue;
    const iso = isoDate(date);
    const duplicate = await db
      .select({ id: classSessions.id })
      .from(classSessions)
      .where(and(eq(classSessions.classId, classId), eq(classSessions.sessionDate, iso)))
      .limit(1);
    if (duplicate.length > 0) continue;
    await db.insert(classSessions).values({
      classId,
      sessionDate: iso,
      startTime: cls.startTime,
      topic: "جلسه کلاس",
    });
    created += 1;
  }
  refresh();
  return OK(created > 0 ? `${created} جلسه جدید در تقویم ثبت شد ✓` : "جلسه جدیدی برای افزودن نبود.");
}

/* ------------------------------------------------------------------ */
/* حضور و غیاب                                                       */
/* ------------------------------------------------------------------ */

export async function saveAttendance(
  sessionId: number,
  entries: { studentId: number; status: AttendanceStatus }[],
) {
  if (entries.length === 0) return FAIL("موردی برای ثبت وجود ندارد.");
  await db.delete(attendance).where(eq(attendance.sessionId, sessionId));
  await db.insert(attendance).values(
    entries.map((entry) => ({
      sessionId,
      studentId: entry.studentId,
      status: entry.status,
      recordedAt: new Date(),
    })),
  );

  /* اطلاع‌رسانی غیبت به ولی */
  const session = await db
    .select({ className: classes.name, sessionDate: classSessions.sessionDate })
    .from(classSessions)
    .innerJoin(classes, eq(classes.id, classSessions.classId))
    .where(eq(classSessions.id, sessionId))
    .limit(1);

  const absentIds = entries.filter((e) => e.status === "absent").map((e) => e.studentId);
  if (absentIds.length > 0 && session[0]) {
    const absentStudents = await db
      .select({
        studentId: students.id,
        parentUserId: students.parentUserId,
        userId: students.userId,
        fullName: users.fullName,
      })
      .from(students)
      .innerJoin(users, eq(users.id, students.userId))
      .where(inArray(students.id, absentIds));

    const rows = absentStudents
      .map((s) => {
        const targets = [s.userId, s.parentUserId].filter((v): v is number => typeof v === "number");
        return targets.map((userId) => ({
          userId,
          title: "غیبت در جلسه کلاس",
          body: `${s.fullName} در جلسه کلاس «${session[0].className}» حضور نداشت.`,
          kind: "absence",
        }));
      })
      .flat();
    if (rows.length > 0) await db.insert(notifications).values(rows);
  }

  refresh();
  return OK("حضور و غیاب ثبت شد ✓");
}

/* ------------------------------------------------------------------ */
/* آزمون‌ها و مسیر حفظ                                               */
/* ------------------------------------------------------------------ */

export async function createExam(payload: {
  studentId: number;
  classId: number | null;
  examType: ExamType;
  title: string;
  examDate: string;
  score: number;
  maxScore: number;
  feedback: string;
}) {
  const me = await getCurrentUser();
  await db.insert(exams).values({
    studentId: payload.studentId,
    classId: payload.classId,
    teacherId: me?.id ?? null,
    examType: payload.examType,
    title: payload.title || "آزمون",
    examDate: payload.examDate || todayISO(),
    score: payload.score,
    maxScore: payload.maxScore,
    feedback: payload.feedback,
  });

  const student = await db
    .select({ userId: students.userId, parentUserId: students.parentUserId })
    .from(students)
    .where(eq(students.id, payload.studentId))
    .limit(1);
  if (student[0]) {
    const targets = [student[0].userId, student[0].parentUserId].filter(
      (v): v is number => typeof v === "number",
    );
    if (targets.length > 0) {
      await db.insert(notifications).values(
        targets.map((userId) => ({
          userId,
          senderId: me?.id ?? null,
          title: "ثبت نمره آزمون",
          body: `نمره «${payload.title}» ثبت شد: ${payload.score} از ${payload.maxScore}`,
          kind: "exam",
        })),
      );
    }
  }
  refresh();
  return OK("نتیجه آزمون ثبت شد ✓");
}

export async function setHifzPage(payload: {
  studentId: number;
  juz: number;
  page: number;
  status: HifzStatus;
}) {
  const existing = await db
    .select({ id: hifzProgress.id })
    .from(hifzProgress)
    .where(
      and(
        eq(hifzProgress.studentId, payload.studentId),
        eq(hifzProgress.juz, payload.juz),
        eq(hifzProgress.page, payload.page),
      ),
    )
    .limit(1);
  if (existing[0]) {
    await db
      .update(hifzProgress)
      .set({ status: payload.status, updatedAt: new Date() })
      .where(eq(hifzProgress.id, existing[0].id));
  } else {
    await db.insert(hifzProgress).values(payload);
  }
  refresh();
  return OK("مسیر حفظ به‌روزرسانی شد ✓");
}

/* ------------------------------------------------------------------ */
/* امور مالی                                                          */
/* ------------------------------------------------------------------ */

export async function createPayment(payload: {
  studentId: number | null;
  title: string;
  amount: number;
  kind: PaymentKind;
  dueDate: string;
}) {
  if (payload.amount <= 0) return FAIL("مبلغ باید بزرگ‌تر از صفر باشد.");
  let parentUserId: number | null = null;
  if (payload.studentId) {
    const row = await db
      .select({ parentUserId: students.parentUserId })
      .from(students)
      .where(eq(students.id, payload.studentId))
      .limit(1);
    parentUserId = row[0]?.parentUserId ?? null;
  }
  await db.insert(payments).values({
    studentId: payload.studentId,
    parentUserId,
    title: payload.title,
    amount: payload.amount,
    kind: payload.kind,
    dueDate: payload.dueDate || todayISO(),
    status: "unpaid",
  });
  refresh();
  return OK("بدهی/شهریه ثبت شد ✓");
}

export async function markPaymentPaid(paymentId: number, method = "ثبت دستی مدیریت") {
  const tracking = `MRJ-${Math.floor(100000 + Math.random() * 899999)}`;
  await db
    .update(payments)
    .set({ status: "paid", paidAt: new Date(), method, trackingCode: tracking })
    .where(eq(payments.id, paymentId));
  refresh();
  return OK(`پرداخت با کد پیگیری ${tracking} ثبت شد ✓`);
}

export async function payOnline(paymentId: number) {
  await new Promise((resolve) => setTimeout(resolve, 400));
  return markPaymentPaid(paymentId, "درگاه پرداخت آنلاین");
}

export async function createDonation(payload: { amount: number; note: string }) {
  const me = await getCurrentUser();
  if (payload.amount <= 0) return FAIL("مبلغ کمک را وارد کنید.");
  await db.insert(payments).values({
    parentUserId: me?.role === "parent" ? me.id : null,
    title: payload.note || "کمک به هیئت امنا",
    amount: payload.amount,
    kind: "donation",
    dueDate: todayISO(),
    status: "unpaid",
  });
  refresh();
  return OK("درخواست کمک مالی ثبت شد ✓ از بخش پرداخت‌ها می‌توانید پرداخت کنید.");
}

/* ------------------------------------------------------------------ */
/* پیام‌رسانی                                                         */
/* ------------------------------------------------------------------ */

export async function sendNotification(payload: {
  target: "all" | "students" | "parents" | "teachers" | "user";
  userId?: number;
  title: string;
  body: string;
  kind: string;
}) {
  const me = await getCurrentUser();
  if (!payload.title.trim()) return FAIL("عنوان پیام را وارد کنید.");

  let targets: { id: number }[] = [];
  if (payload.target === "user" && payload.userId) {
    targets = [{ id: payload.userId }];
  } else if (payload.target !== "user") {
    const roles: Role[] =
      payload.target === "students"
        ? ["student"]
        : payload.target === "parents"
          ? ["parent"]
          : payload.target === "teachers"
            ? ["teacher"]
            : ["manager", "teacher", "student", "parent"];
    targets = await db.select({ id: users.id }).from(users).where(inArray(users.role, roles));
  }
  if (targets.length === 0) return FAIL("گیرنده‌ای انتخاب نشده است.");
  await db.insert(notifications).values(
    targets.map((t) => ({
      userId: t.id,
      senderId: me?.id ?? null,
      title: payload.title,
      body: payload.body,
      kind: payload.kind || "general",
    })),
  );
  refresh();
  return OK(`پیام برای ${targets.length} کاربر ارسال شد ✓`);
}

export async function markAllRead() {
  const me = await getCurrentUser();
  if (!me) return FAIL("ابتدا وارد شوید.");
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, me.id));
  refresh();
  return OK("همه پیام‌ها خوانده شد ✓");
}

/* ------------------------------------------------------------------ */
/* صوت تلاوت                                                          */
/* ------------------------------------------------------------------ */

export async function uploadRecording(payload: {
  title: string;
  surahName: string;
  ayahRange: string;
  mimeType: string;
  audioBase64: string;
}) {
  const me = await getCurrentUser();
  if (!me) return FAIL("ابتدا وارد شوید.");
  if (me.role !== "student") return FAIL("فقط قرآن‌آموز می‌تواند صوت بارگذاری کند.");
  if (payload.audioBase64.length > 6_000_000) return FAIL("حجم فایل صوتی بیش از حد مجاز است (حداکثر ۴ مگابایت).");

  const student = await db
    .select({ id: students.id })
    .from(students)
    .where(eq(students.userId, me.id))
    .limit(1);
  if (!student[0]) return FAIL("پرونده قرآن‌آموز یافت نشد.");

  const classRows = await db
    .select({ classId: enrollments.classId })
    .from(enrollments)
    .where(eq(enrollments.studentId, student[0].id))
    .limit(1);
  const classId = classRows[0]?.classId ?? null;

  let teacherId: number | null = null;
  if (classId) {
    const cls = await db
      .select({ teacherId: classes.teacherId })
      .from(classes)
      .where(eq(classes.id, classId))
      .limit(1);
    teacherId = cls[0]?.teacherId ?? null;
  }

  await db.insert(recordings).values({
    studentId: student[0].id,
    classId,
    teacherId,
    title: payload.title || "تلاوت جدید",
    surahName: payload.surahName,
    ayahRange: payload.ayahRange,
    mimeType: payload.mimeType || "audio/mpeg",
    audioData: payload.audioBase64,
    status: "pending",
  });
  refresh();
  return OK("صوت تلاوت بارگذاری شد ✓ در انتظار تصحیح استاد.");
}

export async function reviewRecording(payload: {
  recordingId: number;
  score: number;
  feedback: string;
}) {
  const rows = await db
    .select({ studentId: recordings.studentId })
    .from(recordings)
    .where(eq(recordings.id, payload.recordingId))
    .limit(1);
  await db
    .update(recordings)
    .set({ score: payload.score, feedback: payload.feedback, status: "reviewed", reviewedAt: new Date() })
    .where(eq(recordings.id, payload.recordingId));

  if (rows[0]) {
    const student = await db
      .select({ userId: students.userId })
      .from(students)
      .where(eq(students.id, rows[0].studentId))
      .limit(1);
    if (student[0]) {
      await db.insert(notifications).values({
        userId: student[0].userId,
        title: "تصحیح صوت تلاوت انجام شد",
        body: `نمره ${payload.score} ثبت شد. ${payload.feedback}`,
        kind: "recording",
      });
    }
  }
  refresh();
  return OK("بازخورد استاد ثبت شد ✓");
}

/* ------------------------------------------------------------------ */
/* گواهی و تقویم                                                      */
/* ------------------------------------------------------------------ */

export async function issueCertificate(payload: {
  studentId: number;
  classId: number | null;
  courseName: string;
  level: string;
  grade: string;
  teacherName: string;
  hours: number;
}) {
  const serial = `MRJ-CERT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 8999)}`;
  await db.insert(certificates).values({
    studentId: payload.studentId,
    classId: payload.classId,
    courseName: payload.courseName,
    level: payload.level,
    grade: payload.grade,
    teacherName: payload.teacherName,
    hours: payload.hours,
    serial,
    issuedAt: todayISO(),
  });
  const student = await db
    .select({ userId: students.userId })
    .from(students)
    .where(eq(students.id, payload.studentId))
    .limit(1);
  if (student[0]) {
    await db.insert(notifications).values({
      userId: student[0].userId,
      title: "گواهی پایان دوره صادر شد ✓",
      body: `گواهی «${payload.courseName}» با شماره سری ${serial} آماده دانلود است.`,
      kind: "certificate",
    });
  }
  refresh();
  return OK(`گواهی با شماره سری ${serial} صادر شد ✓`);
}

export async function createEvent(payload: {
  title: string;
  eventType: EventType;
  eventDate: string;
  description: string;
}) {
  if (!payload.title.trim()) return FAIL("عنوان رویداد را وارد کنید.");
  await db.insert(calendarEvents).values({
    title: payload.title,
    eventType: payload.eventType,
    eventDate: payload.eventDate || todayISO(),
    description: payload.description,
  });
  refresh();
  return OK("رویداد در تقویم ثبت شد ✓");
}

export async function deleteEvent(eventId: number) {
  await db.delete(calendarEvents).where(eq(calendarEvents.id, eventId));
  refresh();
  return OK("رویداد حذف شد ✓");
}

export async function seedCheck() {
  const rows = await db.select({ value: sql<number>`count(*)::int` }).from(users);
  return rows[0]?.value ?? 0;
}
