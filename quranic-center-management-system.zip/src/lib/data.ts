import { and, asc, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  attendance,
  calendarEvents,
  certificates,
  classSessions,
  classes,
  enrollments,
  exams,
  hifzProgress,
  notifications,
  payments,
  recordings,
  students,
  teachers,
  users,
  type AttendanceStatus,
  type HifzStatus,
} from "@/db/schema";
import { addDays, faWeekdayIndex, isoDate, toJalali } from "@/lib/jalali";

export const TOTAL_HIFZ_PAGES = 604;

const studentUsers = alias(users, "student_users");
const teacherUsers = alias(users, "teacher_users");

/* ----------------------------- پروفایل‌ها -------------------------------- */

export async function getStudentByUserId(userId: number) {
  const rows = await db.select().from(students).where(eq(students.userId, userId)).limit(1);
  return rows[0] ?? null;
}

export async function getTeacherByUserId(userId: number) {
  const rows = await db.select().from(teachers).where(eq(teachers.userId, userId)).limit(1);
  return rows[0] ?? null;
}

export async function getStudentById(studentId: number) {
  const rows = await db
    .select({
      student: students,
      user: users,
    })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .where(eq(students.id, studentId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getTeacherById(teacherId: number) {
  const rows = await db
    .select({ teacher: teachers, user: users })
    .from(teachers)
    .innerJoin(users, eq(users.id, teachers.userId))
    .where(eq(teachers.id, teacherId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getUnreadCount(userId: number) {
  const rows = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return rows[0]?.value ?? 0;
}

/* ------------------------------ کلاس‌ها ---------------------------------- */

export async function listClasses() {
  return db
    .select({
      id: classes.id,
      name: classes.name,
      courseType: classes.courseType,
      days: classes.days,
      startTime: classes.startTime,
      durationMinutes: classes.durationMinutes,
      location: classes.location,
      mode: classes.mode,
      capacity: classes.capacity,
      tuition: classes.tuition,
      status: classes.status,
      description: classes.description,
      startDate: classes.startDate,
      endDate: classes.endDate,
      teacherName: users.fullName,
      teacherId: teachers.id,
    })
    .from(classes)
    .leftJoin(teachers, eq(teachers.id, classes.teacherId))
    .leftJoin(users, eq(users.id, teachers.userId))
    .orderBy(asc(classes.id));
}

export type ClassListItem = Awaited<ReturnType<typeof listClasses>>[number];

export async function getEnrollmentCounts() {
  const rows = await db
    .select({ classId: enrollments.classId, value: sql<number>`count(*)::int` })
    .from(enrollments)
    .groupBy(enrollments.classId);
  const map = new Map<number, number>();
  rows.forEach((row) => map.set(row.classId, row.value));
  return map;
}

export async function getClassById(classId: number) {
  const rows = await db
    .select({
      cls: classes,
      teacherName: users.fullName,
    })
    .from(classes)
    .leftJoin(teachers, eq(teachers.id, classes.teacherId))
    .leftJoin(users, eq(users.id, teachers.userId))
    .where(eq(classes.id, classId))
    .limit(1);
  return rows[0] ?? null;
}

export async function getClassStudents(classId: number) {
  return db
    .select({
      studentId: students.id,
      fullName: users.fullName,
      mobile: users.mobile,
      level: students.level,
      status: enrollments.status,
    })
    .from(enrollments)
    .innerJoin(students, eq(students.id, enrollments.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .where(and(eq(enrollments.classId, classId), eq(enrollments.status, "active")))
    .orderBy(asc(users.fullName));
}

export async function getSessionsInRange(fromISO: string, toISO: string, classIds?: number[]) {
  const conditions = [gte(classSessions.sessionDate, fromISO), lte(classSessions.sessionDate, toISO)];
  if (classIds && classIds.length > 0) {
    conditions.push(inArray(classSessions.classId, classIds));
  }
  return db
    .select({
      id: classSessions.id,
      classId: classSessions.classId,
      sessionDate: classSessions.sessionDate,
      startTime: classSessions.startTime,
      topic: classSessions.topic,
      status: classSessions.status,
      className: classes.name,
      mode: classes.mode,
      location: classes.location,
      teacherName: users.fullName,
    })
    .from(classSessions)
    .innerJoin(classes, eq(classes.id, classSessions.classId))
    .leftJoin(teachers, eq(teachers.id, classes.teacherId))
    .leftJoin(users, eq(users.id, teachers.userId))
    .where(and(...conditions))
    .orderBy(asc(classSessions.sessionDate), asc(classSessions.startTime));
}

export type SessionItem = Awaited<ReturnType<typeof getSessionsInRange>>[number];

export async function getSessionsForClasses(classIds: number[], fromISO: string, toISO: string) {
  if (classIds.length === 0) return [];
  return getSessionsInRange(fromISO, toISO, classIds);
}

/* --------------------------- قرآن‌آموزان --------------------------------- */

export async function listStudentsWithDetails() {
  const rows = await db
    .select({
      id: students.id,
      fullName: users.fullName,
      mobile: users.mobile,
      level: students.level,
      status: students.status,
      joinDate: students.joinDate,
      guardianName: students.guardianName,
      birthDate: students.birthDate,
      nationalCode: students.nationalCode,
      address: students.address,
      history: students.history,
      parentUserId: students.parentUserId,
      userId: students.userId,
    })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .orderBy(asc(users.fullName));

  const enrollRows = await db
    .select({ studentId: enrollments.studentId, className: classes.name })
    .from(enrollments)
    .innerJoin(classes, eq(classes.id, enrollments.classId));

  const paymentRows = await db
    .select({ studentId: payments.studentId, status: payments.status, amount: payments.amount })
    .from(payments);

  const examRows = await db
    .select({ studentId: exams.studentId, score: exams.score, maxScore: exams.maxScore })
    .from(exams);

  return rows.map((row) => {
    const classNames = enrollRows.filter((e) => e.studentId === row.id).map((e) => e.className);
    const studentPayments = paymentRows.filter((p) => p.studentId === row.id);
    const debt = studentPayments
      .filter((p) => p.status !== "paid")
      .reduce((sum, p) => sum + p.amount, 0);
    const studentExams = examRows.filter((e) => e.studentId === row.id);
    const average = studentExams.length
      ? Math.round(
          studentExams.reduce((sum, e) => sum + (e.score / Math.max(e.maxScore, 1)) * 100, 0) /
            studentExams.length,
        )
      : null;
    return { ...row, classNames, debt, average, examCount: studentExams.length };
  });
}

export type StudentListItem = Awaited<ReturnType<typeof listStudentsWithDetails>>[number];

export async function getStudentProfile(studentId: number) {
  const base = await getStudentById(studentId);
  if (!base) return null;

  const [enrolledClasses, hifzRows, examRows, paymentRows, recordingRows, certificateRows] =
    await Promise.all([
      db
        .select({
          id: classes.id,
          name: classes.name,
          courseType: classes.courseType,
          days: classes.days,
          startTime: classes.startTime,
          mode: classes.mode,
          location: classes.location,
          teacherName: users.fullName,
        })
        .from(enrollments)
        .innerJoin(classes, eq(classes.id, enrollments.classId))
        .leftJoin(teachers, eq(teachers.id, classes.teacherId))
        .leftJoin(users, eq(users.id, teachers.userId))
        .where(eq(enrollments.studentId, studentId)),
      db
        .select()
        .from(hifzProgress)
        .where(eq(hifzProgress.studentId, studentId))
        .orderBy(asc(hifzProgress.juz), asc(hifzProgress.page)),
      db
        .select()
        .from(exams)
        .where(eq(exams.studentId, studentId))
        .orderBy(desc(exams.examDate)),
      db
        .select()
        .from(payments)
        .where(eq(payments.studentId, studentId))
        .orderBy(asc(payments.dueDate)),
      db
        .select()
        .from(recordings)
        .where(eq(recordings.studentId, studentId))
        .orderBy(desc(recordings.createdAt)),
      db
        .select()
        .from(certificates)
        .where(eq(certificates.studentId, studentId))
        .orderBy(desc(certificates.issuedAt)),
    ]);

  const attendanceRows = await db
    .select({ status: attendance.status, sessionId: attendance.sessionId })
    .from(attendance)
    .where(eq(attendance.studentId, studentId));

  return {
    ...base,
    classes: enrolledClasses,
    hifz: hifzRows,
    exams: examRows,
    payments: paymentRows,
    recordings: recordingRows,
    certificates: certificateRows,
    attendance: attendanceRows,
  };
}

export type StudentProfile = NonNullable<Awaited<ReturnType<typeof getStudentProfile>>>;

/* ------------------------------ حفظ ------------------------------------- */

export function hifzSummary(rows: { status: HifzStatus }[]) {
  const memorized = rows.filter((r) => r.status === "memorized" || r.status === "stable").length;
  const inProgress = rows.filter((r) => r.status === "in_progress").length;
  const percent = Math.round((memorized / TOTAL_HIFZ_PAGES) * 100);
  return { memorized, inProgress, percent, remaining: TOTAL_HIFZ_PAGES - memorized };
}

/* ------------------------------ اساتید ---------------------------------- */

export async function listTeachersWithDetails() {
  const rows = await db
    .select({
      id: teachers.id,
      fullName: users.fullName,
      mobile: users.mobile,
      specialties: teachers.specialties,
      bio: teachers.bio,
      education: teachers.education,
      joinDate: teachers.joinDate,
      status: teachers.status,
      userId: teachers.userId,
    })
    .from(teachers)
    .innerJoin(users, eq(users.id, teachers.userId))
    .orderBy(asc(users.fullName));

  const classRows = await db
    .select({
      teacherId: classes.teacherId,
      className: classes.name,
      classId: classes.id,
    })
    .from(classes);

  const examRows = await db
    .select({ teacherId: exams.teacherId, value: sql<number>`count(*)::int` })
    .from(exams)
    .groupBy(exams.teacherId);

  const attendanceRows = await db
    .select({
      classId: classSessions.classId,
      status: attendance.status,
      value: sql<number>`count(*)::int`,
    })
    .from(attendance)
    .innerJoin(classSessions, eq(classSessions.id, attendance.sessionId))
    .groupBy(classSessions.classId, attendance.status);

  const classStudentRows = await db
    .select({ classId: enrollments.classId, value: sql<number>`count(*)::int` })
    .from(enrollments)
    .groupBy(enrollments.classId);

  return rows.map((row) => {
    const teacherClasses = classRows.filter((c) => c.teacherId === row.id);
    const classIds = teacherClasses.map((c) => c.classId);
    const studentCount = classStudentRows
      .filter((c) => classIds.includes(c.classId))
      .reduce((sum, c) => sum + c.value, 0);
    const relevantAttendance = attendanceRows.filter((a) => classIds.includes(a.classId));
    const total = relevantAttendance.reduce((sum, a) => sum + a.value, 0);
    const present = relevantAttendance
      .filter((a) => a.status === "present" || a.status === "late")
      .reduce((sum, a) => sum + a.value, 0);
    return {
      ...row,
      classNames: teacherClasses.map((c) => c.className),
      studentCount,
      examCount: examRows.find((e) => e.teacherId === row.id)?.value ?? 0,
      attendanceRate: total ? Math.round((present / total) * 100) : null,
    };
  });
}

export type TeacherListItem = Awaited<ReturnType<typeof listTeachersWithDetails>>[number];

/* ------------------------------ مالی ------------------------------------ */

export async function listPayments() {
  return db
    .select({
      id: payments.id,
      title: payments.title,
      amount: payments.amount,
      kind: payments.kind,
      dueDate: payments.dueDate,
      status: payments.status,
      paidAt: payments.paidAt,
      method: payments.method,
      trackingCode: payments.trackingCode,
      studentId: payments.studentId,
      parentUserId: payments.parentUserId,
      note: payments.note,
      studentName: users.fullName,
    })
    .from(payments)
    .leftJoin(students, eq(students.id, payments.studentId))
    .leftJoin(users, eq(users.id, students.userId))
    .orderBy(asc(payments.dueDate));
}

export type PaymentListItem = Awaited<ReturnType<typeof listPayments>>[number];

export async function financeTotals() {
  const rows = await db
    .select({
      status: payments.status,
      total: sql<number>`coalesce(sum(${payments.amount}), 0)::int`,
      value: sql<number>`count(*)::int`,
    })
    .from(payments)
    .groupBy(payments.status);
  const paid = rows.find((r) => r.status === "paid")?.total ?? 0;
  const unpaid = rows.find((r) => r.status === "unpaid")?.total ?? 0;
  const overdue = rows.find((r) => r.status === "overdue")?.total ?? 0;
  return { paid, unpaid, overdue, total: paid + unpaid + overdue };
}

/* ---------------------------- اعلان‌ها ---------------------------------- */

export async function listNotifications(userId: number) {
  return db
    .select({
      id: notifications.id,
      title: notifications.title,
      body: notifications.body,
      kind: notifications.kind,
      isRead: notifications.isRead,
      createdAt: notifications.createdAt,
      senderName: users.fullName,
    })
    .from(notifications)
    .leftJoin(users, eq(users.id, notifications.senderId))
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(60);
}

/* --------------------------- صوت و گواهی -------------------------------- */

export async function listRecordings(filter?: { studentIds?: number[]; teacherId?: number }) {
  const conditions = [];
  if (filter?.studentIds && filter.studentIds.length > 0) {
    conditions.push(inArray(recordings.studentId, filter.studentIds));
  }
  if (filter?.teacherId) {
    conditions.push(eq(recordings.teacherId, filter.teacherId));
  }
  return db
    .select({
      id: recordings.id,
      title: recordings.title,
      surahName: recordings.surahName,
      ayahRange: recordings.ayahRange,
      status: recordings.status,
      score: recordings.score,
      feedback: recordings.feedback,
      createdAt: recordings.createdAt,
      hasAudio: sql<boolean>`(${recordings.audioData} is not null)`,
      mimeType: recordings.mimeType,
      studentId: recordings.studentId,
      studentName: users.fullName,
      className: classes.name,
      teacherId: recordings.teacherId,
    })
    .from(recordings)
    .innerJoin(students, eq(students.id, recordings.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .leftJoin(classes, eq(classes.id, recordings.classId))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(recordings.createdAt));
}

export type RecordingListItem = Awaited<ReturnType<typeof listRecordings>>[number];

export async function listCertificates(filter?: { studentIds?: number[] }) {
  const conditions = [];
  if (filter?.studentIds && filter.studentIds.length > 0) {
    conditions.push(inArray(certificates.studentId, filter.studentIds));
  }
  return db
    .select({
      id: certificates.id,
      courseName: certificates.courseName,
      level: certificates.level,
      grade: certificates.grade,
      teacherName: certificates.teacherName,
      serial: certificates.serial,
      hours: certificates.hours,
      issuedAt: certificates.issuedAt,
      studentId: certificates.studentId,
      studentName: users.fullName,
    })
    .from(certificates)
    .innerJoin(students, eq(students.id, certificates.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(certificates.issuedAt));
}

/* ----------------------------- تقویم ------------------------------------ */

export async function listEvents(fromISO?: string, toISO?: string) {
  const conditions = [];
  if (fromISO) conditions.push(gte(calendarEvents.eventDate, fromISO));
  if (toISO) conditions.push(lte(calendarEvents.eventDate, toISO));
  return db
    .select()
    .from(calendarEvents)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(asc(calendarEvents.eventDate));
}

/* --------------------------- داشبورد مدیر ------------------------------- */

export async function managerDashboard() {
  const today = isoDate(new Date());

  const [counts, classRows, todaySessions, paymentRows, upcomingExams, eventRows, recentUsers] =
    await Promise.all([
      db
        .select({ role: users.role, value: sql<number>`count(*)::int` })
        .from(users)
        .groupBy(users.role),
      db.select().from(classes).where(eq(classes.status, "active")),
      getSessionsInRange(today, today),
      db
        .select({
          id: payments.id,
          title: payments.title,
          amount: payments.amount,
          status: payments.status,
          dueDate: payments.dueDate,
          studentName: users.fullName,
        })
        .from(payments)
        .leftJoin(students, eq(students.id, payments.studentId))
        .leftJoin(users, eq(users.id, students.userId))
        .orderBy(asc(payments.dueDate)),
      db
        .select({
          id: exams.id,
          title: exams.title,
          examDate: exams.examDate,
          studentName: users.fullName,
        })
        .from(exams)
        .innerJoin(students, eq(students.id, exams.studentId))
        .innerJoin(users, eq(users.id, students.userId))
        .where(gte(exams.examDate, today))
        .orderBy(asc(exams.examDate))
        .limit(5),
      db
        .select()
        .from(calendarEvents)
        .where(gte(calendarEvents.eventDate, today))
        .orderBy(asc(calendarEvents.eventDate))
        .limit(5),
      db
        .select({
          id: users.id,
          fullName: users.fullName,
          role: users.role,
          mobile: users.mobile,
          createdAt: users.createdAt,
        })
        .from(users)
        .where(inArray(users.role, ["student", "teacher", "parent"]))
        .orderBy(desc(users.createdAt))
        .limit(6),
    ]);

  const studentRows = await db
    .select({ joinDate: students.joinDate })
    .from(students)
    .orderBy(asc(students.joinDate));

  const attendanceRows = await db
    .select({
      sessionDate: classSessions.sessionDate,
      status: attendance.status,
      value: sql<number>`count(*)::int`,
    })
    .from(attendance)
    .innerJoin(classSessions, eq(classSessions.id, attendance.sessionId))
    .groupBy(classSessions.sessionDate, attendance.status)
    .orderBy(desc(classSessions.sessionDate))
    .limit(120);

  const byRole = (role: string) => counts.find((c) => c.role === role)?.value ?? 0;

  /* روند رشد: تعداد قرآن‌آموزان تجمعی در ۶ ماه اخیر */
  const growth: { label: string; value: number }[] = [];
  for (let i = 5; i >= 0; i -= 1) {
    const date = addDays(new Date(), -i * 30);
    const { jy, jm } = toJalali(date);
    const limitISO = isoDate(date);
    const value = studentRows.filter((s) => s.joinDate <= limitISO).length;
    growth.push({ label: `${jm} / ${String(jy).slice(2)}`, value });
  }

  /* روند حضور در ۶ جلسه اخیر */
  const dateKeys = Array.from(new Set(attendanceRows.map((r) => r.sessionDate))).slice(0, 6).reverse();
  const attendanceTrend = dateKeys.map((date) => {
    const rows = attendanceRows.filter((r) => r.sessionDate === date);
    const total = rows.reduce((sum, r) => sum + r.value, 0);
    const present = rows
      .filter((r) => r.status === "present" || r.status === "late")
      .reduce((sum, r) => sum + r.value, 0);
    return { label: date.slice(5), value: total ? Math.round((present / total) * 100) : 0 };
  });

  const overdueList = paymentRows.filter((p) => p.status === "overdue");
  const upcomingPayments = paymentRows.filter(
    (p) => p.status !== "paid" && p.dueDate >= today,
  );

  return {
    stats: {
      students: byRole("student"),
      teachers: byRole("teacher"),
      parents: byRole("parent"),
      activeClasses: classRows.length,
      todaySessions: todaySessions.length,
    },
    todaySessions,
    growth,
    attendanceTrend,
    overdueList,
    upcomingPayments: upcomingPayments.slice(0, 5),
    upcomingExams,
    events: eventRows,
    recentUsers,
    finance: financeTotalsFromRows(paymentRows.map((p) => ({ status: p.status, amount: p.amount }))),
  };
}

function financeTotalsFromRows(rows: { status: string; amount: number }[]) {
  const sum = (status: string) =>
    rows.filter((r) => r.status === status).reduce((acc, r) => acc + r.amount, 0);
  const paid = sum("paid");
  const unpaid = sum("unpaid");
  const overdue = sum("overdue");
  return { paid, unpaid, overdue, total: paid + unpaid + overdue };
}

/* --------------------------- داشبورد استاد ------------------------------ */

export async function teacherDashboard(teacherId: number) {
  const today = isoDate(new Date());
  const myClasses = await db
    .select()
    .from(classes)
    .where(eq(classes.teacherId, teacherId))
    .orderBy(asc(classes.id));

  const classIds = myClasses.map((c) => c.id);
  const sessions = await getSessionsForClasses(
    classIds,
    isoDate(addDays(new Date(), -7)),
    isoDate(addDays(new Date(), 14)),
  );
  const studentRows = classIds.length
    ? await db
        .select({
          studentId: students.id,
          fullName: users.fullName,
          classId: enrollments.classId,
          className: classes.name,
          level: students.level,
        })
        .from(enrollments)
        .innerJoin(students, eq(students.id, enrollments.studentId))
        .innerJoin(users, eq(users.id, students.userId))
        .innerJoin(classes, eq(classes.id, enrollments.classId))
        .where(inArray(enrollments.classId, classIds))
    : [];

  const pendingRecordings = await db
    .select({
      id: recordings.id,
      title: recordings.title,
      studentName: users.fullName,
      createdAt: recordings.createdAt,
    })
    .from(recordings)
    .innerJoin(students, eq(students.id, recordings.studentId))
    .innerJoin(users, eq(users.id, students.userId))
    .where(
      and(
        eq(recordings.status, "pending"),
        classIds.length ? inArray(recordings.classId, classIds) : sql`true`,
      ),
    )
    .orderBy(desc(recordings.createdAt));

  const attendanceRows = await db
    .select({ status: attendance.status, value: sql<number>`count(*)::int` })
    .from(attendance)
    .innerJoin(classSessions, eq(classSessions.id, attendance.sessionId))
    .where(classIds.length ? inArray(classSessions.classId, classIds) : sql`true`)
    .groupBy(attendance.status);

  const totalAttendance = attendanceRows.reduce((sum, r) => sum + r.value, 0);
  const presentAttendance = attendanceRows
    .filter((r) => r.status === "present" || r.status === "late")
    .reduce((sum, r) => sum + r.value, 0);

  const examRows = classIds.length
    ? await db
        .select({
          id: exams.id,
          title: exams.title,
          examDate: exams.examDate,
          score: exams.score,
          maxScore: exams.maxScore,
          studentName: users.fullName,
        })
        .from(exams)
        .innerJoin(students, eq(students.id, exams.studentId))
        .innerJoin(users, eq(users.id, students.userId))
        .where(inArray(exams.classId, classIds))
        .orderBy(desc(exams.examDate))
        .limit(6)
    : [];

  return {
    classes: myClasses,
    sessions,
    todaySessions: sessions.filter((s) => s.sessionDate === today),
    students: studentRows,
    pendingRecordings,
    examRows,
    attendanceRate: totalAttendance ? Math.round((presentAttendance / totalAttendance) * 100) : 0,
  };
}

/* -------------------------- داشبورد قرآن‌آموز ---------------------------- */

export async function studentDashboard(studentId: number) {
  const today = isoDate(new Date());
  const profile = await getStudentProfile(studentId);
  if (!profile) return null;

  const classIds = profile.classes.map((c) => c.id);
  const sessions = await getSessionsForClasses(
    classIds,
    isoDate(addDays(new Date(), -3)),
    isoDate(addDays(new Date(), 10)),
  );

  return {
    profile,
    summary: hifzSummary(profile.hifz),
    sessions,
    todaySessions: sessions.filter((s) => s.sessionDate === today),
    upcomingExams: profile.exams
      .filter((e) => e.examDate >= today)
      .sort((a, b) => a.examDate.localeCompare(b.examDate))
      .slice(0, 4),
    recentExams: [...profile.exams].sort((a, b) => b.examDate.localeCompare(a.examDate)).slice(0, 5),
    debt: profile.payments
      .filter((p) => p.status !== "paid")
      .reduce((sum, p) => sum + p.amount, 0),
  };
}

/* ---------------------------- داشبورد ولی ------------------------------- */

export async function parentDashboard(parentUserId: number) {
  const children = await db
    .select({
      id: students.id,
      fullName: users.fullName,
      level: students.level,
      status: students.status,
      joinDate: students.joinDate,
    })
    .from(students)
    .innerJoin(users, eq(users.id, students.userId))
    .where(eq(students.parentUserId, parentUserId));

  const childIds = children.map((c) => c.id);

  const paymentRows = childIds.length
    ? await db
        .select()
        .from(payments)
        .where(inArray(payments.studentId, childIds))
        .orderBy(asc(payments.dueDate))
    : [];

  const hifzRows = childIds.length
    ? await db.select().from(hifzProgress).where(inArray(hifzProgress.studentId, childIds))
    : [];

  const examRows = childIds.length
    ? await db
        .select({
          id: exams.id,
          title: exams.title,
          examDate: exams.examDate,
          score: exams.score,
          maxScore: exams.maxScore,
          examType: exams.examType,
          studentId: exams.studentId,
          studentName: users.fullName,
        })
        .from(exams)
        .innerJoin(students, eq(students.id, exams.studentId))
        .innerJoin(users, eq(users.id, students.userId))
        .where(inArray(exams.studentId, childIds))
        .orderBy(desc(exams.examDate))
        .limit(10)
    : [];

  const attendanceRows = childIds.length
    ? await db
        .select({ studentId: attendance.studentId, status: attendance.status })
        .from(attendance)
        .where(inArray(attendance.studentId, childIds))
    : [];

  const classRows = childIds.length
    ? await db
        .select({
          studentId: enrollments.studentId,
          studentName: studentUsers.fullName,
          className: classes.name,
          days: classes.days,
          startTime: classes.startTime,
          mode: classes.mode,
          teacherName: teacherUsers.fullName,
        })
        .from(enrollments)
        .innerJoin(students, eq(students.id, enrollments.studentId))
        .innerJoin(studentUsers, eq(studentUsers.id, students.userId))
        .innerJoin(classes, eq(classes.id, enrollments.classId))
        .leftJoin(teachers, eq(teachers.id, classes.teacherId))
        .leftJoin(teacherUsers, eq(teacherUsers.id, teachers.userId))
        .where(inArray(enrollments.studentId, childIds))
    : [];

  return {
    children,
    payments: paymentRows,
    debt: paymentRows.filter((p) => p.status !== "paid").reduce((s, p) => s + p.amount, 0),
    hifz: hifzRows,
    exams: examRows,
    attendance: attendanceRows,
    classRows,
  };
}

/* --------------------------- حضور و غیاب -------------------------------- */

export async function getSessionAttendance(sessionId: number) {
  const rows = await db
    .select({ studentId: attendance.studentId, status: attendance.status })
    .from(attendance)
    .where(eq(attendance.sessionId, sessionId));
  const map = new Map<number, AttendanceStatus>();
  rows.forEach((row) => map.set(row.studentId, row.status));
  return map;
}

/* ---------------------------- گزارش‌ها ---------------------------------- */

export async function reportsData() {
  const today = isoDate(new Date());
  const [studentRows, teacherRows, classRows, examRows, attendanceRows, finance] = await Promise.all([
    listStudentsWithDetails(),
    listTeachersWithDetails(),
    listClasses(),
    db
      .select({
        classId: exams.classId,
        score: exams.score,
        maxScore: exams.maxScore,
      })
      .from(exams),
    db
      .select({ status: attendance.status, value: sql<number>`count(*)::int` })
      .from(attendance)
      .groupBy(attendance.status),
    financeTotals(),
  ]);

  const enrollmentRows = await db
    .select({ classId: enrollments.classId })
    .from(enrollments);

  const classPerformance = classRows.map((cls) => {
    const clsExams = examRows.filter((e) => e.classId === cls.id);
    const average = clsExams.length
      ? Math.round(
          (clsExams.reduce((s, e) => s + e.score / Math.max(e.maxScore, 1), 0) / clsExams.length) *
            100,
        )
      : null;
    return {
      id: cls.id,
      name: cls.name,
      teacherName: cls.teacherName ?? "—",
      students: enrollmentRows.filter((e) => e.classId === cls.id).length,
      average,
    };
  });

  const totalAttendance = attendanceRows.reduce((s, r) => s + r.value, 0);
  const presentAttendance = attendanceRows
    .filter((r) => r.status === "present" || r.status === "late")
    .reduce((s, r) => s + r.value, 0);

  return {
    today,
    studentRows,
    teacherRows,
    classPerformance,
    finance,
    attendanceRate: totalAttendance ? Math.round((presentAttendance / totalAttendance) * 100) : 0,
    examCount: examRows.length,
    activeStudents: studentRows.filter((s) => s.status === "active").length,
    pendingStudents: studentRows.filter((s) => s.status === "pending").length,
  };
}

/* ------------------------- یاری‌گرهای دسترسی ----------------------------- */

export async function classIdsForStudent(studentId: number) {
  const rows = await db
    .select({ classId: enrollments.classId })
    .from(enrollments)
    .where(eq(enrollments.studentId, studentId));
  return rows.map((r) => r.classId);
}

export async function classIdsForTeacher(teacherId: number) {
  const rows = await db
    .select({ id: classes.id })
    .from(classes)
    .where(eq(classes.teacherId, teacherId));
  return rows.map((r) => r.id);
}

export async function classesForTeacher(teacherId: number) {
  return db.select().from(classes).where(eq(classes.teacherId, teacherId));
}

export async function weekdayOf(dateISO: string) {
  return faWeekdayIndex(dateISO);
}
