/* تبدیل تاریخ میلادی/شمسی — الگوریتم جلالی (jalaali) */

const div = (a: number, b: number) => Math.trunc(a / b);
const mod = (a: number, b: number) => a - b * Math.floor(a / b);

export const JALALI_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

/** شنبه = 0 ... جمعه = 6 */
export const WEEK_DAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
export const WEEK_DAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

function jalCal(jy: number) {
  const breaks = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324,
    2394, 2456, 3178,
  ];
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];
  let jump = 0;
  for (let i = 1; i < breaks.length; i += 1) {
    const jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;
  leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;
  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;
  return { leap, gy, march };
}

function g2d(gy: number, gm: number, gd: number) {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) + div(153 * mod(gm + 9, 12) + 2, 5) + gd;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

export function jalaaliMonthLength(jy: number, jm: number) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return jalCal(jy).leap === 0 ? 30 : 29;
}

export function toJalali(input: Date | string): { jy: number; jm: number; jd: number } {
  const date = typeof input === "string" ? new Date(`${input}T00:00:00`) : input;
  const jdn = g2d(date.getFullYear(), date.getMonth() + 1, date.getDate());
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;
  if (k >= 0) {
    if (k <= 185) {
      return { jy, jm: 1 + div(k, 31), jd: mod(k, 31) + 1 };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  return { jy, jm: 7 + div(k, 30), jd: mod(k, 30) + 1 };
}

export function toGregorian(jy: number, jm: number, jd: number): Date {
  const r = jalCal(jy);
  const jdn = g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
  const g = d2g(jdn);
  return new Date(g.gy, g.gm - 1, g.gd);
}

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function faDigits(value: string | number): string {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

export function faNum(value: number): string {
  return faDigits(value.toLocaleString("en-US"));
}

export function pad2(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

/** YYYY-MM-DD میلادی برای ذخیره در پایگاه داده */
export function isoDate(date: Date = new Date()): string {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

export function parseISO(value: string): Date {
  return new Date(`${value}T00:00:00`);
}

/** ۱۴۰۴/۰۷/۲۳ */
export function faDate(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const { jy, jm, jd } = toJalali(value);
  return faDigits(`${jy}/${pad2(jm)}/${pad2(jd)}`);
}

/** ۲۳ مهر ۱۴۰۴ */
export function faDateLong(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const { jy, jm, jd } = toJalali(value);
  return `${faDigits(jd)} ${JALALI_MONTHS[jm - 1]} ${faDigits(jy)}`;
}

export function faWeekday(value: Date | string): string {
  const date = typeof value === "string" ? parseISO(value) : value;
  return WEEK_DAYS[(date.getDay() + 1) % 7];
}

/** شنبه ۲۳ مهر */
export function faDateShort(value: Date | string): string {
  const date = typeof value === "string" ? parseISO(value) : value;
  const { jm, jd } = toJalali(date);
  return `${faWeekday(date)} ${faDigits(jd)} ${JALALI_MONTHS[jm - 1]}`;
}

/** ایندکس روز هفته فارسی ۰=شنبه */
export function faWeekdayIndex(value: Date | string): number {
  const date = typeof value === "string" ? parseISO(value) : value;
  return (date.getDay() + 1) % 7;
}

export function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

export function todayISO(): string {
  return isoDate(new Date());
}

export function faTime(value: string): string {
  return faDigits(value);
}

/** "0,2,4" → «شنبه، دوشنبه، چهارشنبه» */
export function faDays(days: string): string {
  if (!days) return "—";
  return days
    .split(",")
    .map((day) => WEEK_DAYS[Number(day.trim())] ?? "")
    .filter(Boolean)
    .join("، ");
}

export function faMoney(value: number): string {
  return `${faNum(value)} تومان`;
}
