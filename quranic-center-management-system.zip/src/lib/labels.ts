import type {
  AttendanceStatus,
  ClassMode,
  EventType,
  ExamType,
  HifzStatus,
  PaymentKind,
  PaymentStatus,
  RecordingStatus,
  RegistrationStatus,
  StudentLevel,
} from "@/db/schema";

export const LEVELS: { value: StudentLevel; label: string }[] = [
  { value: "rokhani", label: "روخوانی" },
  { value: "tajvid", label: "تجوید" },
  { value: "hifz", label: "حفظ" },
  { value: "qeraat", label: "قرائت" },
  { value: "mafhim", label: "مفاهیم" },
];

export const levelLabel = (value: string) =>
  LEVELS.find((l) => l.value === value)?.label ?? value;

export const TEACHER_SPECIALTIES = [
  "ترتیل",
  "تحقیق",
  "حفظ",
  "صوت و لحن",
  "تجوید",
  "مفاهیم",
  "روخوانی",
  "قرائت",
];

export const EXAM_TYPES: { value: ExamType; label: string }[] = [
  { value: "new_page", label: "صفحه جدید" },
  { value: "tashbit", label: "تثبیت" },
  { value: "full_juz", label: "کل جزء" },
  { value: "oral", label: "شفاهی" },
];

export const examTypeLabel = (value: string) =>
  EXAM_TYPES.find((t) => t.value === value)?.label ?? value;

export const ATTENDANCE: { value: AttendanceStatus; label: string; short: string }[] = [
  { value: "present", label: "حاضر", short: "ح" },
  { value: "absent", label: "غایب", short: "غ" },
  { value: "late", label: "تأخیر", short: "ت" },
  { value: "excused", label: "موجه", short: "م" },
];

export const attendanceMeta: Record<
  AttendanceStatus,
  { label: string; className: string; dot: string }
> = {
  present: {
    label: "حاضر",
    className: "bg-emerald-100 text-emerald-800 ring-emerald-300",
    dot: "bg-emerald-500",
  },
  absent: {
    label: "غایب",
    className: "bg-rose-100 text-rose-800 ring-rose-300",
    dot: "bg-rose-500",
  },
  late: {
    label: "تأخیر",
    className: "bg-amber-100 text-amber-900 ring-amber-300",
    dot: "bg-amber-500",
  },
  excused: {
    label: "موجه",
    className: "bg-sky-100 text-sky-800 ring-sky-300",
    dot: "bg-sky-500",
  },
};

export const paymentStatusMeta: Record<
  PaymentStatus,
  { label: string; className: string }
> = {
  paid: { label: "پرداخت شده", className: "bg-emerald-100 text-emerald-800 ring-emerald-300" },
  unpaid: { label: "پرداخت نشده", className: "bg-slate-100 text-slate-700 ring-slate-300" },
  overdue: { label: "معوق", className: "bg-rose-100 text-rose-800 ring-rose-300" },
};

export const paymentKindLabel: Record<PaymentKind, string> = {
  tuition: "شهریه",
  donation: "کمک به هیئت امنا",
  other: "متفرقه",
};

export const classModeMeta: Record<ClassMode, { label: string; className: string }> = {
  inperson: { label: "حضوری", className: "bg-emerald-50 text-emerald-700 ring-emerald-200" },
  online: { label: "آنلاین", className: "bg-indigo-50 text-indigo-700 ring-indigo-200" },
};

export const hifzStatusMeta: Record<HifzStatus, { label: string; className: string }> = {
  none: { label: "شروع نشده", className: "bg-slate-100 text-slate-500 ring-slate-200" },
  in_progress: { label: "در حال حفظ", className: "bg-amber-100 text-amber-800 ring-amber-300" },
  memorized: { label: "حفظ شده", className: "bg-emerald-100 text-emerald-800 ring-emerald-300" },
  stable: { label: "تثبیت‌شده", className: "bg-teal-700 text-white ring-teal-800" },
};

export const recordingStatusMeta: Record<RecordingStatus, { label: string; className: string }> = {
  pending: { label: "در انتظار تصحیح", className: "bg-amber-100 text-amber-800 ring-amber-300" },
  reviewed: { label: "تصحیح شد", className: "bg-emerald-100 text-emerald-800 ring-emerald-300" },
};

export const registrationStatusMeta: Record<
  RegistrationStatus,
  { label: string; className: string }
> = {
  pending: { label: "در انتظار تأیید", className: "bg-amber-100 text-amber-800 ring-amber-300" },
  active: { label: "فعال", className: "bg-emerald-100 text-emerald-800 ring-emerald-300" },
  rejected: { label: "رد شده", className: "bg-rose-100 text-rose-800 ring-rose-300" },
};

export const eventTypeMeta: Record<EventType, { label: string; className: string }> = {
  exam: { label: "آزمون", className: "bg-amber-100 text-amber-800 ring-amber-300" },
  occasion: { label: "مناسبت", className: "bg-emerald-100 text-emerald-800 ring-emerald-300" },
  trip: { label: "اردو", className: "bg-sky-100 text-sky-800 ring-sky-300" },
  meeting: { label: "جلسه / دیدار", className: "bg-indigo-100 text-indigo-800 ring-indigo-300" },
};

export const notificationKindLabel: Record<string, string> = {
  general: "عمومی",
  absence: "غیبت",
  exam: "آزمون",
  payment: "مالی",
  registration: "ثبت‌نام",
  recording: "صوت تلاوت",
  certificate: "گواهی",
};
