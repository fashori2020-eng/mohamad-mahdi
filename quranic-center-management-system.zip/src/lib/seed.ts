import { db } from "@/db";
import {
  attendance,
  calendarEvents,
  certificates,
  classSessions,
  classes,
  enrollments,
  exams,
  hifzProgress,
  notifications,
  payments,
  recordings,
  students,
  teachers,
  users,
  type AttendanceStatus,
  type HifzStatus,
} from "@/db/schema";
import { addDays, faWeekdayIndex, isoDate } from "@/lib/jalali";

let seedPromise: Promise<void> | null = null;

/** داده‌های نمایشی — تنها یک بار و در صورت خالی بودن پایگاه داده اجرا می‌شود */
export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

const DAY = 24 * 60 * 60 * 1000;
const shift = (days: number) => isoDate(new Date(Date.now() + days * DAY));

async function runSeed(): Promise<void> {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length > 0) return;

  const insertedUsers = await db
    .insert(users)
    .values([
      { fullName: "حاج آقا رسول هدایتی", mobile: "09121110000", role: "manager" },
      { fullName: "استاد محمدرضا کریمی", mobile: "09121230001", role: "teacher" },
      { fullName: "استاد سیده فاطمه موسوی", mobile: "09121230002", role: "teacher" },
      { fullName: "استاد عبدالرحمن شریفی", mobile: "09121230003", role: "teacher" },
      { fullName: "مهدی محمدی", mobile: "09351010001", role: "student" },
      { fullName: "زهرا احمدی", mobile: "09351010002", role: "student" },
      { fullName: "علی رضایی", mobile: "09351010003", role: "student" },
      { fullName: "فاطمه حسینی", mobile: "09351010004", role: "student" },
      { fullName: "یوسف کاظمی", mobile: "09351010005", role: "student" },
      { fullName: "مریم نوری", mobile: "09351010006", role: "student" },
      { fullName: "حاج آقا محمد محمدی", mobile: "09352020001", role: "parent" },
      { fullName: "خانم سمیرا رضایی", mobile: "09352020002", role: "parent" },
      { fullName: "حاج آقا علی کاظمی", mobile: "09352020003", role: "parent" },
    ])
    .returning({ id: users.id, role: users.role, mobile: users.mobile });

  const uid = (mobile: string) => insertedUsers.find((u) => u.mobile === mobile)!.id;

  const managerId = uid("09121110000");
  const teacherUsers = insertedUsers.filter((u) => u.role === "teacher");

  const insertedTeachers = await db
    .insert(teachers)
    .values([
      {
        userId: uid("09121230001"),
        specialties: "ترتیل,حفظ,صوت و لحن",
        bio: "دارای مجوز رسمی روایت حفص از اعظم و ۱۲ سال سابقه تدریس حفظ کل قرآن کریم.",
        education: "کارشناسی ارشد علوم قرآن و حدیث",
        joinDate: shift(-720),
      },
      {
        userId: uid("09121230002"),
        specialties: "تجوید,تحقیق,روخوانی",
        bio: "مدرس دوره‌های تجوید و صوت و لحن، برگزیده مسابقات سراسری قرآن کریم.",
        education: "کارشناسی الهیات گرایش قرائات",
        joinDate: shift(-540),
      },
      {
        userId: uid("09121230003"),
        specialties: "مفاهیم,قرائت,ترتیل",
        bio: "مدرس علوم قرآنی و مفاهیم، طراح آزمون‌های مفاهیم مجموعه.",
        education: "کارشناسی علوم قرآن و حدیث",
        joinDate: shift(-400),
      },
    ])
    .returning({ id: teachers.id, userId: teachers.userId });

  const tid = (index: number) => insertedTeachers[index].id;

  const insertedStudents = await db
    .insert(students)
    .values([
      {
        userId: uid("09351010001"),
        parentUserId: uid("09352020001"),
        level: "hifz",
        birthDate: "2009-04-18",
        nationalCode: "1270540112",
        address: "قم، بلوار شهدا، کوچه ۱۲",
        guardianName: "حاج آقا محمد محمدی",
        joinDate: shift(-400),
        history: "ناظم جزء ۳۰ و ۲۹ — شرکت‌کننده المپیاد قرآن کریم",
        status: "active",
      },
      {
        userId: uid("09351010002"),
        parentUserId: uid("09352020001"),
        level: "hifz",
        birthDate: "2011-09-02",
        nationalCode: "1380224471",
        address: "قم، بلوار شهدا، کوچه ۱۲",
        guardianName: "حاج آقا محمد محمدی",
        joinDate: shift(-330),
        history: "گذراندن دوره روخوانی و تجوید مقدماتی",
        status: "active",
      },
      {
        userId: uid("09351010003"),
        parentUserId: uid("09352020002"),
        level: "tajvid",
        birthDate: "2008-01-25",
        nationalCode: "1190885566",
        address: "قم، خیابان انقلاب",
        guardianName: "خانم سمیرا رضایی",
        joinDate: shift(-260),
        history: "آشنایی با احکام تجوید سطح یک",
        status: "active",
      },
      {
        userId: uid("09351010004"),
        parentUserId: uid("09352020002"),
        level: "rokhani",
        birthDate: "2013-06-11",
        nationalCode: "1420773311",
        address: "قم، خیابان انقلاب",
        guardianName: "خانم سمیرا رضایی",
        joinDate: shift(-120),
        history: "ثبت‌نام جدید — در حال یادگیری حروف",
        status: "active",
      },
      {
        userId: uid("09351010005"),
        parentUserId: uid("09352020003"),
        level: "qeraat",
        birthDate: "2007-11-30",
        nationalCode: "1040998877",
        address: "قم، صفائیه، بلوار گلها",
        guardianName: "حاج آقا علی کاظمی",
        joinDate: shift(-610),
        history: "قاری برتر جشنواره قرآنی استان",
        status: "active",
      },
      {
        userId: uid("09351010006"),
        parentUserId: uid("09352020003"),
        level: "mafhim",
        birthDate: "2010-03-08",
        nationalCode: "1330664422",
        address: "قم، صفائیه، بلوار گلها",
        guardianName: "حاج آقا علی کاظمی",
        joinDate: shift(-90),
        history: "ثبت‌نام جدید — در انتظار تعیین سطح",
        status: "pending",
      },
    ])
    .returning({ id: students.id, userId: students.userId, level: students.level });

  const sid = (index: number) => insertedStudents[index].id;

  const insertedClasses = await db
    .insert(classes)
    .values([
      {
        name: "حفظ جزء سیام",
        courseType: "hifz",
        teacherId: tid(0),
        days: "0,2,4",
        startTime: "17:00",
        durationMinutes: 90,
        location: "سالن شهید مطهری — مجموعه معارج",
        mode: "inperson",
        capacity: 12,
        tuition: 750000,
        startDate: shift(-120),
        endDate: shift(120),
        description: "حفظ یک‌طرفه و دوطرفه جزء ۳۰ با تثبیت هفتگی و آزمون صفحه جدید.",
      },
      {
        name: "روخوانی مقدماتی (نوجوانان)",
        courseType: "rokhani",
        teacherId: tid(1),
        days: "1,3",
        startTime: "16:00",
        durationMinutes: 75,
        location: "پلتفرم اسکای‌روم",
        mode: "online",
        capacity: 20,
        tuition: 420000,
        startDate: shift(-90),
        endDate: shift(90),
        description: "آموزش حروف، حرکت‌گذاری و روان‌خوانی برای قرآن‌آموزان تازه‌کار.",
      },
      {
        name: "تجوید و صوت و لحن",
        courseType: "tajvid",
        teacherId: tid(1),
        days: "0,3",
        startTime: "18:30",
        durationMinutes: 90,
        location: "کلاس ۲ — ساختمان آموزشی",
        mode: "inperson",
        capacity: 15,
        tuition: 600000,
        startDate: shift(-150),
        endDate: shift(60),
        description: "احکام تجوید، مخارج حروف و تمرین عملی صوت و لحن.",
      },
      {
        name: "قرائت تحقیقی",
        courseType: "qeraat",
        teacherId: tid(2),
        days: "2,5",
        startTime: "10:00",
        durationMinutes: 120,
        location: "سالن اصلی — مجموعه معارج",
        mode: "inperson",
        capacity: 10,
        tuition: 900000,
        startDate: shift(-200),
        endDate: shift(160),
        description: "آموزش قرائت تحقیقی با روایت حفص و تمرین مراتبی صوت.",
      },
      {
        name: "مفاهیم قرآن کریم",
        courseType: "mafhim",
        teacherId: tid(2),
        days: "4",
        startTime: "19:00",
        durationMinutes: 60,
        location: "پلتفرم اسکای‌روم",
        mode: "online",
        capacity: 25,
        tuition: 380000,
        startDate: shift(-60),
        endDate: shift(100),
        description: "ترجمه و مفاهیم آیات، کیفیت‌های قرآنی و تمهیدی برای حفظ.",
      },
    ])
    .returning({ id: classes.id, days: classes.days, startTime: classes.startTime, name: classes.name });

  const cid = (index: number) => insertedClasses[index].id;

  await db.insert(enrollments).values([
    { classId: cid(0), studentId: sid(0), enrolledAt: shift(-120) },
    { classId: cid(0), studentId: sid(1), enrolledAt: shift(-110) },
    { classId: cid(1), studentId: sid(2), enrolledAt: shift(-90) },
    { classId: cid(1), studentId: sid(3), enrolledAt: shift(-80) },
    { classId: cid(2), studentId: sid(2), enrolledAt: shift(-150) },
    { classId: cid(2), studentId: sid(5), enrolledAt: shift(-60) },
    { classId: cid(3), studentId: sid(4), enrolledAt: shift(-200) },
    { classId: cid(4), studentId: sid(0), enrolledAt: shift(-60) },
    { classId: cid(4), studentId: sid(3), enrolledAt: shift(-55) },
    { classId: cid(4), studentId: sid(5), enrolledAt: shift(-50) },
  ]);

  /* ---------------- جلسات کلاس‌ها (۲۴ روز قبل تا ۱۴ روز بعد) --------------- */
  const topics = [
    "مرور و تثبیت صفحه‌های قبلی",
    "حفظ صفحه جدید",
    "تمرین صوت و لحن",
    "آزمون و ارزشیابی",
    "روخوانی و اصلاح لحن",
  ];

  const sessionRows: {
    classId: number;
    sessionDate: string;
    startTime: string;
    topic: string;
  }[] = [];

  insertedClasses.forEach((cls, classIndex) => {
    const dayList = cls.days.split(",").map(Number);
    for (let offset = -24; offset <= 14; offset += 1) {
      const date = addDays(new Date(), offset);
      if (!dayList.includes(faWeekdayIndex(date))) continue;
      sessionRows.push({
        classId: cls.id,
        sessionDate: isoDate(date),
        startTime: cls.startTime,
        topic: topics[(Math.abs(offset) + classIndex) % topics.length],
      });
    }
  });

  const insertedSessions = await db
    .insert(classSessions)
    .values(sessionRows)
    .returning({
      id: classSessions.id,
      classId: classSessions.classId,
      sessionDate: classSessions.sessionDate,
    });

  /* --------------------------- حضور و غیاب ------------------------------ */
  const enrollmentRows = await db
    .select({ classId: enrollments.classId, studentId: enrollments.studentId })
    .from(enrollments);

  const pattern: AttendanceStatus[] = [
    "present",
    "present",
    "present",
    "absent",
    "present",
    "late",
    "present",
    "excused",
  ];

  const attendanceRows: { sessionId: number; studentId: number; status: AttendanceStatus }[] = [];
  let counter = 0;
  insertedSessions
    .filter((s) => s.sessionDate < isoDate(new Date()))
    .forEach((session) => {
      enrollmentRows
        .filter((e) => e.classId === session.classId)
        .forEach((enrollment) => {
          counter += 1;
          attendanceRows.push({
            sessionId: session.id,
            studentId: enrollment.studentId,
            status: pattern[counter % pattern.length],
          });
        });
    });

  if (attendanceRows.length > 0) {
    await db.insert(attendance).values(attendanceRows);
  }

  /* ---------------------------- مسیر حفظ -------------------------------- */
  const hifzPlan: { studentId: number; juz: number; page: number; status: HifzStatus }[] = [];
  const fill = (studentId: number, memorized: number, inProgress: number) => {
    for (let page = 1; page <= 20; page += 1) {
      let status: HifzStatus = "none";
      if (page < memorized) status = "stable";
      else if (page === memorized) status = "memorized";
      else if (page === memorized + inProgress) status = "in_progress";
      if (status !== "none") {
        hifzPlan.push({ studentId, juz: 30, page, status });
      }
    }
  };
  fill(sid(0), 11, 1);
  fill(sid(1), 7, 2);
  if (hifzPlan.length > 0) await db.insert(hifzProgress).values(hifzPlan);

  /* ----------------------------- آزمون‌ها ------------------------------- */
  await db.insert(exams).values([
    {
      studentId: sid(0),
      classId: cid(0),
      teacherId: tid(0),
      examType: "new_page",
      title: "آزمون صفحه جدید — جزء ۳۰ صفحه ۱۱",
      examDate: shift(-14),
      score: 19,
      maxScore: 20,
      feedback: "روان و بدون خطا؛ فقط در مخارج حرف «ض» دقت بیشتری داشته باشید.",
    },
    {
      studentId: sid(0),
      classId: cid(0),
      teacherId: tid(0),
      examType: "tashbit",
      title: "تثبیت صفحه ۸ و ۹",
      examDate: shift(-7),
      score: 18,
      maxScore: 20,
      feedback: "تثبیت خوب است، وقف‌ها را بیشتر تمرین کنید.",
    },
    {
      studentId: sid(1),
      classId: cid(0),
      teacherId: tid(0),
      examType: "full_juz",
      title: "آزمون کل جزء ۳۰ (یک‌طرفه)",
      examDate: shift(-10),
      score: 17,
      maxScore: 20,
      feedback: "ادامه مسیر عالی است، سرعت تلاوت را کمتر کن.",
    },
    {
      studentId: sid(2),
      classId: cid(2),
      teacherId: tid(1),
      examType: "oral",
      title: "آزمون شفاهی احکام نون ساکنه",
      examDate: shift(-5),
      score: 16,
      maxScore: 20,
      feedback: "احکام را می‌دانید، در عملی کردن آن‌ها تمرین بیشتری لازم است.",
    },
    {
      studentId: sid(4),
      classId: cid(3),
      teacherId: tid(2),
      examType: "new_page",
      title: "قرائت تحقیقی — سوره مبارکه یس",
      examDate: shift(-3),
      score: 19,
      maxScore: 20,
      feedback: "صوت بسیار خوب، لحن عاطفی آیات اولیه درخشان بود.",
    },
  ]);

  /* ------------------------------ امور مالی ----------------------------- */
  await db.insert(payments).values([
    {
      studentId: sid(0),
      parentUserId: uid("09352020001"),
      title: "شهریه آذر — حفظ جزء سیام",
      amount: 750000,
      kind: "tuition",
      dueDate: shift(-30),
      status: "paid",
      paidAt: new Date(Date.now() - 28 * DAY),
      method: "درگاه پرداخت آنلاین",
      trackingCode: "MRJ-100241",
    },
    {
      studentId: sid(0),
      parentUserId: uid("09352020001"),
      title: "شهریه دی — حفظ جزء سیام",
      amount: 750000,
      kind: "tuition",
      dueDate: shift(-2),
      status: "overdue",
    },
    {
      studentId: sid(1),
      parentUserId: uid("09352020001"),
      title: "شهریه دی — حفظ جزء سیام",
      amount: 750000,
      kind: "tuition",
      dueDate: shift(6),
      status: "unpaid",
    },
    {
      studentId: sid(2),
      parentUserId: uid("09352020002"),
      title: "شهریه دی — تجوید و صوت و لحن",
      amount: 600000,
      kind: "tuition",
      dueDate: shift(9),
      status: "unpaid",
    },
    {
      studentId: sid(3),
      parentUserId: uid("09352020002"),
      title: "شهریه دی — روخوانی مقدماتی",
      amount: 420000,
      kind: "tuition",
      dueDate: shift(-5),
      status: "paid",
      paidAt: new Date(Date.now() - 6 * DAY),
      method: "کارت به کارت",
      trackingCode: "MRJ-100318",
    },
    {
      studentId: sid(4),
      parentUserId: uid("09352020003"),
      title: "شهریه دی — قرائت تحقیقی",
      amount: 900000,
      kind: "tuition",
      dueDate: shift(3),
      status: "unpaid",
    },
    {
      parentUserId: uid("09352020001"),
      title: "کمک به هیئت امنا — تجهیز سالن",
      amount: 2000000,
      kind: "donation",
      dueDate: shift(-12),
      status: "paid",
      paidAt: new Date(Date.now() - 12 * DAY),
      method: "درگاه پرداخت آنلاین",
      trackingCode: "MRJ-100155",
    },
  ]);

  /* ----------------------------- اعلان‌ها ------------------------------- */
  await db.insert(notifications).values([
    {
      userId: managerId,
      senderId: uid("09351010006"),
      title: "ثبت‌نام جدید: مریم نوری",
      body: "قرآن‌آموز جدید در سطح مفاهیم ثبت‌نام کرد و در انتظار تأیید مدیریت است.",
      kind: "registration",
    },
    {
      userId: managerId,
      title: "گزارش مالی هفتگی",
      body: "۳ فقره شهریه معوق و ۲ پرداخت موفق در هفته گذشته ثبت شده است.",
      kind: "payment",
    },
    {
      userId: uid("09351010001"),
      senderId: uid("09121230001"),
      title: "آزمون تثبیت هفته آینده",
      body: "آزمون تثبیت صفحه‌های ۹ تا ۱۱ روز شنبه برگزار می‌شود.",
      kind: "exam",
    },
    {
      userId: uid("09351010001"),
      senderId: uid("09121230001"),
      title: "تصحیح صوت تلاوت انجام شد",
      body: "صوت تلاوت شما بررسی و نمره ۱۸ ثبت شد. بازخورد را در بخش صوت تلاوت ببینید.",
      kind: "recording",
      isRead: true,
    },
    {
      userId: uid("09352020001"),
      senderId: managerId,
      title: "غیبت در جلسه حفظ",
      body: "قرآن‌آموز زهرا احمدی در جلسه روز سه‌شنبه غایب بوده است.",
      kind: "absence",
    },
    {
      userId: uid("09352020001"),
      senderId: managerId,
      title: "یادآوری شهریه معوق",
      body: "شهریه دی کلاس حفظ جزء سیام به مبلغ ۷۵۰,۰۰۰ تومان معوق است.",
      kind: "payment",
    },
    {
      userId: uid("09352020002"),
      senderId: managerId,
      title: "کارنامه ارزشیابی",
      body: "نمره آزمون شفاهی علی رضایی ثبت شد: ۱۶ از ۲۰",
      kind: "exam",
    },
    {
      userId: uid("09121230001"),
      senderId: managerId,
      title: "جلسه هم‌اندیشی اساتید",
      body: "جلسه اساتید پنجشنبه ساعت ۱۸ در سالن جلسات مجموعه برگزار می‌شود.",
      kind: "general",
    },
  ]);

  /* --------------------------- صوت تلاوت -------------------------------- */
  await db.insert(recordings).values([
    {
      studentId: sid(0),
      classId: cid(0),
      teacherId: tid(0),
      title: "تلاوت سوره مبارکه فجر",
      surahName: "فجر",
      ayahRange: "۱ تا ۲۰",
      status: "reviewed",
      score: 18,
      feedback: "روایت خوب بود؛ در «فَأَمَّا» غُنّه را کامل اجرا کنید.",
      reviewedAt: new Date(Date.now() - 3 * DAY),
    },
    {
      studentId: sid(1),
      classId: cid(0),
      teacherId: tid(0),
      title: "تلاوت سوره مبارکه بروج",
      surahName: "بروج",
      ayahRange: "۱ تا ۱۵",
      status: "pending",
    },
    {
      studentId: sid(4),
      classId: cid(3),
      teacherId: tid(2),
      title: "تلاوت سوره مبارکه یس",
      surahName: "یس",
      ayahRange: "۱ تا ۱۲",
      status: "pending",
    },
  ]);

  /* ------------------------------ گواهی --------------------------------- */
  await db.insert(certificates).values([
    {
      studentId: sid(1),
      classId: cid(0),
      courseName: "دوره حفظ جزء سیام",
      level: "حفظ",
      grade: "خیلی خوب",
      teacherName: "استاد محمدرضا کریمی",
      serial: "MRJ-CERT-1404-018",
      hours: 60,
      issuedAt: shift(-20),
    },
  ]);

  /* ---------------------------- تقویم ----------------------------------- */
  await db.insert(calendarEvents).values([
    {
      title: "آزمون کل جزء ۳۰ — کلاس حفظ",
      eventType: "exam",
      eventDate: shift(4),
      description: "آزمون جامع جزء سیام در سالن شهید مطهری",
      classId: cid(0),
    },
    {
      title: "شب شعر و مدح اهل‌بیت (ع)",
      eventType: "occasion",
      eventDate: shift(9),
      description: "برنامه فرهنگی با حضور خانواده‌های قرآن‌آموزان",
    },
    {
      title: "اردوی زیارتی مشهد مقدس",
      eventType: "trip",
      eventDate: shift(18),
      description: "اعزام دو روزه قرآن‌آموزان برتر مجموعه",
    },
    {
      title: "جلسه هیئت امنا و ارائه گزارش",
      eventType: "meeting",
      eventDate: shift(12),
      description: "ارائه گزارش عملکرد و مالی سه‌ماهه به هیئت امنا",
    },
  ]);

  /* پیام خوش‌آمد برای همه کاربران */
  await db.insert(notifications).values(
    insertedUsers.map((user) => ({
      userId: user.id,
      senderId: managerId,
      title: "به مجموعه فرهنگی قرآنی معارج خوش آمدید",
      body: "حساب کاربری شما در سامانه مدیریت معارج فعال شد. از داشبورد اختصاصی خود استفاده کنید.",
      kind: "general",
      isRead: false,
    })),
  );

  void teacherUsers;
}
